"""
FastAPI backend (production adapter).   Run from the project root:    python run.py       or      uvicorn backend.main:app --port 8000
All logic lives in src/api_core.py (shared with the zero-dependency server), so both servers behave identically.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Request, Response
from starlette.concurrency import run_in_threadpool

from src import api_core

app = FastAPI(title="Predictive Maintenance & RUL", version="3.0", docs_url=None, redoc_url=None, openapi_url=None)


@app.api_route("/{full_path:path}", methods=["GET", "POST", "HEAD"])
async def everything(request: Request, full_path: str):
    body = await request.body()
    path = request.url.path + (f"?{request.url.query}" if request.url.query else "")
    status, headers, payload = await run_in_threadpool(api_core.handle, request.method, path, dict(request.headers), body)
    return Response(content=payload, status_code=status, headers=headers)
