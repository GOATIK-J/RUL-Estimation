/* core.js - state, API client, shared components */
(function () {
  const { C, STATUS, esc, f } = PM;
  const S = { ds: null, model: null, datasets: [], info: null, route: "fleet", cmp: null };
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const name = (u) => "M-" + String(u).padStart(3, "0");

  function store(k, v) { try { if (v === undefined) return localStorage.getItem("pm." + k); localStorage.setItem("pm." + k, v); } catch (e) { return null; } }

  function toast(msg, kind = "err") {
    const t = $("#toast"); const n = document.createElement("div");
    n.className = "toast " + kind; n.textContent = msg; t.appendChild(n); setTimeout(() => n.remove(), 6000);
  }

  async function api(path, params = {}, opts = {}) {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== null && v !== undefined && v !== "")).toString();
    let r;
    try { r = await fetch("/api/" + path + (q ? "?" + q : ""), opts); }
    catch (e) { throw new Error("Cannot reach the server. Is it still running? (python run.py)"); }
    const ct = r.headers.get("content-type") || "";
    const data = ct.includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((data && data.error) || "Request failed (" + r.status + ")");
    return data;
  }

  // ---- model & dataset selectors ------------------------------------------------------------------------
  function fillModelSelect() {
    const sel = $("#modelSel"), ms = S.info.models;
    const group = (title, fam) => {
      const items = ms.filter((m) => m.family === fam);
      if (!items.length) return "";
      return `<optgroup label="${title}">` + items.map((m) => m.status === "ready"
        ? `<option value="${m.id}" ${m.id === S.model ? "selected" : ""}>${esc(m.name)}${m.recommended ? "  ★ best" : ""}</option>`
        : `<option value="${m.id}" disabled>${esc(m.name)}  (not trained yet)</option>`).join("") + "</optgroup>";
    };
    sel.innerHTML = group("Deep learning · TensorFlow/Keras", "deep") + group("Ensembles", "ensemble") + group("Classical machine learning", "classical");
    const m = ms.find((x) => x.id === S.model);
    sel.className = m ? m.family : "";
  }

  async function loadDataset(ds) {
    S.ds = ds; store("ds", ds);
    S.info = await api("models", { ds });
    const ready = S.info.models.filter((m) => m.status === "ready").map((m) => m.id);
    const saved = store("model:" + ds);
    S.model = ready.includes(saved) ? saved : S.info.recommended;
    S.cmp = null; S.lab = null;
    fillModelSelect();
  }

  function modelMeta(id) { return S.info.models.find((m) => m.id === id) || {}; }
  const famColor = (fam) => PM.FAMILY[fam] || C.cobalt;

  // ---- shared: machine health monitor card --------------------------------------------------------------------
  const ICON = { Temperature: "🌡", Pressure: "◔", "Speed / Vibration proxy": "∿", "Flow / Fuel": "≋" };
  function monitorCard(d, extra = "") {
    const col = STATUS[d.status] || C.steel, trends = Object.entries(d.groups || {});
    return `<section class="monitor st-${d.status}">
      <header><span class="mid">${esc(d.name)}</span><span class="badge st-${d.status}">${d.status}</span></header>
      <div class="mon-top"><div class="gauge">${PM.gaugeSvg(d.health_pct, col, 190)}<div class="gcap">Health score</div></div>
        <dl class="reads">
          <div><dt>Remaining useful life</dt><dd class="big">${f(d.rul, 0)}<small> cycles</small></dd></div>
          <div><dt>Anomaly score</dt><dd><span class="num">${f(d.anomaly, 2)}</span><span class="meter"><i style="width:${Math.min(100, d.anomaly * 100)}%;background:${d.anomaly > 0.5 ? C.crit : C.ok}"></i><b></b></span><small>${d.anomaly_flag ? "above alarm level" : "normal"}</small></dd></div>
          ${d.true_rul_capped !== undefined && d.true_rul_capped !== null ? `<div><dt>True RUL (capped)</dt><dd class="num">${f(d.true_rul_capped, 0)} <small>cycles</small></dd></div>` : ""}
        </dl></div>
      ${trends.length ? `<ul class="trends">${trends.map(([g, v]) => `<li><span>${esc(g)}</span><b class="arrow">${v.arrow}</b></li>`).join("")}</ul>` : ""}
      <div class="action"><b>Recommended action</b><p>${esc(d.action)}</p></div>${extra}
    </section>`;
  }

  function legend(items) { return `<div class="legend">${items.map((i) => `<span><i style="background:${i.color};${i.dash ? "height:0;border-top:2px dashed " + i.color + ";background:none" : ""}"></i>${esc(i.label)}</span>`).join("")}</div>`; }
  function lifeBands(cap) { return [{ from: 0, to: 30, color: C.crit }, { from: 30, to: 70, color: C.warn }, { from: 70, to: cap, color: C.ok }]; }

  function stripChart(el, d, opts = {}) {
    const ci = d.cycles.findIndex((c) => c > d.cutoff); const cut = ci < 0 ? d.cycles.length : ci;
    PM.line(el, { x: d.cycles, height: opts.height || 300, yMin: 0, yMax: d.cap + 5, bands: lifeBands(d.cap), cursor: d.cutoff, xLabel: "operating cycle", yLabel: "remaining useful life (cycles)", animate: opts.animate,
      onClick: opts.onClick,
      series: [{ name: "true RUL (capped)", color: C.ink, dash: "6 4", width: 1.6, values: d.rul_true_capped || d.cycles.map(() => null) },
               { name: d.model_name || "predicted", color: C.cobalt, width: 2.6, values: d.rul_pred.map((v, i) => (i < cut ? v : null)) }] });
  }

  window.PM.S = S; window.PM.$ = $; window.PM.$$ = $$; window.PM.api = api; window.PM.toast = toast; window.PM.name = name; window.PM.store = store;
  Object.assign(window.PM, { loadDataset, fillModelSelect, modelMeta, famColor, monitorCard, legend, lifeBands, stripChart });
})();
