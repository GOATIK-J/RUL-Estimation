/* views.js - the six pages */
(function () {
  const { C, STATUS, esc, f, S, $, $$, api, toast, name, store, monitorCard, legend, stripChart, famColor, modelMeta } = PM;
  const view = () => $("#view");
  const quant = (a, p) => { const s = [...a].sort((x, y) => x - y), i = (s.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); };
  const spinner = (t = "Loading") => `<div class="loading"><i></i>${t}…</div>`;
  const famLabel = { deep: "Deep learning", classical: "Classical ML", ensemble: "Ensemble" };
  const chip = (fam) => `<span class="chip ${fam}">${famLabel[fam] || fam}</span>`;

  // ====================================================================================== FLEET
  async function fleet() {
    view().innerHTML = spinner("Loading fleet");
    const d = await api("fleet", { ds: S.ds, model: S.model });
    const n = d.machines.length, c = (k) => d.counts[k] || 0;
    view().innerHTML = `
      <div class="page-head"><h1>Fleet board</h1>
        <p>${n} machines, shortest remaining life first. Predictions by <b>${esc(d.model_name)}</b>; change the model in the top bar to see the board update.</p></div>
      <div class="summary">
        <div class="seg st-CRITICAL"><b>${c("CRITICAL")}</b><span>critical<small>less than 30 cycles left</small></span></div>
        <div class="seg st-WARNING"><b>${c("WARNING")}</b><span>warning<small>30 to 70 cycles left</small></span></div>
        <div class="seg st-HEALTHY"><b>${c("HEALTHY")}</b><span>healthy<small>70 cycles or more</small></span></div>
        <div class="seg plain"><b>${f(d.mae, 1)}</b><span>average error<small>cycles, against true remaining life</small></span></div>
      </div>
      <div class="bar"><i class="st-CRITICAL" style="flex:${c("CRITICAL")}"></i><i class="st-WARNING" style="flex:${c("WARNING")}"></i><i class="st-HEALTHY" style="flex:${c("HEALTHY")}"></i></div>
      <div class="board" id="board">${d.machines.map((m) => `<a class="tile st-${m.status}" href="#/machine/${m.unit}" data-u="${m.unit}"><span class="tn">${name(m.unit)}</span><b>${f(m.rul_pred, 0)}</b>${m.anomaly > 0.5 ? '<i class="alarm" title="anomaly alarm"></i>' : ""}</a>`).join("")}</div>
      <p class="hint">Number on each tile = predicted remaining useful life in cycles. A red corner mark means the anomaly detector is also raising an alarm.</p>
      <div class="two">
        <section class="card c-cyan"><h2>Predicted against actual</h2><p class="sub">Each dot is one machine. Points on the diagonal are perfect; the green band is within 10 cycles.</p><div id="sc"></div></section>
        <section class="card c-rose"><h2>Maintenance priority list</h2><p class="sub">The ten machines that need attention first.</p>
          <table class="tbl compact"><thead><tr><th>Machine</th><th>Status</th><th class="r">RUL</th><th class="r">Anomaly</th><th>Action</th></tr></thead><tbody>
          ${d.machines.slice(0, 10).map((m) => `<tr class="click" data-u="${m.unit}"><td><b>${name(m.unit)}</b></td><td><span class="badge sm st-${m.status}">${m.status}</span></td><td class="r">${f(m.rul_pred, 0)}</td><td class="r">${f(m.anomaly, 2)}</td><td>${m.status === "CRITICAL" ? "Remove from service" : m.status === "WARNING" ? "Schedule inspection" : "Routine"}</td></tr>`).join("")}</tbody></table></section>
      </div>`;
    PM.scatter("#sc", { points: d.machines.map((m) => ({ x: m.rul_true_capped, y: m.rul_pred, color: STATUS[m.status], label: name(m.unit), u: m.unit })), onClick: (p) => (location.hash = "#/machine/" + p.u), height: 320 });
    $$(".click").forEach((r) => r.addEventListener("click", () => (location.hash = "#/machine/" + r.dataset.u)));
  }

  // ====================================================================================== MACHINE
  async function machine(unit, cutoff) {
    view().innerHTML = spinner("Loading machine");
    const fl = await api("fleet", { ds: S.ds, model: S.model });
    const units = fl.machines.map((m) => m.unit).sort((a, b) => a - b);
    if (!unit || !units.includes(+unit)) unit = (fl.machines.find((m) => m.status === "WARNING") || fl.machines[0]).unit;
    unit = +unit;
    const d = await api("engine", { ds: S.ds, model: S.model, unit, cutoff });
    const i = units.indexOf(unit), first = d.cycles[0];
    view().innerHTML = `
      <div class="page-head row"><div><h1>Machine monitor</h1><p>One machine in detail. Prediction by <b>${esc(d.model_name)}</b>.</p></div>
        <div class="picker"><button class="ghost" id="prev" aria-label="Previous machine">‹</button>
          <select id="unitSel" aria-label="Machine">${units.map((u) => `<option value="${u}" ${u === unit ? "selected" : ""}>${name(u)}</option>`).join("")}</select>
          <button class="ghost" id="next" aria-label="Next machine">›</button>
          <a class="btn ghost" href="#/compare/${unit}">Compare models on this machine</a></div></div>
      <div class="replay"><label for="rp">Replay: what did the model know at cycle</label>
        <input id="rp" type="range" min="${first}" max="${d.last_cycle}" value="${d.cutoff}"><output id="rpo">${d.cutoff} of ${d.last_cycle}</output><button class="ghost" id="latest">Latest</button></div>
      <div class="mon-layout"><div>${monitorCard(d)}</div>
        <div class="stack">
          <section class="card c-cyan"><h2>Remaining life across the machine's lifetime</h2>
            <p class="sub">Solid line: what the model predicted using only the data up to each cycle. Dashed: the true value. Click the chart to replay from that cycle.</p>
            ${legend([{ label: "Prediction", color: C.cobalt }, { label: "True RUL (capped at " + d.cap + ")", color: C.ink, dash: true }, { label: "Critical zone", color: C.crit }, { label: "Warning zone", color: C.warn }, { label: "Healthy zone", color: C.ok }])}
            <div id="strip"></div></section>
          <div class="two tight">
            <section class="card c-violet"><h2>Anomaly score</h2><p class="sub">Distance from this machine type's healthy behaviour. Above the line = alarm.</p><div id="anom"></div></section>
            <section class="card c-amber"><h2>Why this prediction?</h2><p class="sub">${esc(d.importance_method)}. Red pulls remaining life down; green pushes it up.</p><div id="why"></div></section>
          </div>
          <section class="card c-teal"><h2>Sensor trends</h2><p class="sub">The sensors that matter most for this prediction, normalised so 0 is typical.</p><div class="minis" id="minis"></div></section>
        </div></div>`;
    stripChart("#strip", d, { animate: !cutoff, onClick: (c) => machine(unit, c) });
    const ci = d.cycles.findIndex((c) => c > d.cutoff), cut = ci < 0 ? d.cycles.length : ci;
    PM.line("#anom", { x: d.cycles, height: 262, yMin: 0, yMax: 1, cursor: d.cutoff, xLabel: "operating cycle", dec: 2, hlines: [{ y: 0.5, label: "alarm", color: C.crit }],
      series: [{ name: "anomaly score", color: C.deep, width: 2, area: true, values: d.anomaly_series.map((v, k) => (k < cut ? v : null)) }] });
    PM.diverge("#why", d.importance.map((x) => ({ label: x.label, value: x.value, trend: x.trend })));
    $("#minis").innerHTML = Object.entries(d.sensors).map(([k, s], n) => `<div class="mini"><b>${esc(k)}</b><small>${esc(s.desc)}</small><div id="mini${n}"></div></div>`).join("");
    Object.values(d.sensors).forEach((s, n) => PM.line("#mini" + n, { x: d.cycles, height: 96, cursor: d.cutoff, hover: true, dec: 2, series: [{ name: "normalised", color: C.classical, width: 1.8, values: s.z.map((v, k) => (k < cut ? v : null)) }] }));
    const go = (u, c) => (location.hash = "#/machine/" + u + (c ? "?cutoff=" + c : ""));
    $("#unitSel").onchange = (e) => go(e.target.value);
    $("#prev").onclick = () => go(units[(i - 1 + units.length) % units.length]);
    $("#next").onclick = () => go(units[(i + 1) % units.length]);
    $("#latest").onclick = () => go(unit);
    $("#rp").oninput = (e) => ($("#rpo").textContent = e.target.value + " of " + d.last_cycle);
    $("#rp").onchange = (e) => go(unit, +e.target.value);
  }

  // ====================================================================================== COMPARE
  const COLS = [
    { k: "val", t: "Validation R²", g: (m) => m.metrics.val.R2, d: 3, hi: true },
    { k: "test", t: "Test R²", g: (m) => m.metrics.test.R2, d: 3, hi: true },
    { k: "raw", t: "Test R² (raw labels)", g: (m) => m.metrics.test.R2_raw, d: 3, hi: true },
    { k: "rmse", t: "RMSE", g: (m) => m.metrics.test.RMSE, d: 1, hi: false },
    { k: "mae", t: "MAE", g: (m) => m.metrics.test.MAE, d: 1, hi: false },
    { k: "nasa", t: "NASA score", g: (m) => m.metrics.test.NASA_score, d: 0, hi: false },
    { k: "w10", t: "Within ±10 cycles", g: (m) => m.metrics.test["Within_10_cycles_%"], d: 0, hi: true, u: "%" },
    { k: "gap", t: "Train − test R²", g: (m) => m.metrics.train.R2 - m.metrics.test.R2, d: 3, hi: false, nb: true },
    { k: "kb", t: "Size (KB)", g: (m) => m.size_kb, d: 0, hi: false },
    { k: "lat", t: "Latency (ms)", g: (m) => m.latency_ms, d: 1, hi: false },
  ];

  async function compare(unitParam) {
    view().innerHTML = spinner("Loading model results");
    if (!S.lab) S.lab = await api("lab", { ds: S.ds });
    const L = S.lab, ready = L.models.filter((m) => m.status === "ready"), untrained = L.models.filter((m) => m.status !== "ready");
    const byVal = (fam) => ready.filter((m) => (fam ? m.family === fam : true)).sort((a, b) => a.metrics.val.RMSE - b.metrics.val.RMSE);
    if (!S.cmp) S.cmp = [...new Set([L.recommended, (byVal("deep")[0] || {}).id, (byVal("classical")[0] || {}).id].filter(Boolean))];
    S.cmp = S.cmp.filter((id) => ready.some((m) => m.id === id));
    const sort = S.sort || { k: "test", dir: -1 }, col = COLS.find((c) => c.k === sort.k);
    const rows = [...ready].sort((a, b) => (col.g(a) - col.g(b)) * sort.dir * (sort.dir === -1 ? 1 : 1));
    const best = {}; COLS.forEach((c) => { if (c.nb) { best[c.k] = NaN; return; } const v = ready.map(c.g); best[c.k] = c.hi ? Math.max(...v) : Math.min(...v.filter((x) => x !== null)); });
    const banner = L.deep_available ? "" : `<div class="note"><b>Deep learning models are not trained in this copy yet.</b>
        <p>The table below compares the classical models and their ensemble. To add the six TensorFlow/Keras models (MLP, LSTM, GRU, BiLSTM, CNN-LSTM, CNN-BiLSTM-Attention), run these two commands in the project folder. They appear here automatically afterwards.</p>
        <pre><code>pip install tensorflow\npython tools/train_deep_models.py</code></pre></div>`;
    view().innerHTML = `
      <div class="page-head"><h1>Compare models</h1><p>Every model is scored on the same ${L.units.length} machines it has never seen. The model you pick in the top bar is the one used for predictions elsewhere.</p></div>
      ${banner}
      <section class="card c-blue"><h2>Leaderboard</h2><p class="sub">Click a column to sort. Tick up to 5 models to show them in the charts below. Bold = best in column. “Train − test R²” near 0 means no overfitting.</p>
        <div class="scroll"><table class="tbl lb"><thead><tr><th></th><th>Model</th>${COLS.map((c) => `<th class="r sortable ${sort.k === c.k ? "on" : ""}" data-k="${c.k}">${c.t}${sort.k === c.k ? (sort.dir === -1 ? " ↓" : " ↑") : ""}</th>`).join("")}</tr></thead><tbody>
        ${rows.map((m) => `<tr class="${S.cmp.includes(m.id) ? "sel" : ""}"><td><input type="checkbox" data-id="${m.id}" ${S.cmp.includes(m.id) ? "checked" : ""} aria-label="Show ${esc(m.name)} in charts"></td>
          <td class="mn"><b>${esc(m.name)}</b>${m.recommended ? ' <span class="star" title="Lowest validation error">★ best on validation</span>' : ""}<div>${chip(m.family)}</div></td>
          ${COLS.map((c) => { const v = c.g(m); return `<td class="r ${Math.abs(v - best[c.k]) < 1e-9 ? "bestv" : ""}">${f(v, c.d)}${c.u || ""}</td>`; }).join("")}</tr>`).join("")}
        ${untrained.map((m) => `<tr class="off"><td></td><td class="mn"><b>${esc(m.name)}</b><div>${chip(m.family)} <span class="muted">not trained yet</span></div></td>${COLS.map(() => '<td class="r">–</td>').join("")}</tr>`).join("")}
        </tbody></table></div></section>
      <div class="two">
        <section class="card c-violet"><h2>Accuracy at a glance</h2><div class="seg-ctl" id="metricSel"><button data-m="R2" class="on">R²</button><button data-m="RMSE">RMSE</button><button data-m="MAE">MAE</button></div>
          <div class="legend"><span><i style="background:${C.deep}"></i>Deep learning</span><span><i style="background:${C.classical}"></i>Classical</span><span><i style="background:${C.ensemble}"></i>Ensemble</span></div><p class="sub" id="axnote"></p><div id="bars"></div></section>
        <section class="card c-rose"><h2>Error spread</h2><p class="sub">Box = middle half of the errors, bar = median. A narrow box centred on 0 is better.</p><div id="box"></div></section>
      </div>
      <section class="card c-cyan"><h2>Predicted against actual, side by side</h2><p class="sub">Selected models only. Tighter around the diagonal is better.</p><div class="grid3" id="scs"></div></section>
      <div class="two">
        <section class="card c-teal"><h2>Overfitting check</h2><p class="sub">R² on training data, held-out validation engines and the official test engines. Dots close together mean the model generalises.</p>${legend([{ label: "Training", color: C.steel }, { label: "Validation", color: C.cobalt }, { label: "Test", color: C.ink }])}<div id="dots"></div></section>
        <section class="card c-amber"><h2>What each model relies on</h2><p class="sub">Average influence of each input on the prediction (occlusion), scaled per model. Darker = more influence.</p><div id="heat" class="scroll"></div></section>
      </div>
      <section class="card c-blue"><h2>One machine, every model</h2>
        <div class="inline"><label for="cu">Machine</label><select id="cu">${L.units.map((u) => `<option value="${u}" ${+unitParam === u ? "selected" : ""}>${name(u)}</option>`).join("")}</select></div>
        <div id="hth"></div></section>`;

    $$(".sortable").forEach((th) => (th.onclick = () => { S.sort = { k: th.dataset.k, dir: sort.k === th.dataset.k ? -sort.dir : (COLS.find((c) => c.k === th.dataset.k).hi ? -1 : 1) }; compare(unitParam); }));
    $$("input[data-id]").forEach((cb) => (cb.onchange = () => {
      const id = cb.dataset.id; S.cmp = cb.checked ? [...S.cmp, id].slice(-5) : S.cmp.filter((x) => x !== id); compare(unitParam);
    }));
    const col2 = (m) => famColor(m.family);
    const drawBars = (metric) => {
      const items = ready.map((m) => ({ label: m.name, value: m.metrics.test[metric], color: col2(m), best: m.recommended })).sort((a, b) => (metric === "R2" ? b.value - a.value : a.value - b.value));
      const lo = metric === "R2" ? Math.floor((Math.min(...items.map((i) => i.value)) - 0.04) * 20) / 20 : 0;
      $("#axnote").textContent = metric === "R2" ? "Axis starts at " + lo.toFixed(2) + " to make the differences visible." : "";
      PM.hbar("#bars", items, { min: lo, max: metric === "R2" ? 1 : undefined, dec: metric === "R2" ? 3 : 1, rowH: 30 });
    };
    drawBars("R2");
    $$("#metricSel button").forEach((b) => (b.onclick = () => { $$("#metricSel button").forEach((x) => x.classList.toggle("on", x === b)); drawBars(b.dataset.m); }));
    const errs = (id) => L.preds[id].map((p, i) => p - L.true_capped[i]);
    PM.boxes("#box", ready.map((m) => { const e = errs(m.id); return { label: m.name, color: col2(m), q: [quant(e, 0.05), quant(e, 0.25), quant(e, 0.5), quant(e, 0.75), quant(e, 0.95)], rm: m.metrics.test.RMSE }; }).sort((a, b) => a.rm - b.rm), { lo: -40, hi: 40 });
    $("#scs").innerHTML = S.cmp.map((id, k) => { const m = ready.find((x) => x.id === id); return `<div class="sc"><b>${esc(m.name)}</b><small>R² ${f(m.metrics.test.R2, 3)} · RMSE ${f(m.metrics.test.RMSE, 1)}</small><div id="s${k}"></div></div>`; }).join("");
    S.cmp.forEach((id, k) => { const m = ready.find((x) => x.id === id); PM.scatter("#s" + k, { height: 250, color: col2(m), points: L.units.map((u, i) => ({ x: L.true_capped[i], y: L.preds[id][i], label: name(u) })) }); });
    // overfit dots
    const dr = [...ready].sort((a, b) => b.metrics.test.R2 - a.metrics.test.R2);
    PM.mount("#dots", (W) => {
      const rowH = 28, lw = Math.min(180, W * 0.36), H = dr.length * rowH + 30, lo = Math.floor(Math.min(...dr.map((m) => Math.min(m.metrics.val.R2, m.metrics.test.R2))) * 20 - 1) / 20, X = (v) => lw + ((v - lo) / (1.0 - lo)) * (W - lw - 20);
      let b = PM.ticks(lo, 1, 5).map((t) => `<line x1="${X(t)}" x2="${X(t)}" y1="0" y2="${H - 24}" stroke="${C.grid}"/><text x="${X(t)}" y="${H - 8}" text-anchor="middle" class="ax">${f(t, 2)}</text>`).join("");
      dr.forEach((m, i) => { const y = 4 + i * rowH + 14, a = m.metrics.train.R2, v = m.metrics.val.R2, t = m.metrics.test.R2;
        b += `<text x="${lw - 10}" y="${y + 4}" text-anchor="end" class="bl">${esc(m.name)}</text><line x1="${X(Math.min(a, v, t))}" x2="${X(Math.max(a, v, t))}" y1="${y}" y2="${y}" stroke="${C.rule}" stroke-width="3"/>`
          + `<circle cx="${X(a)}" cy="${y}" r="5" fill="none" stroke="${C.steel}" stroke-width="2"><title>training ${f(a, 3)}</title></circle><rect x="${X(v) - 4.5}" y="${y - 4.5}" width="9" height="9" fill="${C.cobalt}"><title>validation ${f(v, 3)}</title></rect><circle cx="${X(t)}" cy="${y}" r="5" fill="${C.ink}"><title>test ${f(t, 3)}</title></circle>`; });
      return `<svg class="chart" width="${W}" height="${H}">${b}</svg>`;
    });
    // heatmap
    const feats = {}; S.cmp.forEach((id) => Object.entries(L.importance[id] || {}).forEach(([k, v]) => (feats[k] = (feats[k] || 0) + v / (Math.max(...Object.values(L.importance[id])) || 1))));
    const top = Object.entries(feats).sort((a, b) => b[1] - a[1]).slice(0, 9).map((x) => x[0]);
    $("#heat").innerHTML = `<table class="tbl heat"><thead><tr><th></th>${top.map((t) => `<th>${esc(t.replace("sensor_", "s"))}</th>`).join("")}</tr></thead><tbody>${S.cmp.map((id) => { const imp = L.importance[id] || {}, mx = Math.max(...Object.values(imp)) || 1; return `<tr><th class="rowh">${esc(ready.find((m) => m.id === id).name)}</th>${top.map((t) => { const v = (imp[t] || 0) / mx; return `<td style="background:rgba(36,79,214,${(0.06 + v * 0.8).toFixed(2)});color:${v > 0.5 ? "#fff" : C.ink}" title="${f(imp[t], 2)} cycles">${f(v, 2)}</td>`; }).join("")}</tr>`; }).join("")}</tbody></table>`;
    // head to head
    const drawH2H = async (u) => {
      $("#hth").innerHTML = spinner("Comparing");
      const d = await api("compare", { ds: S.ds, unit: u });
      $("#hth").innerHTML = legend([{ label: "True RUL", color: C.ink, dash: true }, ...S.cmp.map((id, k) => ({ label: ready.find((m) => m.id === id).name, color: PM.palette(k) }))]) + '<div id="h2h"></div>' +
        `<table class="tbl compact"><thead><tr><th>Model</th><th class="r">Predicted RUL now</th><th class="r">Error (cycles)</th></tr></thead><tbody>${S.cmp.map((id) => { const m = d.models.find((x) => x.id === id); return `<tr><td>${esc(m.name)}</td><td class="r">${f(m.final, 1)}</td><td class="r">${f(m.error, 1)}</td></tr>`; }).join("")}<tr class="truth"><td>True RUL (capped)</td><td class="r">${f(d.true_capped[d.true_capped.length - 1], 1)}</td><td class="r">–</td></tr></tbody></table>`;
      PM.line("#h2h", { x: d.cycles, height: 300, yMin: 0, yMax: d.cap + 5, bands: PM.lifeBands(d.cap), xLabel: "operating cycle", yLabel: "remaining useful life (cycles)",
        series: [{ name: "True RUL", color: C.ink, dash: "6 4", width: 1.6, values: d.true_capped }, ...S.cmp.map((id, k) => ({ name: ready.find((m) => m.id === id).name, color: PM.palette(k), width: 2, values: d.models.find((x) => x.id === id).pred }))] });
    };
    const order = L.units.map((u, i) => i).sort((a, b) => L.true_capped[a] - L.true_capped[b]);
    const startU = unitParam && L.units.includes(+unitParam) ? +unitParam : L.units[order[Math.floor(order.length * 0.2)]];
    $("#cu").value = startU; drawH2H(startU).catch((e) => toast(e.message));
    $("#cu").onchange = (e) => drawH2H(+e.target.value).catch((er) => toast(er.message));
  }
  PM.palette = (k) => [C.cobalt, "#FFB631", "#FF7AB8", "#A78BFA", "#34D399"][k % 5];

  // ====================================================================================== LIVE
  function parseCSV(text) {
    const lines = text.replace(/\r/g, "").split("\n").filter((l) => l.trim());
    if (lines.length < 2) throw new Error("The file needs a header row and at least one data row.");
    const sep = lines[0].includes(",") ? "," : lines[0].includes(";") ? ";" : /\t/.test(lines[0]) ? "\t" : /\s+/;
    const head = lines[0].split(sep).map((h) => h.trim().replace(/^"|"$/g, ""));
    return lines.slice(1).map((l) => { const c = l.split(sep), o = {}; head.forEach((h, i) => (o[h] = c[i] === undefined || c[i].trim() === "" ? null : Number(c[i]))); return o; });
  }

  function resultBlock(d, label) {
    const card = Object.assign({}, d, { name: label, groups: {} });
    return `<div class="stack"><div>${monitorCard(card)}</div><div class="stack">
      <section class="card"><h2>Remaining life predicted at every cycle</h2><p class="sub">Each point uses only the data up to that cycle.</p><div id="lv"></div></section>
      <div class="two tight"><section class="card"><h2>Anomaly score</h2><div id="la"></div></section><section class="card"><h2>Why this prediction?</h2><p class="sub">Occlusion: cycles of life each input takes away.</p><div id="lw"></div></section></div></div></div>`;
  }
  function drawResult(d) {
    PM.line("#lv", { x: d.cycles, height: 260, yMin: 0, yMax: d.cap + 5, bands: PM.lifeBands(d.cap), xLabel: "operating cycle", yLabel: "RUL (cycles)", series: [{ name: d.model_name, color: C.cobalt, width: 2.5, values: d.rul_pred }] });
    PM.line("#la", { x: d.cycles, height: 190, yMin: 0, yMax: 1, dec: 2, hlines: [{ y: 0.5, label: "alarm" }], series: [{ name: "anomaly", color: C.deep, area: true, values: d.anomaly_series }] });
    PM.diverge("#lw", d.importance.map((x) => ({ label: x.label, value: x.value, trend: x.trend })));
  }

  async function live() {
    const meta = modelMeta(S.model);
    const units = (S.lab ? S.lab.units : (await api("fleet", { ds: S.ds, model: S.model })).machines.map((m) => m.unit).sort((a, b) => a - b));
    view().innerHTML = `
      <div class="page-head"><h1>Live prediction</h1><p>Upload the sensor history of a machine and get its health dashboard. Pick the model first: the same data gives different answers from different models.</p></div>
      <div class="two start">
        <section class="card"><h2>1. Sensor data</h2>
          <label class="drop" id="drop"><input type="file" id="file" accept=".csv,.txt"><b>Drop a CSV here, or click to choose</b><small>One row per operating cycle. Columns: cycle, sensor_1 … sensor_21${S.info && S.ds && ["FD002", "FD004"].includes(S.ds) ? ", setting_1 … setting_3" : ""}.</small></label>
          <p class="or">or use a machine from the test fleet</p>
          <div class="inline"><select id="lu">${units.map((u) => `<option value="${u}">${name(u)}</option>`).join("")}</select><a class="btn ghost" id="dl" href="#">Download its CSV</a></div>
          <h2 class="gap">2. Model</h2>
          <div class="modelline"><span class="dotf ${meta.family}"></span><b>${esc(meta.name)}</b>${chip(meta.family)}<small>Change it in the top bar.</small></div>
          <div class="btnrow"><button class="btn" id="runSel">Predict with this machine</button><button class="btn ghost" id="runAll">Compare all models on it</button></div>
        </section>
        <section class="card" id="out"><div class="empty"><b>Nothing predicted yet</b><p>Choose a file or a machine, then press Predict.</p></div></section>
      </div>`;
    const out = $("#out"); let rows = null, label = "";
    const setDl = () => ($("#dl").href = `/api/sample.csv?ds=${S.ds}&unit=${$("#lu").value}`);
    setDl(); $("#lu").onchange = () => { rows = null; setDl(); };
    const run = async (r, lab) => {
      out.innerHTML = spinner("Predicting with " + meta.name);
      const d = await api("predict", { ds: S.ds, model: S.model }, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rows: r }) });
      out.innerHTML = `<h2>Result · ${esc(lab)}</h2>` + resultBlock(d, lab); drawResult(d);
    };
    const getRows = async () => {
      if (rows) return { r: rows, lab: label };
      const csv = await api("sample.csv", { ds: S.ds, unit: $("#lu").value });
      return { r: parseCSV(csv), lab: name($("#lu").value) };
    };
    $("#file").onchange = async (e) => {
      const fl = e.target.files[0]; if (!fl) return;
      try { rows = parseCSV(await fl.text()); label = fl.name; $("#drop b").textContent = fl.name + " · " + rows.length + " cycles"; await run(rows, label); } catch (er) { console.error(er.stack); toast(er.message); out.innerHTML = `<div class="empty"><b>Could not predict</b><p>${esc(er.message)}</p></div>`; }
    };
    $("#drop").ondragover = (e) => { e.preventDefault(); $("#drop").classList.add("over"); };
    $("#drop").ondragleave = () => $("#drop").classList.remove("over");
    $("#drop").ondrop = (e) => { e.preventDefault(); $("#drop").classList.remove("over"); $("#file").files = e.dataTransfer.files; $("#file").onchange({ target: $("#file") }); };
    $("#runSel").onclick = async () => { try { const x = await getRows(); await run(x.r, x.lab); } catch (er) { console.error(er.stack); toast(er.message); out.innerHTML = `<div class="empty"><b>Could not predict</b><p>${esc(er.message)}</p></div>`; } };
    $("#runAll").onclick = async () => {
      try {
        const x = await getRows(); const ready = S.info.models.filter((m) => m.status === "ready"); const res = [];
        out.innerHTML = `<h2>All models · ${esc(x.lab)}</h2><div id="allrows">${spinner("Running " + ready.length + " models")}</div>`;
        const box = $("#allrows");
        for (const m of ready) {
          try { const d = await api("predict", { ds: S.ds, model: m.id }, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rows: x.r }) }); res.push({ m, d }); }
          catch (er) { res.push({ m, err: er.message }); }
          box.innerHTML = allTable(res, ready.length);
        }
      } catch (er) { console.error(er.stack); toast(er.message); }
    };
  }
  function allTable(res, total) {
    const ok = res.filter((r) => r.d), vals = ok.map((r) => r.d.rul), mn = Math.min(...vals), mx = Math.max(...vals);
    return `<table class="tbl"><thead><tr><th>Model</th><th>Type</th><th class="r">Predicted RUL</th><th>Status</th><th class="r">Anomaly</th></tr></thead><tbody>${res.map((r) => r.d
      ? `<tr><td><b>${esc(r.m.name)}</b></td><td>${chip(r.m.family)}</td><td class="r">${f(r.d.rul, 1)}</td><td><span class="badge sm st-${r.d.status}">${r.d.status}</span></td><td class="r">${f(r.d.anomaly, 2)}</td></tr>`
      : `<tr class="off"><td><b>${esc(r.m.name)}</b></td><td>${chip(r.m.family)}</td><td colspan="3" class="muted">${esc(r.err)}</td></tr>`).join("")}</tbody></table>
      <p class="hint">${res.length < total ? "Running… " : ""}${ok.length > 1 ? `Spread between models: ${f(mx - mn, 1)} cycles.` : ""}</p>`;
  }

  // ====================================================================================== PHOTO
  async function photo() {
    const reg = await api("registry", { ds: S.ds });
    const units = (S.lab ? S.lab.units : (await api("fleet", { ds: S.ds, model: S.model })).machines.map((m) => m.unit).sort((a, b) => a - b));
    view().innerHTML = `
      <div class="page-head"><h1>Machine photo</h1><p>Upload a photo of a machine to open its health dashboard.</p></div>
      <div class="note soft"><b>What the photo does, and what it does not.</b> A photo cannot show how many cycles a machine has left; that comes from its sensor history. The photo identifies <i>which</i> machine it is (machine ID in the file name, a QR code in the picture, or a photo registered earlier), and the dashboard is built from that machine's sensor data.</div>
      <div class="two start">
        <section class="card"><h2>Upload a photo</h2>
          <label class="drop img" id="pdrop"><input type="file" id="pfile" accept="image/*"><div id="prev"><b>Drop a photo here, or click to choose</b><small>JPG, PNG or WEBP. Name it like M-023.jpg to open M-023 directly.</small></div></label>
          <div id="idres"></div>
          ${reg.length ? `<h2 class="gap">Or try a sample photo</h2><div class="gallery" id="gal">${reg.map((e) => `<button class="thumb" data-u="${e.unit}" data-url="${e.url}" title="${e.name}"><img src="${e.url}" alt="Photo of ${e.name}"><span>${e.name}</span></button>`).join("")}</div><p class="hint">Sample photos are matched by picture content, not by file name.</p>` : ""}
        </section>
        <section class="card" id="pout"><div class="empty"><b>No photo yet</b><p>The machine's dashboard appears here after you upload a photo.</p></div></section>
      </div>`;
    const show = async (unit, ds, idInfo) => {
      if (ds && ds !== S.ds) { await PM.loadDataset(ds); $("#dsSel").value = ds; }
      const d = await api("engine", { ds: S.ds, model: S.model, unit });
      $("#pout").innerHTML = `<h2>Dashboard for ${name(unit)}</h2><p class="sub">${esc(idInfo)} Prediction by <b>${esc(d.model_name)}</b>.</p>${monitorCard(d)}<section class="inner"><h3>Remaining life across the machine's lifetime</h3><div id="pstrip"></div></section><a class="btn" href="#/machine/${unit}">Open full machine monitor</a>`;
      stripChart("#pstrip", d, { height: 240 });
    };
    const identify = async (blob, filename) => {
      $("#idres").innerHTML = spinner("Identifying machine");
      let qr = null;
      if ("BarcodeDetector" in window) { try { const bmp = await createImageBitmap(blob); const codes = await new BarcodeDetector({ formats: ["qr_code"] }).detect(bmp); const t = codes.length && codes[0].rawValue.match(/(\d{1,4})/); if (t && units.includes(+t[1])) qr = +t[1]; } catch (e) { /* QR scanning is optional */ } }
      const r = await api("image/identify", { ds: S.ds }, { method: "POST", headers: { "X-Filename": encodeURIComponent(filename || ""), "Content-Type": "application/octet-stream" }, body: blob });
      if (qr) Object.assign(r, { unit: qr, method: "QR code", confidence: 1, note: `A QR code in the photo reads M-${String(qr).padStart(3, "0")}.` });
      const meta = `<div class="imginfo">${r.image.width} × ${r.image.height} px · ${r.image.format} · ${r.image.kb} KB</div>`;
      if (r.unit) {
        $("#idres").innerHTML = `${meta}<div class="found"><b>${name(r.unit)}</b><span>Identified by ${r.method}${r.confidence && r.confidence < 1 ? " · " + Math.round(r.confidence * 100) + "% match" : ""}</span></div>`;
        await show(r.unit, r.dataset, r.note);
      } else {
        $("#idres").innerHTML = `${meta}<div class="notfound"><b>Machine not recognised</b><p>${esc(r.note)}</p><div class="inline"><select id="pick">${units.map((u) => `<option value="${u}">${name(u)}</option>`).join("")}</select><button class="btn" id="reg">Register photo and open dashboard</button></div></div>`;
        $("#reg").onclick = async () => { try { const u = +$("#pick").value; await api("image/register", { ds: S.ds, unit: u }, { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: blob }); toast("Photo registered to " + name(u) + ". Uploading it again will now be recognised.", "ok"); $("#idres").innerHTML = meta + `<div class="found"><b>${name(u)}</b><span>Registered by you</span></div>`; await show(u, null, "You linked this photo to the machine."); } catch (e) { toast(e.message); } };
      }
    };
    const handle = async (blob, filename) => {
      try { $("#prev").innerHTML = `<img class="preview" src="${URL.createObjectURL(blob)}" alt="Uploaded machine photo">`; await identify(blob, filename); }
      catch (e) { $("#idres").innerHTML = `<div class="notfound"><b>Could not use this file</b><p>${esc(e.message)}</p></div>`; }
    };
    $("#pfile").onchange = (e) => { const fl = e.target.files[0]; if (fl) handle(fl, fl.name); };
    $("#pdrop").ondragover = (e) => { e.preventDefault(); $("#pdrop").classList.add("over"); };
    $("#pdrop").ondragleave = () => $("#pdrop").classList.remove("over");
    $("#pdrop").ondrop = (e) => { e.preventDefault(); $("#pdrop").classList.remove("over"); const fl = e.dataTransfer.files[0]; if (fl) handle(fl, fl.name); };
    $$("#gal .thumb").forEach((b) => (b.onclick = async () => { const blob = await (await fetch(b.dataset.url)).blob(); handle(blob, "sample_photo.png"); }));
  }

  // ====================================================================================== ABOUT
  function about() {
    const steps = [["Sensor data", "21 sensors + 3 settings per cycle (NASA C-MAPSS turbofan engines)"], ["Preprocessing", "per-condition scaling, drop constant sensors, causal smoothing"], ["Time windows", "last 30 or 40 cycles per machine"],
      ["Prediction models", "6 Keras networks and 4 classical models, compared on the same machines"], ["Outputs", "remaining useful life · anomaly score · health status"], ["Explanation", "which sensors push the remaining life down"], ["This dashboard", "fleet board, machine monitor, model comparison"]];
    view().innerHTML = `
      <div class="page-head"><h1>How it works</h1><p>From raw sensor readings to a maintenance decision.</p></div>
      <section class="card"><div class="flow">${steps.map((s, i) => `<div class="step"><b>${s[0]}</b><span>${s[1]}</span></div>${i < steps.length - 1 ? '<i class="join"></i>' : ""}`).join("")}</div></section>
      <div class="two">
        <section class="card"><h2>What the numbers mean</h2><dl class="defs">
          <dt>Remaining useful life (RUL)</dt><dd>Operating cycles left before the engine needs maintenance. Targets are capped at 125 because a healthy engine shows no sign of when it will fail.</dd>
          <dt>R²</dt><dd>Share of the variation in remaining life the model explains. 1 is perfect, 0 is no better than guessing the average.</dd>
          <dt>RMSE and MAE</dt><dd>Typical error in cycles. RMSE punishes large mistakes more.</dd>
          <dt>NASA score</dt><dd>An asymmetric penalty: predicting failure later than it happens costs more than predicting it early. Lower is better.</dd>
          <dt>Anomaly score</dt><dd>How far the current sensor pattern is from this machine type's healthy behaviour. Above 0.5 raises an alarm.</dd>
          <dt>Train − test R²</dt><dd>Close to zero means the model is not memorising its training machines.</dd></dl></section>
        <section class="card"><h2>Good to know</h2><dl class="defs">
          <dt>Fair comparison</dt><dd>Every model is trained on the same machines, chosen by held-out validation machines, and scored once on official test machines it has never seen.</dd>
          <dt>Vibration</dt><dd>C-MAPSS has no vibration sensor. Fan and core speed sensors stand in as the rotating-machinery signal.</dd>
          <dt>Photos</dt><dd>A photo identifies the machine. Health comes from sensor data, because a picture cannot reveal remaining life.</dd>
          <dt>Datasets</dt><dd>FD001: one operating condition. FD004: six operating conditions and two fault types, the hardest.</dd></dl></section>
      </div>`;
  }

  PM.views = { fleet, machine, compare, live, photo, about };
})();
