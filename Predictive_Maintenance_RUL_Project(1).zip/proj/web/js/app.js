/* app.js - router and start-up */
(function () {
  const { S, $, $$, api, toast, store, esc } = PM;
  const titles = { fleet: "Fleet board", machine: "Machine monitor", compare: "Compare models", live: "Live prediction", photo: "Machine photo", about: "How it works" };

  function parse() {
    const h = location.hash.replace(/^#\/?/, ""), [path, qs] = h.split("?"), parts = path.split("/").filter(Boolean);
    return { page: titles[parts[0]] ? parts[0] : "fleet", arg: parts[1], q: new URLSearchParams(qs || "") };
  }

  let token = 0;
  async function render() {
    const { page, arg, q } = parse(), my = ++token;
    $$("#nav a").forEach((a) => a.classList.toggle("on", a.dataset.p === page));
    document.title = titles[page] + " · Engine health monitor";
    PM.tooltip(null);
    try {
      if (page === "machine") await PM.views.machine(arg, q.get("cutoff"));
      else if (page === "compare") await PM.views.compare(arg);
      else await PM.views[page]();
      if (my === token && page !== "machine") window.scrollTo(0, 0);
    } catch (e) {
      if (my !== token) return;
      $("#view").innerHTML = `<div class="note err"><b>Something went wrong</b><p>${esc(e.message)}</p><p>If the server was stopped, start it again with <code>python run.py</code> and reload this page.</p></div>`;
    }
  }

  async function start() {
    try {
      S.datasets = await api("datasets");
      if (!S.datasets.length) throw new Error("No trained models found. Run notebooks 01 → 02 → 03 first.");
      $("#dsSel").innerHTML = S.datasets.map((d) => `<option value="${d.id}">${d.id}${d.id === "FD001" ? " · 1 condition" : d.id === "FD004" ? " · 6 conditions" : ""}</option>`).join("");
      const saved = store("ds"), first = S.datasets.find((d) => d.id === saved) ? saved : S.datasets[0].id;
      $("#dsSel").value = first;
      await PM.loadDataset(first);
    } catch (e) { $("#view").innerHTML = `<div class="note err"><b>Cannot start</b><p>${esc(e.message)}</p></div>`; return; }
    $("#dsSel").onchange = async (e) => { try { await PM.loadDataset(e.target.value); render(); } catch (er) { toast(er.message); } };
    $("#modelSel").onchange = (e) => { S.model = e.target.value; store("model:" + S.ds, S.model); PM.fillModelSelect(); render(); };
    window.addEventListener("hashchange", render);
    render();
  }
  document.addEventListener("DOMContentLoaded", start);
})();
