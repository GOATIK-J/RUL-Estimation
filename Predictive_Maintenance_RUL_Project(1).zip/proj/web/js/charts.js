/* charts.js - small SVG chart toolkit (no dependencies). Every chart redraws when its container is resized. */
(function () {
  const NS = "http://www.w3.org/2000/svg";
  const C = { ink: "#EAF1FF", steel: "#9FB3D9", rule: "#2F4C8C", grid: "rgba(150,180,255,.13)", paper: "#112347",
              ok: "#34D399", warn: "#FFB631", crit: "#FF5A5F", cobalt: "#38D6F5", deep: "#A78BFA", classical: "#2DD4BF", ensemble: "#FF7AB8", track: "rgba(255,255,255,.14)" };
  const FAMILY = { deep: C.deep, classical: C.classical, ensemble: C.ensemble };
  const STATUS = { HEALTHY: C.ok, WARNING: C.warn, CRITICAL: C.crit };

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const f = (n, d = 1) => (n === null || n === undefined || Number.isNaN(n) ? "–" : Number(n).toFixed(d));
  function ticks(lo, hi, n = 5) {
    const span = hi - lo || 1, raw = span / n, mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw) || raw;
    const out = []; for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  }

  // ---- tooltip -----------------------------------------------------------------------------------
  let tip;
  function tooltip(html, x, y) {
    if (!tip) { tip = document.createElement("div"); tip.className = "tip"; document.body.appendChild(tip); }
    if (html === null) { tip.style.display = "none"; return; }
    tip.innerHTML = html; tip.style.display = "block";
    const w = tip.offsetWidth, h = tip.offsetHeight;
    tip.style.left = Math.min(x + 14, window.innerWidth - w - 8) + "px";
    tip.style.top = Math.max(8, Math.min(y + 14, window.innerHeight - h - 8)) + "px";
  }

  // ---- responsive wrapper --------------------------------------------------------------------------
  function mount(el, draw) {
    if (typeof el === "string") el = document.querySelector(el);
    if (!el) return;
    el.__draw = draw;
    const run = () => { const w = el.clientWidth; if (w > 20) { el.__w = w; el.innerHTML = el.__draw(w); if (el.__after) el.__after(); } };
    if (!el.__ro && window.ResizeObserver) { el.__ro = new ResizeObserver(() => { if (Math.abs(el.clientWidth - (el.__w || 0)) > 2) run(); }); el.__ro.observe(el); }
    run();
    return el;
  }
  const svg = (w, h, body, cls = "") => `<svg class="${cls}" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" role="img" xmlns="${NS}">${body}</svg>`;

  // ---- line / strip chart ----------------------------------------------------------------------------
  // opts: x[], series[{name,color,values,width,dash,area,legend}], yMin,yMax, bands[{from,to,color,label}], cursor(x value), height, yLabel, xLabel, hover(bool), animate
  function line(el, o) {
    mount(el, (W) => {
      const H = o.height || 260, m = { l: 44, r: 14, t: 12, b: 34 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
      const xs = o.x, xmin = xs[0], xmax = xs[xs.length - 1] || 1;
      const all = o.series.flatMap((s) => s.values.filter((v) => v !== null && v !== undefined));
      const ymin = o.yMin !== undefined ? o.yMin : Math.min(0, ...all), ymax = o.yMax !== undefined ? o.yMax : Math.max(...all) * 1.05;
      const X = (v) => m.l + ((v - xmin) / (xmax - xmin || 1)) * iw, Y = (v) => m.t + ih - ((v - ymin) / (ymax - ymin || 1)) * ih;
      let b = "";
      (o.bands || []).forEach((bd) => { b += `<rect x="${m.l}" y="${Y(bd.to)}" width="${iw}" height="${Math.max(0, Y(bd.from) - Y(bd.to))}" fill="${bd.color}" opacity=".17"/>`; });
      ticks(ymin, ymax, 5).forEach((t) => { b += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}" stroke="${C.grid}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end" class="ax">${t}</text>`; });
      ticks(xmin, xmax, Math.max(3, Math.floor(iw / 90))).forEach((t) => { b += `<text x="${X(t)}" y="${H - 14}" text-anchor="middle" class="ax">${t}</text>`; });
      if (o.xLabel) b += `<text x="${m.l + iw / 2}" y="${H - 1}" text-anchor="middle" class="axl">${esc(o.xLabel)}</text>`;
      if (o.yLabel) b += `<text transform="rotate(-90)" x="${-(m.t + ih / 2)}" y="11" text-anchor="middle" class="axl">${esc(o.yLabel)}</text>`;
      (o.hlines || []).forEach((h) => { b += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(h.y)}" y2="${Y(h.y)}" stroke="${h.color || C.crit}" stroke-dasharray="5 4"/><text x="${W - m.r - 4}" y="${Y(h.y) - 5}" text-anchor="end" class="ax" fill="${h.color || C.crit}">${esc(h.label || "")}</text>`; });
      o.series.forEach((s, k) => {
        const pts = xs.map((x, i) => (s.values[i] === null || s.values[i] === undefined ? null : [X(x), Y(s.values[i])])).filter(Boolean);
        if (!pts.length) return;
        const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
        if (s.area) b += `<path d="${d} L${pts[pts.length - 1][0]} ${Y(ymin)} L${pts[0][0]} ${Y(ymin)} Z" fill="${s.color}" opacity=".12"/>`;
        b += `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="${s.width || 2}" ${s.dash ? `stroke-dasharray="${s.dash}"` : ""} stroke-linejoin="round" stroke-linecap="round" ${o.animate && k === 0 ? 'class="draw" pathLength="1"' : ""}/>`;
      });
      if (o.cursor !== undefined && o.cursor !== null) b += `<line x1="${X(o.cursor)}" x2="${X(o.cursor)}" y1="${m.t}" y2="${m.t + ih}" stroke="${C.ink}" stroke-width="1.5"/><rect x="${X(o.cursor) - 3}" y="${m.t - 2}" width="6" height="6" fill="${C.ink}"/>`;
      b += `<line class="xh" x1="0" x2="0" y1="${m.t}" y2="${m.t + ih}" stroke="${C.steel}" stroke-dasharray="3 3" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${iw}" height="${ih}" fill="transparent"/>`;
      el.__after = () => {
        const hit = el.querySelector(".hit"), xh = el.querySelector(".xh"); if (!hit || o.hover === false) return;
        hit.addEventListener("mousemove", (e) => {
          const r = hit.getBoundingClientRect(), t = (e.clientX - r.left) / r.width, i = Math.round(t * (xs.length - 1));
          xh.style.display = ""; xh.setAttribute("x1", X(xs[i])); xh.setAttribute("x2", X(xs[i]));
          tooltip(`<b>${o.xName || "cycle"} ${xs[i]}</b>` + o.series.filter((s) => s.values[i] !== null && s.values[i] !== undefined).map((s) => `<div><i style="background:${s.color}"></i>${esc(s.name)} <b>${f(s.values[i], o.dec ?? 1)}</b></div>`).join(""), e.clientX, e.clientY);
        });
        hit.addEventListener("mouseleave", () => { xh.style.display = "none"; tooltip(null); });
        if (o.onClick) hit.addEventListener("click", (e) => { const r = hit.getBoundingClientRect(); o.onClick(xs[Math.round(((e.clientX - r.left) / r.width) * (xs.length - 1))]); });
      };
      return svg(W, H, b, "chart");
    });
  }

  // ---- scatter: predicted vs actual -------------------------------------------------------------------
  function scatter(el, o) {
    mount(el, (W) => {
      const H = o.height || Math.min(W, 300), m = { l: 38, r: 10, t: 10, b: 30 }, iw = W - m.l - m.r, ih = H - m.t - m.b, max = o.max || 130;
      const X = (v) => m.l + (v / max) * iw, Y = (v) => m.t + ih - (v / max) * ih;
      let b = `<polygon points="${X(0)},${Y(10)} ${X(max - 10)},${Y(max)} ${X(max)},${Y(max)} ${X(max)},${Y(max - 10)} ${X(10)},${Y(0)} ${X(0)},${Y(0)}" fill="${C.ok}" opacity=".16"/>`;
      ticks(0, max, 5).forEach((t) => { b += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}" stroke="${C.grid}"/><text x="${m.l - 6}" y="${Y(t) + 4}" text-anchor="end" class="ax">${t}</text><text x="${X(t)}" y="${H - 14}" text-anchor="middle" class="ax">${t}</text>`; });
      b += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(max)}" y2="${Y(max)}" stroke="${C.steel}" stroke-dasharray="4 4"/>`;
      b += `<text x="${m.l + iw / 2}" y="${H - 1}" text-anchor="middle" class="axl">${o.xLabel || "actual RUL"}</text><text transform="rotate(-90)" x="${-(m.t + ih / 2)}" y="10" text-anchor="middle" class="axl">${o.yLabel || "predicted RUL"}</text>`;
      o.points.forEach((p, i) => { b += `<circle cx="${X(p.x)}" cy="${Y(Math.min(p.y, max))}" r="${o.r || 3.4}" fill="${p.color || o.color || C.cobalt}" fill-opacity=".72" data-i="${i}"/>`; });
      el.__after = () => el.querySelectorAll("circle").forEach((c) => {
        const p = o.points[+c.dataset.i];
        c.addEventListener("mousemove", (e) => tooltip(`<b>${esc(p.label || "")}</b><div>actual <b>${f(p.x)}</b></div><div>predicted <b>${f(p.y)}</b></div>`, e.clientX, e.clientY));
        c.addEventListener("mouseleave", () => tooltip(null));
        if (o.onClick) c.addEventListener("click", () => o.onClick(p));
      });
      return svg(W, H, b, "chart");
    });
  }

  // ---- horizontal bars (labels left) -------------------------------------------------------------------------
  // items [{label, value, color, note}] ; opts: max, signed, dec, rowH, labelW, best(index)
  function hbar(el, items, o = {}) {
    mount(el, (W) => {
      const rowH = o.rowH || 30, lw = o.labelW || Math.min(190, W * 0.38), H = items.length * rowH + 8, iw = W - lw - 60;
      const vals = items.map((i) => i.value), lo = o.min !== undefined ? o.min : (o.signed ? Math.min(0, ...vals) : 0), hi = o.max ?? Math.max(...vals, 1e-9) * 1.08, X = (v) => lw + ((v - lo) / (hi - lo || 1)) * iw;
      let b = `<line x1="${X(Math.max(lo, 0))}" x2="${X(Math.max(lo, 0))}" y1="0" y2="${H}" stroke="${C.rule}"/>`;
      items.forEach((it, i) => {
        const y = 4 + i * rowH, x0 = X(Math.max(lo, Math.min(0, it.value))), x1 = X(Math.max(lo, Math.max(0, it.value)));
        b += `<text x="${lw - 10}" y="${y + rowH / 2 + 4}" text-anchor="end" class="bl ${it.best ? "best" : ""}">${esc(it.label)}</text>`;
        b += `<rect x="${x0}" y="${y + 5}" width="${Math.max(1, x1 - x0)}" height="${rowH - 12}" rx="2" fill="${it.color || C.cobalt}" ${it.best ? "" : 'opacity=".88"'}><title>${esc(it.label)}: ${f(it.value, o.dec ?? 2)}</title></rect>`;
        b += `<text x="${Math.max(x1, x0) + 6}" y="${y + rowH / 2 + 4}" class="bv">${f(it.value, o.dec ?? 2)}${o.unit || ""}</text>`;
      });
      return svg(W, H, b, "chart");
    });
  }

  // ---- gauge -----------------------------------------------------------------------------------------------
  function gaugeSvg(pct, color, size = 200) {
    const r = size * 0.42, cx = size / 2, cy = size * 0.56, a0 = Math.PI * 0.82, a1 = Math.PI * 0.18 + Math.PI * 2, span = a1 - a0;
    const pt = (a, rr = r) => [cx + rr * Math.cos(a), cy + rr * Math.sin(a)];
    const arc = (a, b2, rr) => { const [x1, y1] = pt(a, rr), [x2, y2] = pt(b2, rr); return `M${x1.toFixed(1)} ${y1.toFixed(1)} A${rr} ${rr} 0 ${b2 - a > Math.PI ? 1 : 0} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`; };
    const v = Math.max(0, Math.min(100, pct)) / 100, ang = a0 + span * v;
    let ticksSvg = ""; for (let i = 0; i <= 10; i++) { const a = a0 + (span * i) / 10, [x1, y1] = pt(a, r + 8), [x2, y2] = pt(a, r + (i % 5 === 0 ? 17 : 13)); ticksSvg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${C.steel}" stroke-width="${i % 5 === 0 ? 1.6 : 1}"/>`; }
    const [nx, ny] = pt(ang, r - 14);
    return svg(size, size * 0.9, `${ticksSvg}<path d="${arc(a0, a1, r)}" stroke="${C.track}" stroke-width="12" fill="none" stroke-linecap="butt"/>` +
      `<path d="${arc(a0, Math.max(a0 + 0.001, ang), r)}" stroke="${color}" stroke-width="12" fill="none"/>` +
      `<line x1="${cx}" y1="${cy}" x2="${nx}" y2="${ny}" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="5" fill="#fff"/>` +
      `<text x="${cx}" y="${cy + 38}" text-anchor="middle" class="gv">${Math.round(pct)}%</text>`, "gauge");
  }

  // ---- diverging bars for explanations ----------------------------------------------------------------------------
  function diverge(el, items, o = {}) {
    mount(el, (W) => {
      const rowH = 28, H = items.length * rowH + 6, lw = 92, mid = lw + (W - lw - 20) / 2, half = (W - lw - 20) / 2 - 36, max = Math.max(...items.map((i) => Math.abs(i.value)), 1e-9);
      let b = `<line x1="${mid}" x2="${mid}" y1="0" y2="${H}" stroke="${C.rule}"/>`;
      items.forEach((it, i) => {
        const y = 3 + i * rowH, w = (Math.abs(it.value) / max) * half, pos = it.value >= 0, col = pos ? C.crit : C.ok;
        b += `<text x="${lw - 8}" y="${y + 18}" text-anchor="end" class="bl">${esc(it.label)} <tspan class="tr">${esc(it.trend || "")}</tspan></text>`;
        b += `<rect x="${pos ? mid : mid - w}" y="${y + 5}" width="${Math.max(1, w)}" height="${rowH - 12}" rx="2" fill="${col}" opacity=".9"><title>${esc(it.label)}: ${f(it.value, 2)}</title></rect>`;
        b += `<text x="${pos ? mid + w + 5 : mid - w - 5}" y="${y + 18}" text-anchor="${pos ? "start" : "end"}" class="bv">${f(it.value, 1)}</text>`;
      });
      return svg(W, H, b, "chart");
    });
  }

  // ---- box plot rows (signed error per model) --------------------------------------------------------------------------------
  function boxes(el, rows, o = {}) {
    mount(el, (W) => {
      const rowH = 30, lw = Math.min(190, W * 0.34), H = rows.length * rowH + 44, iw = W - lw - 16, lo = o.lo ?? -40, hi = o.hi ?? 40, X = (v) => lw + ((Math.max(lo, Math.min(hi, v)) - lo) / (hi - lo)) * iw;
      let b = ticks(lo, hi, 8).map((t) => `<line x1="${X(t)}" x2="${X(t)}" y1="0" y2="${H - 38}" stroke="${t === 0 ? C.ink : C.grid}"/><text x="${X(t)}" y="${H - 24}" text-anchor="middle" class="ax">${t}</text>`).join("");
      rows.forEach((r, i) => {
        const y = 4 + i * rowH, c = r.color || C.cobalt;
        b += `<text x="${lw - 10}" y="${y + 19}" text-anchor="end" class="bl">${esc(r.label)}</text><line x1="${X(r.q[0])}" x2="${X(r.q[4])}" y1="${y + 14}" y2="${y + 14}" stroke="${c}" stroke-width="1.5"/>`;
        b += `<rect x="${X(r.q[1])}" y="${y + 5}" width="${Math.max(2, X(r.q[3]) - X(r.q[1]))}" height="18" fill="${c}" opacity=".25" stroke="${c}"/><line x1="${X(r.q[2])}" x2="${X(r.q[2])}" y1="${y + 5}" y2="${y + 23}" stroke="${c}" stroke-width="3"/>`;
      });
      b += `<text x="${lw + iw / 2}" y="${H - 2}" text-anchor="middle" class="axl">error = predicted − actual (cycles)   ·   left: too early   ·   right: too late</text>`;
      return svg(W, H + 4, b, "chart");
    });
  }

  window.PM = window.PM || {};
  Object.assign(window.PM, { C, FAMILY, STATUS, esc, f, line, scatter, hbar, gaugeSvg, diverge, boxes, tooltip, mount, ticks });
})();
