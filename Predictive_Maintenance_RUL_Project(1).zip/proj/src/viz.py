"""viz.py - all figures (matplotlib, one consistent dark industrial theme). Used by the notebooks AND the Streamlit app."""
from __future__ import annotations

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, Wedge

BG, PANEL, GRID, TEXT, MUTED = "#0e1621", "#152231", "#26374a", "#e6edf5", "#8fa3b8"
OK, WARN, CRIT, BLUE, VIOLET = "#2dd4a8", "#f5b83d", "#ef5b5b", "#4ea8ff", "#a78bfa"
STATUS_COLOR = {"HEALTHY": OK, "WARNING": WARN, "CRITICAL": CRIT}
PALETTE = [BLUE, OK, WARN, VIOLET, CRIT, "#7dd3fc", "#fb7185"]


def apply_style():
    plt.rcParams.update({
        "figure.facecolor": BG, "axes.facecolor": PANEL, "savefig.facecolor": BG, "axes.edgecolor": GRID,
        "axes.labelcolor": MUTED, "axes.titlecolor": TEXT, "axes.titleweight": "bold", "axes.titlesize": 12,
        "xtick.color": MUTED, "ytick.color": MUTED, "text.color": TEXT, "grid.color": GRID, "grid.alpha": 0.6,
        "axes.grid": True, "axes.spines.top": False, "axes.spines.right": False, "legend.facecolor": PANEL,
        "legend.edgecolor": GRID, "font.size": 10, "figure.dpi": 100, "savefig.dpi": 150,
    })


apply_style()


def _finish(fig, path=None):
    if path:
        from pathlib import Path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, bbox_inches="tight")
    return fig


def fig_gauge(value, title, color=None, vmax=100, unit="%", path=None):
    fig, ax = plt.subplots(figsize=(3.2, 2.1))
    ax.axis("off"); ax.set_xlim(-1.2, 1.2); ax.set_ylim(-0.2, 1.2); ax.set_aspect("equal")
    frac = float(np.clip(value / vmax, 0, 1))
    color = color or (OK if frac > 0.55 else WARN if frac > 0.25 else CRIT)
    ax.add_patch(Wedge((0, 0), 1, 0, 180, width=0.22, color=GRID))
    ax.add_patch(Wedge((0, 0), 1, 180 - 180 * frac, 180, width=0.22, color=color))
    txt = f"{value:.0f}{unit}" if vmax > 1.5 else f"{value:.2f}"
    ax.text(0, 0.30, txt, ha="center", va="center", fontsize=21, fontweight="bold", color=TEXT)
    ax.text(0, -0.05, title, ha="center", va="center", fontsize=9, color=MUTED)
    return _finish(fig, path)


def fig_status_donut(counts: dict, path=None):
    fig, ax = plt.subplots(figsize=(4, 3.4))
    order = ["HEALTHY", "WARNING", "CRITICAL"]
    vals = [counts.get(k, 0) for k in order]
    ax.pie(vals, colors=[STATUS_COLOR[k] for k in order], startangle=90, counterclock=False, wedgeprops=dict(width=0.38, edgecolor=BG),
           labels=[f"{k}\n{v}" for k, v in zip(order, vals)], textprops=dict(color=TEXT, fontsize=9))
    ax.set_title("Fleet status"); ax.grid(False)
    return _finish(fig, path)


def fig_rul_timeline(cycles, pred, true_capped=None, cap=125, cutoff=None, title="Predicted RUL over the machine's life", path=None):
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.axhspan(0, 30, color=CRIT, alpha=0.10); ax.axhspan(30, 70, color=WARN, alpha=0.08); ax.axhspan(70, cap + 5, color=OK, alpha=0.06)
    if true_capped is not None:
        ax.plot(cycles, true_capped, color=MUTED, lw=2, ls="--", label="True RUL (capped)")
    ax.plot(cycles, pred, color=BLUE, lw=2.2, label="Predicted RUL")
    if cutoff is not None:
        ax.axvline(cutoff, color=TEXT, lw=1, ls=":"); ax.text(cutoff, cap, " now", color=TEXT, va="top", fontsize=9)
    ax.set_ylim(0, cap + 5); ax.set_xlabel("Operating cycle"); ax.set_ylabel("RUL (cycles)"); ax.set_title(title); ax.legend(loc="upper right")
    return _finish(fig, path)


def fig_anomaly_timeline(cycles, scores, cutoff=None, title="Anomaly score over time", path=None):
    fig, ax = plt.subplots(figsize=(9, 2.8))
    ax.fill_between(cycles, scores, color=VIOLET, alpha=0.25); ax.plot(cycles, scores, color=VIOLET, lw=2)
    ax.axhline(0.5, color=CRIT, ls="--", lw=1.2); ax.text(np.min(cycles), 0.53, "alarm threshold", color=CRIT, fontsize=8)
    if cutoff is not None:
        ax.axvline(cutoff, color=TEXT, lw=1, ls=":")
    ax.set_ylim(0, 1.02); ax.set_xlabel("Operating cycle"); ax.set_ylabel("Anomaly score"); ax.set_title(title)
    return _finish(fig, path)


def fig_sensor_trends(cycles, series: dict, cutoff=None, title="Key sensor trends (standardised per operating condition)", path=None):
    fig, ax = plt.subplots(figsize=(9, 3.4))
    for i, (name, y) in enumerate(series.items()):
        ax.plot(cycles, y, lw=1.8, color=PALETTE[i % len(PALETTE)], label=name)
    if cutoff is not None:
        ax.axvline(cutoff, color=TEXT, lw=1, ls=":")
    ax.set_xlabel("Operating cycle"); ax.set_ylabel("z-score"); ax.set_title(title); ax.legend(ncol=max(1, len(series)), loc="upper left", fontsize=8)
    return _finish(fig, path)


def fig_importance(names, values, title="Why this prediction? (sensor contribution)", top=8, path=None):
    names, values = np.asarray(list(names)), np.asarray(list(values), float)
    idx = np.argsort(-np.abs(values))[:top][::-1]
    fig, ax = plt.subplots(figsize=(6, 3.5))
    ax.barh(names[idx], values[idx], color=[CRIT if v > 0 else BLUE for v in values[idx]])
    ax.axvline(0, color=MUTED, lw=1); ax.set_xlabel("contribution to a SHORTER remaining life (red) / longer (blue)"); ax.set_title(title, fontsize=10)
    return _finish(fig, path)


def fig_pred_vs_true(y_true, y_pred, title="Predicted vs actual RUL", path=None):
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    fig, axs = plt.subplots(1, 2, figsize=(10, 4), gridspec_kw={"width_ratios": [1.3, 1]})
    err = y_pred - y_true
    axs[0].scatter(y_true, y_pred, c=np.where(np.abs(err) <= 10, OK, np.where(np.abs(err) <= 20, WARN, CRIT)), s=26, alpha=0.85, edgecolor="none")
    m = max(y_true.max(), y_pred.max()) + 5
    axs[0].plot([0, m], [0, m], color=MUTED, ls="--", lw=1.2); axs[0].fill_between([0, m], [-10, m - 10], [10, m + 10], color=OK, alpha=0.08)
    axs[0].set_xlabel("True RUL"); axs[0].set_ylabel("Predicted RUL"); axs[0].set_title(title, fontsize=11)
    axs[1].hist(err, bins=24, color=BLUE, alpha=0.9); axs[1].axvline(0, color=TEXT, lw=1)
    axs[1].set_xlabel("error = predicted − true (cycles)"); axs[1].set_title("Error distribution (green band = ±10 cycles)", fontsize=10)
    fig.tight_layout()
    return _finish(fig, path)


def fig_model_comparison(df, metric="Test_RMSE", title=None, lower_better=True, highlight=None, path=None):
    d = df.sort_values(metric, ascending=not lower_better)
    fig, ax = plt.subplots(figsize=(6.2, max(2.8, 0.38 * len(d) + 1)))
    best = highlight or d.iloc[-1]["Model"]
    ax.barh(d["Model"], d[metric], color=[OK if m == best else BLUE for m in d["Model"]])
    for y, v in enumerate(d[metric]):
        ax.text(v, y, f" {v:.3f}" if abs(v) < 5 else f" {v:.1f}", va="center", fontsize=8, color=TEXT)
    if "R2" in metric:
        ax.set_xlim(0, 1.1); ax.axvline(0.75, color=WARN, ls="--", lw=1); ax.text(0.75, len(d) - 0.4, " target 0.75", color=WARN, fontsize=8)
    ax.set_title(title or metric, fontsize=11)
    fig.tight_layout()
    return _finish(fig, path)


def fig_generalization(train_r2, val_r2, test_r2, path=None):
    fig, ax = plt.subplots(figsize=(5, 3))
    labels, vals = ["train", "validation\n(unseen engines)", "official test\n(unseen engines)"], [train_r2, val_r2, test_r2]
    keep = [(l, v) for l, v in zip(labels, vals) if v is not None]
    bars = ax.bar([l for l, _ in keep], [v for _, v in keep], color=[BLUE, VIOLET, OK][: len(keep)], width=0.55)
    for b, (_, v) in zip(bars, keep):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.01, f"{v:.3f}", ha="center", fontsize=10, fontweight="bold")
    ax.set_ylim(0, 1.1); ax.set_ylabel("R²"); ax.set_title("Generalisation check"); ax.axhline(0.75, color=WARN, ls="--", lw=1)
    return _finish(fig, path)


def fig_training_curves(histories: dict, path=None):
    fig, ax = plt.subplots(figsize=(8, 3.6))
    for i, (name, h) in enumerate(histories.items()):
        ax.plot(h["loss"], color=PALETTE[i % 7], lw=1.3, alpha=0.7); ax.plot(h["val_loss"], color=PALETTE[i % 7], lw=2, ls="--", label=name)
    ax.set_yscale("log"); ax.set_xlabel("epoch"); ax.set_ylabel("Huber loss  (solid = train, dashed = validation)")
    ax.set_title("Learning curves"); ax.legend(fontsize=8, ncol=2)
    return _finish(fig, path)


def fig_pipeline(path=None):
    fig, ax = plt.subplots(figsize=(13, 3.4)); ax.axis("off"); ax.set_xlim(0, 13); ax.set_ylim(0, 3.4)
    boxes = [("Industrial\nmachine\n(21 sensors)", BLUE), ("Preprocessing\nper-condition z-score\nsmoothing", BLUE), ("Time windows\n30–40 cycles", BLUE),
             ("Deep model\n1D-CNN → BiLSTM\n→ Attention", VIOLET), ("RUL\nprediction", OK), ("Health +\nAnomaly +\nExplanation", WARN), ("Dashboard\n+ API", CRIT)]
    for i, (t, c) in enumerate(boxes):
        x = 0.15 + i * 1.85
        ax.add_patch(FancyBboxPatch((x, 0.8), 1.55, 1.8, boxstyle="round,pad=0.04,rounding_size=0.12", fc=PANEL, ec=c, lw=2))
        ax.text(x + 0.775, 1.7, t, ha="center", va="center", fontsize=8.6, color=TEXT)
        if i < len(boxes) - 1:
            ax.annotate("", (x + 1.85, 1.7), (x + 1.58, 1.7), arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.5))
    ax.text(6.5, 3.05, "Predictive-maintenance pipeline: from raw sensor data to explainable machine-health intelligence", ha="center", fontsize=11, fontweight="bold")
    ax.text(6.5, 0.3, "Baselines (Ridge · RandomForest · ExtraTrees · GradientBoosting) and 6 Keras architectures are compared on the same split",
            ha="center", fontsize=9, color=MUTED)
    return _finish(fig, path)
