"""
rul_core.py  -  data loading, preprocessing, windowing, metrics, anomaly detection.

Pure NumPy / pandas / scikit-learn (NO TensorFlow here), so every step of Phase 1
and Phase 2 can be run, tested and explained without a deep-learning framework.

Dataset : NASA C-MAPSS turbofan engine degradation (FD001 ... FD004).
Task    : given the last `window` cycles of sensor readings, predict Remaining Useful Life (RUL).
"""
from __future__ import annotations

import io
import json
import re
import shutil
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
RUL_CAP = 125                      # piece-wise linear RUL target (standard practice for C-MAPSS)
ID_COLS = ["unit_id", "cycle"]
SETTING_COLS = [f"setting_{i}" for i in range(1, 4)]
SENSOR_COLS = [f"sensor_{i}" for i in range(1, 22)]
ALL_COLS = ID_COLS + SETTING_COLS + SENSOR_COLS

# Per-dataset configuration. FD002/FD004 have 6 operating conditions -> need per-condition normalisation.
DATASET_CFG = {
    "FD001": dict(n_conditions=1, window=30, train_stride=1, use_cycle=False, description="1 operating condition, 1 fault mode (HPC)"),
    "FD002": dict(n_conditions=6, window=40, train_stride=2, use_cycle=True, description="6 operating conditions, 1 fault mode"),
    "FD003": dict(n_conditions=1, window=30, train_stride=1, use_cycle=False, description="1 operating condition, 2 fault modes"),
    "FD004": dict(n_conditions=6, window=40, train_stride=2, use_cycle=True, description="6 operating conditions, 2 fault modes (hardest)"),
}

SENSOR_INFO = {  # official C-MAPSS sensor descriptions
    "sensor_1": ("T2", "Total temperature at fan inlet"), "sensor_2": ("T24", "Total temperature at LPC outlet"),
    "sensor_3": ("T30", "Total temperature at HPC outlet"), "sensor_4": ("T50", "Total temperature at LPT outlet"),
    "sensor_5": ("P2", "Pressure at fan inlet"), "sensor_6": ("P15", "Total pressure in bypass duct"),
    "sensor_7": ("P30", "Total pressure at HPC outlet"), "sensor_8": ("Nf", "Physical fan speed"),
    "sensor_9": ("Nc", "Physical core speed"), "sensor_10": ("epr", "Engine pressure ratio"),
    "sensor_11": ("Ps30", "Static pressure at HPC outlet"), "sensor_12": ("phi", "Ratio of fuel flow to Ps30"),
    "sensor_13": ("NRf", "Corrected fan speed"), "sensor_14": ("NRc", "Corrected core speed"),
    "sensor_15": ("BPR", "Bypass ratio"), "sensor_16": ("farB", "Burner fuel-air ratio"),
    "sensor_17": ("htBleed", "Bleed enthalpy"), "sensor_18": ("Nf_dmd", "Demanded fan speed"),
    "sensor_19": ("PCNfR_dmd", "Demanded corrected fan speed"), "sensor_20": ("W31", "HPT coolant bleed"),
    "sensor_21": ("W32", "LPT coolant bleed"),
}
# Groups used by the dashboard (C-MAPSS has no vibration sensor; fan/core speed is the rotating-machinery analogue)
SENSOR_GROUPS = {
    "Temperature": ["sensor_2", "sensor_3", "sensor_4"],
    "Pressure": ["sensor_7", "sensor_11", "sensor_6"],
    "Speed / Vibration proxy": ["sensor_8", "sensor_9", "sensor_13", "sensor_14"],
    "Flow / Fuel": ["sensor_12", "sensor_15", "sensor_20", "sensor_21"],
}

DATA_URLS = [
    "https://data.nasa.gov/docs/legacy/CMAPSSData.zip",
    "https://phm-datasets.s3.amazonaws.com/NASA/6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip",
]
_FILE_RE = re.compile(r"^(train|test|RUL)_FD00[1-4]\.txt$")


# ----------------------------------------------------------------------------------------------
# 1. Data acquisition and loading
# ----------------------------------------------------------------------------------------------
def find_cmapss_files(root) -> dict:
    """Return {filename: path} for every C-MAPSS text file found below `root`."""
    root = Path(root)
    return {p.name: p for p in root.rglob("*.txt") if _FILE_RE.match(p.name)} if root.exists() else {}


def _extract_recursive(zip_bytes: bytes, dest: Path, depth: int = 0) -> None:
    """Extract a zip; if it contains further zips (the NASA mirror does), extract those too."""
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for name in zf.namelist():
            data = zf.read(name)
            if name.lower().endswith(".zip") and depth < 3:
                _extract_recursive(data, dest, depth + 1)
            elif name.lower().endswith(".txt"):
                (dest / Path(name).name).write_bytes(data)


def ensure_dataset(data_dir, datasets=("FD001", "FD004"), verbose=True) -> dict:
    """
    Make sure the C-MAPSS text files exist in `data_dir`.
    Order: (1) already present -> done, (2) a CMAPSSData*.zip placed in data_dir, (3) download from NASA mirrors.
    Raises a FileNotFoundError with plain instructions if everything fails.
    """
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    need = [f"{p}_{d}.txt" for d in datasets for p in ("train", "test", "RUL")]

    def complete():
        found = find_cmapss_files(data_dir)
        return all(n in found for n in need), found

    ok, found = complete()
    if ok:
        if verbose:
            print(f"Dataset already available in {data_dir}")
        return found

    for z in sorted(data_dir.rglob("*.zip")):                       # (2) user-supplied zip
        try:
            _extract_recursive(z.read_bytes(), data_dir)
            ok, found = complete()
            if ok:
                if verbose:
                    print(f"Extracted dataset from {z.name}")
                return found
        except zipfile.BadZipFile:
            pass

    try:                                                            # (3) download
        import requests
    except ImportError:
        requests = None
    if requests is not None:
        for url in DATA_URLS:
            try:
                if verbose:
                    print("Trying", url)
                r = requests.get(url, timeout=(15, 180))
                r.raise_for_status()
                _extract_recursive(r.content, data_dir)
                ok, found = complete()
                if ok:
                    if verbose:
                        print("Download OK")
                    return found
            except Exception as exc:                                # network problems are expected sometimes
                if verbose:
                    print(f"  failed: {type(exc).__name__}: {str(exc)[:100]}")
    raise FileNotFoundError(
        "C-MAPSS files not found and automatic download failed.\n"
        "FIX (30 seconds): download 'CMAPSSData.zip' from NASA (search: 'NASA C-MAPSS turbofan dataset'),\n"
        f"and put the ZIP (or the extracted .txt files) inside:  {data_dir.resolve()}\n"
        "Then re-run this cell. In Google Colab: use the Files panel (left) -> drag the ZIP into data/raw."
    )


def read_table(path) -> pd.DataFrame:
    df = pd.read_csv(path, sep=r"\s+", header=None).dropna(axis=1, how="all")
    if df.shape[1] != len(ALL_COLS):
        raise ValueError(f"{Path(path).name}: expected {len(ALL_COLS)} columns, found {df.shape[1]}")
    df.columns = ALL_COLS
    df["unit_id"] = df["unit_id"].astype(int)
    df["cycle"] = df["cycle"].astype(int)
    return df.sort_values(["unit_id", "cycle"]).reset_index(drop=True)


def load_subset(files: dict, code: str):
    """Return (train_df, test_df, test_rul_array) for 'FD001'..'FD004'."""
    train = read_table(files[f"train_{code}.txt"])
    test = read_table(files[f"test_{code}.txt"])
    rul = pd.read_csv(files[f"RUL_{code}.txt"], sep=r"\s+", header=None).dropna(axis=1, how="all").iloc[:, 0].to_numpy(float)
    if len(rul) != test["unit_id"].nunique():
        raise ValueError(f"{code}: {len(rul)} RUL labels but {test['unit_id'].nunique()} test engines")
    return train, test, rul


def add_rul(train: pd.DataFrame, cap: float = RUL_CAP) -> pd.DataFrame:
    """RUL = (last cycle of the engine) - (current cycle); capped at `cap` (early life = 'healthy plateau')."""
    out = train.copy()
    out["RUL_raw"] = out.groupby("unit_id")["cycle"].transform("max") - out["cycle"]
    out["RUL"] = out["RUL_raw"].clip(upper=cap)
    return out


def split_engines(unit_ids, val_fraction=0.2, seed=SEED):
    """Split by ENGINE (never by row) so no engine is in both train and validation -> no leakage."""
    rng = np.random.RandomState(seed)
    ids = np.array(sorted(unit_ids))
    rng.shuffle(ids)
    n_val = max(1, int(round(len(ids) * val_fraction)))
    return np.sort(ids[n_val:]), np.sort(ids[:n_val])


# ----------------------------------------------------------------------------------------------
# 2. Preprocessing  (fit on TRAIN engines only)
# ----------------------------------------------------------------------------------------------
class Preprocessor:
    """
    Steps (all parameters are learnt on training engines only and stored as plain numbers -> JSON):
      1. operating-condition detection (k-means on the 3 settings) for multi-condition sets (FD002/FD004)
      2. per-condition z-score of every sensor   (removes the effect of altitude / speed / throttle)
      3. drop sensors that are constant (carry no information)
      4. causal exponential smoothing per engine (denoises without looking into the future)
      5. optional 'cycle' feature (operating hours so far - always known at prediction time)
    """

    def __init__(self, n_conditions=1, smooth_span=5, use_cycle=True, cap=RUL_CAP, window=30):
        self.n_conditions, self.smooth_span, self.use_cycle = n_conditions, smooth_span, use_cycle
        self.cap, self.window = cap, window

    # -- operating conditions -------------------------------------------------
    def _cond(self, df):
        if self.n_conditions == 1:
            return np.zeros(len(df), dtype=int)
        s = (df[SETTING_COLS].to_numpy(float) - self.set_mu) / self.set_sd
        d = ((s[:, None, :] - self.centers[None, :, :]) ** 2).sum(-1)
        return d.argmin(1)

    def fit(self, train_df: pd.DataFrame):
        if self.n_conditions > 1:
            from sklearn.cluster import KMeans
            S = train_df[SETTING_COLS].to_numpy(float)
            self.set_mu, self.set_sd = S.mean(0), S.std(0) + 1e-8
            km = KMeans(self.n_conditions, n_init=10, random_state=SEED).fit((S - self.set_mu) / self.set_sd)
            self.centers = km.cluster_centers_
        cond = self._cond(train_df)
        X = train_df[SENSOR_COLS].to_numpy(float)
        C = self.n_conditions
        mu, sd = np.zeros((C, X.shape[1])), np.ones((C, X.shape[1]))
        for c in range(C):
            m = cond == c
            if m.sum() > 1:
                mu[c], sd[c] = X[m].mean(0), X[m].std(0)
        keep = sd.max(0) > 1e-6
        self.sensors = [s for s, k in zip(SENSOR_COLS, keep) if k]
        self._keep = keep
        self.mu, self.sd = mu, np.where(sd < 1e-6, 1.0, sd)
        self.cycle_scale = float(train_df["cycle"].max())
        return self

    @property
    def features(self):
        return self.sensors + (["cycle"] if self.use_cycle else [])

    @property
    def n_features(self):
        return len(self.features)

    # -- transform --------------------------------------------------------------
    def transform_engine(self, df: pd.DataFrame) -> np.ndarray:
        """df = rows of ONE engine sorted by cycle -> (n_cycles, n_features) float32."""
        cond = self._cond(df)
        X = df[SENSOR_COLS].to_numpy(float)
        Z = ((X - self.mu[cond]) / self.sd[cond])[:, self._keep]
        if self.smooth_span > 1:
            Z = pd.DataFrame(Z).ewm(span=self.smooth_span, adjust=False).mean().to_numpy()
        if self.use_cycle:
            Z = np.column_stack([Z, df["cycle"].to_numpy(float) / self.cycle_scale])
        return Z.astype(np.float32)

    def sensor_part(self, feat: np.ndarray) -> np.ndarray:
        return feat[:, : len(self.sensors)]

    # -- (de)serialisation -----------------------------------------------------
    def to_dict(self):
        d = dict(n_conditions=self.n_conditions, smooth_span=self.smooth_span, use_cycle=self.use_cycle, cap=self.cap,
                 window=self.window, sensors=self.sensors, keep=self._keep.tolist(), mu=self.mu.tolist(),
                 sd=self.sd.tolist(), cycle_scale=self.cycle_scale)
        if self.n_conditions > 1:
            d.update(set_mu=self.set_mu.tolist(), set_sd=self.set_sd.tolist(), centers=self.centers.tolist())
        return d

    @classmethod
    def from_dict(cls, d):
        p = cls(d["n_conditions"], d["smooth_span"], d["use_cycle"], d["cap"], d["window"])
        p.sensors, p._keep = d["sensors"], np.array(d["keep"], dtype=bool)
        p.mu, p.sd, p.cycle_scale = np.array(d["mu"]), np.array(d["sd"]), d["cycle_scale"]
        if p.n_conditions > 1:
            p.set_mu, p.set_sd, p.centers = np.array(d["set_mu"]), np.array(d["set_sd"]), np.array(d["centers"])
        return p


# ----------------------------------------------------------------------------------------------
# 3. Sliding windows
# ----------------------------------------------------------------------------------------------
def pad_front(feat: np.ndarray, window: int) -> np.ndarray:
    """Repeat the first row so that every cycle (even cycle 1) has a full window of history."""
    return np.vstack([np.repeat(feat[:1], window - 1, axis=0), feat])


def engine_windows(feat: np.ndarray, window: int) -> np.ndarray:
    """All windows of one engine: window i ends at cycle i  -> (n_cycles, window, F)."""
    padded = pad_front(feat, window)
    w = np.lib.stride_tricks.sliding_window_view(padded, window, axis=0)   # (n, F, window)
    return np.ascontiguousarray(w.transpose(0, 2, 1))


def build_windows(prep: Preprocessor, df: pd.DataFrame, window: int, stride: int = 1):
    """Training/validation windows for labelled engines. Returns X, y(capped), y_raw, unit, cycle."""
    X, y, yr, u, c = [], [], [], [], []
    for uid, g in df.groupby("unit_id", sort=True):
        g = g.sort_values("cycle")
        W = engine_windows(prep.transform_engine(g), window)
        idx = np.arange(len(g) - 1, -1, -stride)[::-1]              # always keep the last cycle of the engine
        X.append(W[idx]); y.append(g["RUL"].to_numpy()[idx]); yr.append(g["RUL_raw"].to_numpy()[idx])
        u.append(np.full(len(idx), uid)); c.append(g["cycle"].to_numpy()[idx])
    return (np.concatenate(X).astype(np.float32), np.concatenate(y).astype(np.float32),
            np.concatenate(yr).astype(np.float32), np.concatenate(u), np.concatenate(c))


def build_test_windows(prep: Preprocessor, test_df: pd.DataFrame, rul_true: np.ndarray, window: int):
    """One window per test engine: its LAST `window` observed cycles (this is the official C-MAPSS protocol)."""
    X, units, last = [], [], []
    for uid, g in test_df.groupby("unit_id", sort=True):
        g = g.sort_values("cycle")
        X.append(engine_windows(prep.transform_engine(g), window)[-1]); units.append(uid); last.append(int(g["cycle"].max()))
    return np.stack(X).astype(np.float32), np.asarray(rul_true, dtype=np.float32), np.array(units), np.array(last)


# ----------------------------------------------------------------------------------------------
# 4. Metrics
# ----------------------------------------------------------------------------------------------
def nasa_score(y_true, y_pred):
    """Asymmetric PHM08 score: late predictions (pred > true) are penalised more. Lower is better."""
    d = np.asarray(y_pred, float) - np.asarray(y_true, float)
    return float(np.sum(np.where(d < 0, np.exp(-d / 13.0) - 1.0, np.exp(d / 10.0) - 1.0)))


def regression_metrics(y_true, y_pred) -> dict:
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    err = y_pred - y_true
    ss_res, ss_tot = float(np.sum(err ** 2)), float(np.sum((y_true - y_true.mean()) ** 2))
    return {"MAE": float(np.mean(np.abs(err))), "RMSE": float(np.sqrt(np.mean(err ** 2))),
            "R2": 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan"),
            "NASA_score": nasa_score(y_true, y_pred), "Within_10_cycles_%": float(np.mean(np.abs(err) <= 10) * 100)}


def classification_metrics(y_true, y_pred, y_score=None) -> dict:
    from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
    p, r, f, _ = precision_recall_fscore_support(y_true, y_pred, average="binary", zero_division=0)
    out = {"Precision": float(p), "Recall": float(r), "F1": float(f)}
    if y_score is not None and len(np.unique(y_true)) == 2:
        out["ROC_AUC"] = float(roc_auc_score(y_true, y_score))
    return out


# ----------------------------------------------------------------------------------------------
# 5. Classical (non-deep) baselines: hand-crafted window statistics
# ----------------------------------------------------------------------------------------------
def flat_features(X: np.ndarray) -> np.ndarray:
    """(N, T, F) window -> (N, 9F) statistics: last, mean, std, min, max, slope, mean-of-last-5, 10-step and 20-step change."""
    N, T, F = X.shape
    t = np.arange(T, dtype=np.float32) - (T - 1) / 2
    slope = (X * t[None, :, None]).sum(1) / (t ** 2).sum()
    d10 = X[:, -1] - X[:, max(0, T - 10)]
    d20 = X[:, -1] - X[:, max(0, T - 20)]
    return np.concatenate([X[:, -1], X.mean(1), X.std(1), X.min(1), X.max(1), slope, X[:, -5:].mean(1), d10, d20], axis=1)


def flat_feature_names(names):
    return [f"{n}__{s}" for s in ("last", "mean", "std", "min", "max", "slope", "last5", "d10", "d20") for n in names]


# ----------------------------------------------------------------------------------------------
# 6. Anomaly detection (unsupervised): Mahalanobis distance from the engine's HEALTHY behaviour
# ----------------------------------------------------------------------------------------------
class AnomalyDetector:
    """
    Learns the normal (healthy) sensor distribution from the first part of each training engine's life.
    distance = Mahalanobis distance of the current (smoothed, condition-normalised) sensor vector.
    score in [0,1):  r = distance / alarm-distance ;  score = r^2/(1+r^2)  (0.5 == alarm threshold; the alarm distance is
    first set to the healthy 99.5th percentile and then calibrated on validation engines)
    """

    def __init__(self, healthy_fraction=0.25, quantile=0.995):
        self.healthy_fraction, self.quantile = healthy_fraction, quantile

    def fit(self, healthy_rows: np.ndarray):
        self.mu = healthy_rows.mean(0)
        cov = np.cov(healthy_rows.T) + np.eye(healthy_rows.shape[1]) * 1e-3
        self.prec = np.linalg.inv(cov)
        self.thr = float(np.quantile(self.distance(healthy_rows), self.quantile))
        return self

    def distance(self, rows):
        d = rows - self.mu
        return np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", d, self.prec, d), 0.0))

    def score(self, rows):
        r = self.distance(rows) / max(self.thr, 1e-9)
        return r ** 2 / (1.0 + r ** 2)

    def calibrate(self, rows, labels):
        """Choose the alarm threshold that maximises F1 on VALIDATION engines (label 1 = degraded). Returns (F1, threshold)."""
        d, labels = self.distance(rows), np.asarray(labels).astype(bool)
        best = (-1.0, self.thr)
        for t in np.quantile(d, np.linspace(0.05, 0.98, 150)):
            p = d > t
            tp, fp, fn = int((p & labels).sum()), int((p & ~labels).sum()), int((~p & labels).sum())
            f1 = 2 * tp / max(2 * tp + fp + fn, 1)
            if f1 >= best[0]:
                best = (f1, float(t))
        self.thr = best[1]
        return best

    def to_dict(self):
        return dict(mu=self.mu.tolist(), prec=self.prec.tolist(), thr=self.thr)

    @classmethod
    def from_dict(cls, d):
        o = cls(); o.mu, o.prec, o.thr = np.array(d["mu"]), np.array(d["prec"]), d["thr"]
        return o


def warmup_fix(scores, n=20):
    """The smoothing needs ~n cycles to forget its (noisy) first reading, so early anomaly scores are unreliable:
    cap them at the value reached at cycle n."""
    s = np.array(scores, dtype=float).copy()
    if len(s) > n:
        s[:n] = np.minimum(s[:n], s[n])
    return s


def healthy_rows_from_train(prep: Preprocessor, train_df: pd.DataFrame, fraction=0.25) -> np.ndarray:
    rows = []
    for _, g in train_df.groupby("unit_id"):
        f = prep.sensor_part(prep.transform_engine(g.sort_values("cycle")))
        rows.append(f[: max(5, int(len(f) * fraction))])
    return np.vstack(rows)


# ----------------------------------------------------------------------------------------------
# 7. Health indicators used by the dashboard
# ----------------------------------------------------------------------------------------------
def health_percent(rul, cap=RUL_CAP):
    return float(np.clip(rul / cap, 0, 1) * 100)


def status_from_rul(rul):
    return "HEALTHY" if rul >= 70 else ("WARNING" if rul >= 30 else "CRITICAL")


ACTIONS = {
    "HEALTHY": "Normal operation. Continue routine monitoring.",
    "WARNING": "Schedule maintenance inspection within the next operating window.",
    "CRITICAL": "Immediate maintenance required. Remove from service as soon as possible.",
}


def trend_arrow(series, lookback=15, thr=0.05):
    s = np.asarray(series, float)[-lookback:]
    if len(s) < 3:
        return "→"
    slope = np.polyfit(np.arange(len(s)), s, 1)[0] * lookback
    return "↗" if slope > thr else ("↘" if slope < -thr else "→")


def save_json(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))


def load_json(path):
    return json.loads(Path(path).read_text())
