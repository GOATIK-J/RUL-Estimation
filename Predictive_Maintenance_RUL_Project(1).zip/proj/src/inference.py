"""
inference.py - load the trained pipeline and produce predictions / dashboard artefacts.
Used by the notebooks (Phase 3 export), the FastAPI backend and the Streamlit app.
Works with Keras members (if TensorFlow is installed) and scikit-learn members.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from src.rul_core import (ACTIONS, SENSOR_INFO, AnomalyDetector, Preprocessor, SENSOR_COLS, SETTING_COLS, engine_windows,
                          flat_features, health_percent, warmup_fix, load_json, status_from_rul, trend_arrow)


class Predictor:
    """artifacts/final/<FDxxx>/  ->  callable RUL predictor with anomaly score and explanations."""

    def __init__(self, art_dir):
        self.dir = Path(art_dir)
        self.meta = load_json(self.dir / "meta.json")
        self.prep = Preprocessor.from_dict(load_json(self.dir / "prep.json"))
        self.anom = AnomalyDetector.from_dict(load_json(self.dir / "anomaly.json"))
        self.window, self.cap = self.meta["window"], self.meta["cap"]
        self._members = None

    # ---- model loading --------------------------------------------------------
    def _load_members(self):
        if self._members is not None:
            return
        members, weights = [], []
        for m in self.meta["final_model"]["members"]:
            weights.append(float(m.get("weight", 1.0)))
            if m["kind"] == "sklearn":
                import joblib
                members.append(("sklearn", joblib.load(self.dir / m["file"])))
            else:
                from src import rul_models as RM
                if not RM.HAS_TF:
                    raise RuntimeError("This saved model needs TensorFlow (pip install tensorflow).")
                members.append(("keras", RM.load_model(m["arch"], self.window, self.prep.n_features, self.dir / m["file"], **m.get("kw", {}))))
        self._members, self._weights = members, weights

    def predict_windows(self, X):
        """X (N, window, F) -> RUL estimates (N,) = average of all ensemble members."""
        self._load_members()
        total, out = 0.0, 0.0
        for (kind, model), w in zip(self._members, self._weights):
            if kind == "sklearn":
                p = np.clip(model.predict(flat_features(X)), 0, self.cap)
            else:
                p = np.clip(model.predict(X, batch_size=1024, verbose=0).ravel() * self.cap, 0, self.cap)
            out = out + w * p
            total += w
        return out / total

    # ---- per-engine API ---------------------------------------------------------
    def timeline(self, df_engine: pd.DataFrame) -> pd.DataFrame:
        """Predicted RUL + anomaly score at EVERY cycle of one engine (only past data used at each cycle)."""
        g = df_engine.sort_values("cycle")
        feat = self.prep.transform_engine(g)
        rul = self.predict_windows(engine_windows(feat, self.window))
        anom = warmup_fix(self.anom.score(self.prep.sensor_part(feat)))
        return pd.DataFrame({"cycle": g["cycle"].to_numpy(), "rul_pred": rul, "anomaly_score": anom,
                             "health_pct": np.clip(rul / self.cap, 0, 1) * 100})

    def assess(self, df_raw: pd.DataFrame) -> dict:
        """Raw sensor history of ONE machine (columns: cycle, setting_1..3, sensor_1..21) -> full health assessment."""
        df = df_raw.copy()
        missing = [c for c in ["cycle"] + SENSOR_COLS if c not in df.columns]
        if missing:
            raise ValueError(f"missing columns: {missing[:5]}")
        for c in SETTING_COLS:
            if c not in df.columns:
                df[c] = 0.0
        tl = self.timeline(df)
        last = tl.iloc[-1]
        rul = float(last["rul_pred"])
        status = status_from_rul(rul)
        return {"cycle": int(last["cycle"]), "n_cycles": int(len(tl)), "rul": rul, "health_pct": health_percent(rul, self.cap),
                "anomaly_score": float(last["anomaly_score"]), "anomaly_flag": bool(last["anomaly_score"] > 0.5),
                "status": status, "action": ACTIONS[status], "timeline": tl[["cycle", "rul_pred", "anomaly_score"]]}

    def occlusion_importance(self, X_last, feature_names=None):
        """
        Model-agnostic explanation: replace one feature of the window by its healthy value (0 after
        standardisation) and see how much the predicted RUL RISES. Large rise = that feature is pushing the RUL down.
        Returns (N, F) array of cycles.
        """
        names = feature_names or self.prep.features
        base = self.predict_windows(X_last)
        out = np.zeros((len(X_last), len(names)))
        for j in range(len(names)):
            Xo = X_last.copy()
            Xo[:, :, j] = 0.0
            out[:, j] = self.predict_windows(Xo) - base
        return out


# ------------------------------------------------------------------------------------------------
# artefacts for the dashboard (computed once after training, then the app only reads files)
# ------------------------------------------------------------------------------------------------
def export_dashboard_data(pred: Predictor, test_df: pd.DataFrame, rul_true: np.ndarray, out_dir) -> dict:
    """Per-engine predictions at EVERY cycle (using only past data), fleet table, explanations, raw test sensors."""
    out_dir = Path(out_dir)
    prep, cap = pred.prep, pred.cap
    units = np.sort(test_df["unit_id"].unique())
    tl_rows, fleet_rows, imp_rows, X_last = [], [], [], []
    for uid, true_last in zip(units, rul_true):
        g = test_df[test_df["unit_id"] == uid].sort_values("cycle")
        feat = prep.transform_engine(g)
        W = engine_windows(feat, pred.window)
        rul = pred.predict_windows(W)
        anom = warmup_fix(pred.anom.score(prep.sensor_part(feat)))
        last_cycle = int(g["cycle"].max())
        true_rul = true_last + (last_cycle - g["cycle"].to_numpy())              # true RUL at every cycle of the test history
        tl_rows.append(pd.DataFrame({"unit_id": uid, "cycle": g["cycle"].to_numpy(), "rul_pred": rul, "rul_true": true_rul,
                                     "rul_true_capped": np.minimum(true_rul, cap), "anomaly_score": anom}))
        X_last.append(W[-1])
        r = float(rul[-1]); st = status_from_rul(r)
        fleet_rows.append({"unit_id": int(uid), "cycles_observed": last_cycle, "rul_pred": r, "rul_true": float(true_last),
                           "rul_true_capped": float(min(true_last, cap)), "abs_error": abs(r - min(true_last, cap)),
                           "health_pct": health_percent(r, cap), "anomaly_score": float(anom[-1]), "status": st, "action": ACTIONS[st]})
    X_last = np.stack(X_last)
    contrib = pred.occlusion_importance(X_last)
    for i, uid in enumerate(units):
        for j, f in enumerate(prep.features):
            z = X_last[i, :, j]
            imp_rows.append({"unit_id": int(uid), "feature": f, "label": SENSOR_INFO.get(f, ("cycles run",))[0],
                             "contribution": float(contrib[i, j]), "z_last": float(z[-1]), "trend": trend_arrow(z)})
    timelines, fleet, imp = pd.concat(tl_rows, ignore_index=True), pd.DataFrame(fleet_rows), pd.DataFrame(imp_rows)
    timelines.round(4).to_csv(out_dir / "timelines.csv.gz", index=False)
    fleet.round(4).to_csv(out_dir / "fleet_summary.csv", index=False)
    imp.round(4).to_csv(out_dir / "engine_importance.csv", index=False)
    test_df[["unit_id", "cycle"] + SETTING_COLS + SENSOR_COLS].to_csv(out_dir / "test_sensors.csv.gz", index=False)
    return {"timelines": timelines, "fleet": fleet, "importance": imp}
