"""
zoo.py - the MODEL ZOO: every selectable model (classical + Keras deep learning + ensembles) with
metrics, per-engine predictions over time and per-engine explanations.  The web UI reads these files, so a user can
pick a model BEFORE predicting and compare deep learning against classical ML on identical engines.

    build_zoo(root, "FD001")                  -> artifacts/zoo/FD001/{index.json, timelines.csv.gz, importance.csv.gz}
    train_deep_suite(root, "FD001")           -> trains Keras models (TensorFlow) into artifacts/models/FD001/
    ZooPredictor(root, "FD001", model_id)     -> live predictions for the API

Framework: TensorFlow / Keras only for deep models (no PyTorch).  Classical models use scikit-learn.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from src.rul_core import (ACTIONS, RUL_CAP, AnomalyDetector, Preprocessor, engine_windows, flat_features, health_percent,
                          load_json, regression_metrics, save_json, status_from_rul, warmup_fix)

MODEL_KW = dict(units=64, filters=64, dropout=0.2, l2=1e-5, noise=0.03, lr=1e-3)   # must match training
DEEP_ARCHS = ["mlp", "lstm", "gru", "bilstm", "cnn_lstm", "cnn_lstm_attention"]
CLASSICAL = ["Ridge", "RandomForest", "ExtraTrees", "HistGradientBoosting"]
PRETTY = {"mlp": "MLP (dense network)", "lstm": "LSTM", "gru": "GRU", "bilstm": "BiLSTM", "cnn_lstm": "CNN-LSTM",
          "cnn_lstm_attention": "CNN-BiLSTM-Attention", "Ridge": "Ridge regression", "RandomForest": "Random Forest",
          "ExtraTrees": "Extra Trees", "HistGradientBoosting": "Gradient Boosting"}
DESC = {"mlp": "Flatten + dense layers. No notion of time order: the control experiment.",
        "lstm": "Recurrent network that reads the window step by step.",
        "gru": "Lighter recurrent network, similar idea to LSTM.",
        "bilstm": "LSTM reading the window forwards and backwards.",
        "cnn_lstm": "1D convolutions find local sensor patterns, an LSTM models how they evolve.",
        "cnn_lstm_attention": "CNN + BiLSTM + temporal attention: learns which time steps matter. The proposed model.",
        "Ridge": "Linear model on window statistics. The simplest baseline.",
        "RandomForest": "Many decision trees on window statistics.",
        "ExtraTrees": "Randomised trees on window statistics.",
        "HistGradientBoosting": "Boosted trees on window statistics."}


def paths(root, ds):
    root = Path(root)
    return dict(root=root, proc=root / "data" / "processed" / ds, models=root / "artifacts" / "models" / ds,
                final=root / "artifacts" / "final" / ds, zoo=root / "artifacts" / "zoo" / ds)


def has_tensorflow() -> bool:
    try:
        from src import rul_models as RM
        return bool(RM.HAS_TF)
    except Exception:
        return False


# ------------------------------------------------------------------------------------------------
# Training helpers
# ------------------------------------------------------------------------------------------------
def ensure_classical(root, ds, log=print):
    """Make sure the 4 classical models exist on disk (train them if not; deterministic, takes 1-3 minutes)."""
    import joblib
    from src import rul_models as RM
    P = paths(root, ds)
    d = P["models"] / "classical"
    d.mkdir(parents=True, exist_ok=True)
    if all((d / f"{n}.joblib").exists() for n in CLASSICAL):
        return
    z = np.load(P["proc"] / "arrays.npz")
    log(f"[{ds}] training classical models ...")
    for name, m in RM.fit_classical(flat_features(z["X_train"]), z["y_train"], seed=0).items():
        joblib.dump(m, d / f"{name}.joblib", compress=3)


def train_deep_suite(root, ds, archs=None, seeds=3, epochs=60, patience=10, batch=128, force=False, log=print):
    """Train Keras models (TensorFlow) on the Phase-2 arrays and save weights to artifacts/models/<ds>/."""
    from src import rul_models as RM
    if not RM.HAS_TF:
        raise RuntimeError("TensorFlow is not installed.  Run:  pip install tensorflow")
    P = paths(root, ds)
    z = np.load(P["proc"] / "arrays.npz")
    P["models"].mkdir(parents=True, exist_ok=True)
    window, F = z["X_train"].shape[1], z["X_train"].shape[2]
    done = []
    for i, arch in enumerate(archs or DEEP_ARCHS):
        t0 = time.time()
        try:
            for s in range(seeds):
                f = P["models"] / f"{arch}_s{s}.weights.h5"
                if f.exists() and not force:
                    continue
                RM.set_seed(1000 * (DEEP_ARCHS.index(arch) + 1) + s)
                model = RM.build_model(arch, window, F, **MODEL_KW)
                RM.train_model(model, z["X_train"], z["y_train"], z["X_val"], z["y_val"], RUL_CAP, epochs, batch, patience, verbose=0)
                RM.save_weights(model, P["models"] / f"{arch}_s{s}")
            done.append(arch)
            log(f"[{ds}] {PRETTY[arch]:22s} trained ({seeds} seeds, {time.time() - t0:.0f}s)")
        except Exception as exc:                       # one failing architecture must never stop the others
            log(f"[{ds}] {PRETTY[arch]:22s} FAILED: {type(exc).__name__}: {str(exc)[:120]}")
    save_json(dict(model_kw=MODEL_KW, seeds=seeds, epochs=epochs), P["models"] / "config.json")
    return done


# ------------------------------------------------------------------------------------------------
# Loading members and predicting
# ------------------------------------------------------------------------------------------------
def _load_member(m, window, F, kw):
    if m["kind"] == "sklearn":
        import joblib
        return joblib.load(m["path"])
    from src import rul_models as RM
    return RM.load_model(m["arch"], window, F, m["path"], **kw)


def _predict_member(kind, model, X, cap=RUL_CAP):
    if kind == "sklearn":
        return np.clip(model.predict(flat_features(X)), 0, cap)
    if len(X) <= 32:
        out = np.asarray(model(np.asarray(X, dtype=np.float32), training=False).numpy())
    else:
        out = np.asarray(model.predict(X, batch_size=1024, verbose=0))
    return np.clip(out.ravel() * cap, 0, cap)


def discover_specs(root, ds):
    """Find every trained model on disk and describe it. Deep architectures that are not trained are listed as such."""
    P = paths(root, ds)
    specs = []
    for n in CLASSICAL:
        f = P["models"] / "classical" / f"{n}.joblib"
        if f.exists():
            specs.append(dict(id=n, name=PRETTY[n], family="classical", desc=DESC[n], status="ready",
                              members=[dict(kind="sklearn", path=str(f), weight=1.0)]))
    et, gb = (P["models"] / "classical" / f"{n}.joblib" for n in ("ExtraTrees", "HistGradientBoosting"))
    if et.exists() and gb.exists():
        specs.append(dict(id="classical_ensemble", name="Classical ensemble", family="ensemble", status="ready",
                          desc="Average of Extra Trees and Gradient Boosting.",
                          members=[dict(kind="sklearn", path=str(et), weight=0.5), dict(kind="sklearn", path=str(gb), weight=0.5)]))
    for a in DEEP_ARCHS:
        files = sorted(P["models"].glob(f"{a}_s*.weights.h5"))
        if files:
            specs.append(dict(id=a, name=PRETTY[a], family="deep", desc=DESC[a], status="ready",
                              members=[dict(kind="keras", arch=a, path=str(f), weight=1.0 / len(files)) for f in files]))
        else:
            specs.append(dict(id=a, name=PRETTY[a], family="deep", desc=DESC[a], status="not_trained", members=[]))
    return specs


def _metrics(y, p, y_raw=None):
    m = regression_metrics(y, p)
    out = {k: round(float(v), 4) for k, v in m.items()}
    if y_raw is not None:
        r = regression_metrics(y_raw, p)
        out["R2_raw"], out["RMSE_raw"], out["MAE_raw"] = round(float(r["R2"]), 4), round(float(r["RMSE"]), 4), round(float(r["MAE"]), 4)
    return out


def build_zoo(root, ds, log=print, train_sample=6000):
    """Evaluate every available model on identical data and write the files the web UI reads."""
    P = paths(root, ds)
    z = np.load(P["proc"] / "arrays.npz")
    prep = Preprocessor.from_dict(load_json(P["proc"] / "prep.json"))
    det = AnomalyDetector.from_dict(load_json(P["proc"] / "anomaly.json"))
    window, F, cap = z["X_train"].shape[1], z["X_train"].shape[2], RUL_CAP
    cfgp = P["models"] / "config.json"
    kw = load_json(cfgp).get("model_kw", MODEL_KW) if cfgp.exists() else MODEL_KW
    ensure_classical(root, ds, log)
    specs = discover_specs(root, ds)

    sens = pd.read_csv(P["final"] / "test_sensors.csv.gz")
    fleet0 = pd.read_csv(P["final"] / "fleet_summary.csv").set_index("unit_id")
    units = np.sort(sens["unit_id"].unique())
    rng = np.random.RandomState(0)
    idx = rng.choice(len(z["X_train"]), min(train_sample, len(z["X_train"])), replace=False)
    Xtr_s, ytr_s = z["X_train"][idx], z["y_train"][idx]

    # every cycle of every test engine (windows use only past data) + anomaly score
    Ws, rows = [], []
    for u in units:
        g = sens[sens.unit_id == u].sort_values("cycle")
        feat = prep.transform_engine(g)
        W = engine_windows(feat, window)
        Ws.append(W)
        last, true_last = int(g.cycle.max()), float(fleet0.loc[u, "rul_true"])
        true = true_last + (last - g.cycle.to_numpy())
        rows.append(pd.DataFrame({"unit_id": u, "cycle": g.cycle.to_numpy(), "rul_true": true, "rul_true_capped": np.minimum(true, cap),
                                  "anomaly_score": warmup_fix(det.score(prep.sensor_part(feat)))}))
    W_all, TL = np.concatenate(Ws), pd.concat(rows, ignore_index=True)
    X_last = np.stack([w[-1] for w in Ws])
    names = prep.features

    # per-member predictions (each member evaluated once, shared by every model that uses it)
    cache, mp = {}, {}
    def member_preds(m):
        key = m["path"]
        if key in mp:
            return mp[key]
        model = _load_member(m, window, F, kw)
        k = m["kind"]
        base = _predict_member(k, model, X_last)
        occ = np.zeros((len(X_last), F))
        for j in range(F):
            Xo = X_last.copy(); Xo[:, :, j] = 0.0
            occ[:, j] = _predict_member(k, model, Xo) - base
        t0 = time.perf_counter()
        for i in range(20):
            _predict_member(k, model, X_last[i:i + 1])
        lat = (time.perf_counter() - t0) / 20 * 1000
        params = int(model.count_params()) if k == "keras" else None
        mp[key] = dict(train=_predict_member(k, model, Xtr_s), val=_predict_member(k, model, z["X_val"]),
                       test=_predict_member(k, model, z["X_test"]), tl=_predict_member(k, model, W_all), occ=occ, lat=lat,
                       size=Path(m["path"]).stat().st_size / 1024, params=params)
        return mp[key]

    def combine(spec):
        out = dict(train=0, val=0, test=0, tl=0, occ=0, lat=0, size=0, params=0)
        tot = sum(m["weight"] for m in spec["members"])
        for m in spec["members"]:
            r, w = member_preds(m), m["weight"] / tot
            for k in ("train", "val", "test", "tl", "occ"):
                out[k] = out[k] + w * r[k]
            out["lat"] += r["lat"]; out["size"] += r["size"]
            out["params"] += (r["params"] or 0)
        return out

    results, deep_rank = {}, []
    ready = [s for s in specs if s["status"] == "ready"]
    for s in ready:
        results[s["id"]] = combine(s)
        log(f"[{ds}] evaluated {s['name']}")
    # ensembles of the best deep architectures (ranked on VALIDATION only)
    deep = sorted([s for s in ready if s["family"] == "deep"], key=lambda s: _metrics(z["y_val"], results[s["id"]]["val"])["RMSE"])
    if len(deep) >= 2:
        top = deep[:3]
        members = [dict(m, weight=m["weight"] / len(top)) for s in top for m in s["members"]]
        s3 = dict(id="deep_top3", name="Deep top-3 ensemble", family="ensemble", status="ready", members=members,
                  desc="Average of the 3 best deep architectures (chosen on validation engines): " + ", ".join(t["name"] for t in top))
        specs.append(s3); ready.append(s3); results[s3["id"]] = combine(s3)
        if any(s["id"] == "classical_ensemble" for s in ready):
            ce = next(s for s in ready if s["id"] == "classical_ensemble")
            sh = dict(id="hybrid", name="Hybrid: deep + classical", family="ensemble", status="ready",
                      members=[dict(m, weight=m["weight"] * 0.5) for m in s3["members"]] + [dict(m, weight=m["weight"] * 0.5) for m in ce["members"]],
                      desc="Half deep top-3 ensemble, half classical ensemble.")
            specs.append(sh); ready.append(sh); results[sh["id"]] = combine(sh)

    for u_i, s in enumerate(specs):
        if s["status"] != "ready":
            continue
        r = results[s["id"]]
        s["metrics"] = dict(train=_metrics(ytr_s, r["train"]), val=_metrics(z["y_val"], r["val"]),
                            test=_metrics(z["y_test"], r["test"], z["y_test_raw"]))
        s["size_kb"], s["latency_ms"] = round(r["size"], 1), round(r["lat"], 3)
        s["params"] = int(r["params"]) if r["params"] else None
        s["n_members"] = len(s["members"])
        TL[s["id"]] = np.round(r["tl"], 3)
    ok = [s for s in specs if s["status"] == "ready"]
    best = min(ok, key=lambda s: s["metrics"]["val"]["RMSE"])            # recommended = best on VALIDATION (test never used)
    for s in specs:
        s["recommended"] = s["id"] == best["id"]
        for m in s["members"]:
            m["path"] = str(Path(m["path"]).resolve().relative_to(Path(root).resolve())).replace("\\", "/")

    P["zoo"].mkdir(parents=True, exist_ok=True)
    imp = []
    for s in ok:
        occ = results[s["id"]]["occ"]
        imp.append(pd.DataFrame({"model": s["id"], "unit_id": np.repeat(units, F), "feature": np.tile(names, len(units)),
                                 "contribution": np.round(occ.ravel(), 4)}))
    pd.concat(imp, ignore_index=True).to_csv(P["zoo"] / "importance.csv.gz", index=False)
    TL.to_csv(P["zoo"] / "timelines.csv.gz", index=False)
    index = dict(dataset=ds, cap=cap, window=window, features=names, recommended=best["id"], deep_available=any(s["family"] == "deep" for s in ok),
                 tensorflow=has_tensorflow(), n_test_engines=int(len(units)), model_kw=kw, models=[
                     {k: v for k, v in s.items()} for s in specs])
    save_json(index, P["zoo"] / "index.json")
    log(f"[{ds}] model zoo written: {len(ok)} models ready, recommended = {best['name']}")
    return index


# ------------------------------------------------------------------------------------------------
# Live inference for the API (uploaded CSV / any machine history)
# ------------------------------------------------------------------------------------------------
class ZooPredictor:
    def __init__(self, root, ds, model_id=None):
        P = paths(root, ds)
        self.root, self.ds = Path(root), ds
        self.index = load_json(P["zoo"] / "index.json")
        self.prep = Preprocessor.from_dict(load_json(P["final"] / "prep.json"))
        self.det = AnomalyDetector.from_dict(load_json(P["final"] / "anomaly.json"))
        self.window, self.cap = self.index["window"], self.index["cap"]
        mid = model_id or self.index["recommended"]
        self.spec = next((m for m in self.index["models"] if m["id"] == mid), None)
        if self.spec is None or self.spec["status"] != "ready":
            raise ValueError(f"model '{mid}' is not available for {ds}")
        self._members = None

    def _load(self):
        if self._members is None:
            self._members = [(m["kind"], _load_member(dict(m, path=str(self.root / m["path"])), self.window, self.prep.n_features, self.index["model_kw"]),
                              m["weight"]) for m in self.spec["members"]]

    def predict_windows(self, X):
        self._load()
        tot = sum(w for _, _, w in self._members)
        return sum(w * _predict_member(k, m, X, self.cap) for k, m, w in self._members) / tot

    def timeline(self, df):
        g = df.sort_values("cycle")
        feat = self.prep.transform_engine(g)
        rul = self.predict_windows(engine_windows(feat, self.window))
        return pd.DataFrame({"cycle": g.cycle.to_numpy(), "rul_pred": rul,
                             "anomaly_score": warmup_fix(self.det.score(self.prep.sensor_part(feat)))}), feat

    def occlusion(self, window_last):
        base = self.predict_windows(window_last[None])[0]
        out = []
        for j in range(window_last.shape[1]):
            x = window_last.copy(); x[:, j] = 0.0
            out.append(float(self.predict_windows(x[None])[0] - base))
        return out
