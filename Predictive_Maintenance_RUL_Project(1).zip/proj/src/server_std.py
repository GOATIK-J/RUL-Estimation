"""server_std.py - zero-dependency web server (Python standard library) around api_core.handle. Used when FastAPI is not installed."""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from src import api_core


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _go(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else b""
        status, headers, payload = api_core.handle(self.command, self.path, dict(self.headers), body)
        self.send_response(status)
        for k, v in headers.items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(payload)

    do_GET = do_POST = do_HEAD = _go

    def log_message(self, fmt, *args):          # keep the console quiet
        pass


def make_server(host="127.0.0.1", port=8000):
    return ThreadingHTTPServer((host, port), Handler)
