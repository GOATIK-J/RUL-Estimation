"""
rul_models.py  -  models for RUL prediction.   Framework: TensorFlow / Keras ONLY (no PyTorch).

* classical baselines (scikit-learn):  Ridge, RandomForest, ExtraTrees, HistGradientBoosting
* deep models (Keras):  MLP, LSTM, GRU, BiLSTM, CNN-LSTM, CNN-BiLSTM-Attention
* training with early stopping on held-out ENGINES (anti-overfitting), seed ensembles
* Integrated-Gradients explainability, knowledge distillation, quantisation
Only built-in Keras layers are used, so models can be saved/loaded as plain weight files.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import numpy as np

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    HAS_TF = True
    TF_VERSION = tf.__version__
except Exception as _exc:          # TensorFlow not installed -> classical models still work
    tf = keras = layers = None
    HAS_TF = False
    TF_VERSION = f"not available ({type(_exc).__name__})"

ARCHS = {
    "mlp": "Flatten + 2 dense layers (deep baseline without temporal structure)",
    "lstm": "LSTM -> dense",
    "gru": "GRU -> dense",
    "bilstm": "Bidirectional LSTM -> dense",
    "cnn_lstm": "1D-CNN (local patterns) -> LSTM (temporal dependencies) -> dense",
    "cnn_lstm_attention": "1D-CNN -> BiLSTM -> temporal attention -> dense  (proposed model)",
}


# ------------------------------------------------------------------------------------------
# classical baselines
# ------------------------------------------------------------------------------------------
def fit_classical(F_train, y_train, seed=0, fast=False):
    """Fit the 4 classical regressors on window-statistics features. Returns {name: fitted_model}."""
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
    from sklearn.linear_model import Ridge
    n = 100 if fast else 300
    models = {
        "Ridge": Ridge(alpha=10.0),
        # min_samples_leaf / L2 / early stopping keep the tree models regularised (smaller, less memorisation)
        "RandomForest": RandomForestRegressor(n_estimators=n // 2, min_samples_leaf=15, max_features=0.5, n_jobs=-1, random_state=seed),
        "ExtraTrees": ExtraTreesRegressor(n_estimators=n // 2, min_samples_leaf=15, max_features=0.5, n_jobs=-1, random_state=seed),
        "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=800, learning_rate=0.04, max_leaf_nodes=16, min_samples_leaf=100,
                                                              l2_regularization=10.0, early_stopping=True, validation_fraction=0.15,
                                                              n_iter_no_change=30, random_state=seed),
    }
    for m in models.values():
        m.fit(F_train, y_train)
    return models


# ------------------------------------------------------------------------------------------
# Keras architectures
# ------------------------------------------------------------------------------------------
def set_seed(seed: int):
    np.random.seed(seed)
    if HAS_TF:
        try:
            keras.utils.set_random_seed(seed)
        except Exception:
            tf.random.set_seed(seed)


def _attention_pool(x, window):
    """Temporal attention using only built-in layers: score each time step, softmax, weighted sum."""
    score = layers.Dense(1, activation="tanh", name="att_score")(x)          # (B,T,1)
    weights = layers.Softmax(axis=1, name="att_weights")(score)               # (B,T,1) sums to 1 over time
    weighted = layers.Multiply(name="att_weighted")([x, weights])             # (B,T,H)
    pooled = layers.GlobalAveragePooling1D()(weighted)                        # (B,H)  = context / T
    return layers.Rescaling(float(window), name="att_context")(pooled)       # (B,H)  = context vector


def build_model(arch, window, n_features, units=64, filters=64, dropout=0.2, l2=1e-5, noise=0.03, lr=1e-3):
    """Returns a compiled Keras model that maps (window, n_features) -> RUL / cap  (a number in ~[0,1])."""
    if not HAS_TF:
        raise RuntimeError("TensorFlow is not installed:  pip install tensorflow")
    reg = keras.regularizers.l2(l2)
    inp = layers.Input((window, n_features), name="sensor_window")
    x = layers.GaussianNoise(noise, name="noise_augment")(inp)                # regulariser: active only in training
    if arch == "mlp":
        x = layers.Flatten()(x)
        x = layers.Dense(128, activation="relu", kernel_regularizer=reg)(x)
        x = layers.Dropout(dropout)(x)
        x = layers.Dense(64, activation="relu", kernel_regularizer=reg)(x)
    elif arch in ("lstm", "gru"):
        rnn = layers.LSTM if arch == "lstm" else layers.GRU
        x = rnn(units, kernel_regularizer=reg)(x)
        x = layers.Dropout(dropout)(x)
    elif arch == "bilstm":
        x = layers.Bidirectional(layers.LSTM(units, kernel_regularizer=reg))(x)
        x = layers.Dropout(dropout)(x)
    elif arch == "cnn_lstm":
        x = layers.Conv1D(filters, 3, padding="same", activation="relu", kernel_regularizer=reg)(x)
        x = layers.Conv1D(filters, 3, padding="same", activation="relu", kernel_regularizer=reg)(x)
        x = layers.LSTM(units, kernel_regularizer=reg)(x)
        x = layers.Dropout(dropout)(x)
    elif arch == "cnn_lstm_attention":
        x = layers.Conv1D(filters, 3, padding="same", activation="relu", kernel_regularizer=reg)(x)
        x = layers.Conv1D(filters, 3, padding="same", activation="relu", kernel_regularizer=reg)(x)
        x = layers.Bidirectional(layers.LSTM(units // 2, return_sequences=True, kernel_regularizer=reg))(x)
        x = layers.Dropout(dropout)(x)
        x = _attention_pool(x, window)
    elif arch == "student_gru":                                               # tiny model for distillation / edge
        x = layers.GRU(16)(x)
    else:
        raise ValueError(f"unknown architecture '{arch}'. Choose from {list(ARCHS)}")
    x = layers.Dense(32, activation="relu", kernel_regularizer=reg)(x)
    out = layers.Dense(1, name="rul_scaled")(x)
    model = keras.Model(inp, out, name=arch)
    model.compile(optimizer=keras.optimizers.Adam(lr, clipnorm=1.0), loss=keras.losses.Huber(delta=0.1),
                  metrics=[keras.metrics.MeanAbsoluteError(name="mae")])
    return model


def train_model(model, X_tr, y_tr, X_va, y_va, cap=125.0, epochs=60, batch_size=128, patience=10, verbose=0):
    """Train on RUL/cap. Early stopping on validation ENGINES + LR reduction restores the best weights (anti-overfitting)."""
    cbs = [keras.callbacks.EarlyStopping(monitor="val_loss", patience=patience, restore_best_weights=True),
           keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=max(2, patience // 3), min_lr=1e-5)]
    return model.fit(X_tr, y_tr / cap, validation_data=(X_va, y_va / cap), epochs=epochs, batch_size=batch_size,
                     callbacks=cbs, verbose=verbose, shuffle=True)


def predict_rul(model, X, cap=125.0):
    return np.clip(model.predict(X, batch_size=1024, verbose=0).ravel() * cap, 0.0, cap)


def save_weights(model, path):
    path = str(path)
    if not path.endswith(".weights.h5"):
        path += ".weights.h5"
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    model.save_weights(path)
    return path


def load_model(arch, window, n_features, weights_path, **kw):
    m = build_model(arch, window, n_features, **kw)
    m.load_weights(str(weights_path))
    return m


# ------------------------------------------------------------------------------------------
# Explainability: Integrated Gradients  (which sensor / time step drove the prediction?)
# ------------------------------------------------------------------------------------------
def integrated_gradients(model, X, steps=24, batch_size=64, baseline=None):
    """
    IG attribution of the model output to every input value.  baseline = all-zeros (= average healthy state
    because inputs are standardised).  Returns array (N, T, F); sum over axis (1,2) ~ f(x) - f(baseline).
    """
    X = np.asarray(X, dtype=np.float32)
    base = np.zeros_like(X) if baseline is None else np.broadcast_to(baseline, X.shape).astype(np.float32)
    out = np.zeros_like(X)
    alphas = (np.arange(steps, dtype=np.float32) + 0.5) / steps               # mid-point rule
    for s in range(0, len(X), batch_size):
        xb, bb = tf.constant(X[s:s + batch_size]), tf.constant(base[s:s + batch_size])
        total = tf.zeros_like(xb)
        for a in alphas:
            xi = bb + a * (xb - bb)
            with tf.GradientTape() as tape:
                tape.watch(xi)
                y = model(xi, training=False)
            total += tape.gradient(y, xi)
        out[s:s + batch_size] = ((xb - bb) * total / steps).numpy()
    return out


# ------------------------------------------------------------------------------------------
# Compression: knowledge distillation + quantisation (edge / IoT deployment)
# ------------------------------------------------------------------------------------------
def distill_student(teacher_pred_scaled, X_tr, y_tr, X_va, y_va, cap=125.0, alpha=0.7, epochs=40, seed=0, verbose=0):
    """Small GRU student learns from  alpha * teacher + (1-alpha) * ground truth  (soft + hard targets)."""
    set_seed(seed)
    student = build_model("student_gru", X_tr.shape[1], X_tr.shape[2], lr=2e-3, noise=0.0)
    target = alpha * teacher_pred_scaled + (1 - alpha) * (y_tr / cap)
    cbs = [keras.callbacks.EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True)]
    student.fit(X_tr, target, validation_data=(X_va, y_va / cap), epochs=epochs, batch_size=128, callbacks=cbs, verbose=verbose)
    return student


def float16_quantize(model, arch, window, n_features, **kw):
    """Post-training weight quantisation to float16 (always works): returns (model_with_rounded_weights, size_bytes)."""
    q = build_model(arch, window, n_features, **kw)
    ws = model.get_weights()
    q.set_weights([w.astype(np.float16).astype(np.float32) for w in ws])
    return q, int(sum(w.size for w in ws) * 2)


def tflite_dynamic_quantize(model, out_path):
    """Try TensorFlow-Lite dynamic-range int8 quantisation. Returns (size_bytes, path) or (None, reason)."""
    try:
        conv = tf.lite.TFLiteConverter.from_keras_model(model)
        conv.optimizations = [tf.lite.Optimize.DEFAULT]
        conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS]
        conv._experimental_lower_tensor_list_ops = False
        blob = conv.convert()
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        Path(out_path).write_bytes(blob)
        return len(blob), str(out_path)
    except Exception as exc:
        return None, f"{type(exc).__name__}: {str(exc)[:120]}"


def tflite_predict(path, X, cap=125.0):
    interp = tf.lite.Interpreter(model_path=str(path))
    inp, out = interp.get_input_details()[0], interp.get_output_details()[0]
    preds = []
    for i in range(len(X)):
        interp.resize_tensor_input(inp["index"], [1] + list(X.shape[1:]))
        interp.allocate_tensors()
        interp.set_tensor(inp["index"], X[i:i + 1].astype(np.float32))
        interp.invoke()
        preds.append(float(interp.get_tensor(out["index"]).ravel()[0]))
    return np.clip(np.array(preds) * cap, 0, cap)


def latency_ms(predict_fn, X, repeats=5):
    """Mean time (ms) to predict ONE window (batch of 1), measured over a few windows."""
    predict_fn(X[:1])
    t = time.perf_counter()
    for _ in range(repeats):
        for i in range(min(20, len(X))):
            predict_fn(X[i:i + 1])
    return (time.perf_counter() - t) / (repeats * min(20, len(X))) * 1000.0
