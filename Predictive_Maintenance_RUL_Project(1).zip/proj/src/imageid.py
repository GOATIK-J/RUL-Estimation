"""
imageid.py - machine PHOTO -> machine identity.

Honest scope: a photograph cannot reveal how many cycles a machine has left (the model needs its sensor history), so the photo is used to
IDENTIFY the machine; the health dashboard is then produced from that machine's sensor data.  Three ways to identify:
  1. the machine ID is written in the file name (e.g. M-023.jpg, engine_23.png)
  2. the photo (or a resized / re-compressed copy) was registered before: perceptual-hash match
  3. otherwise the user picks the machine once and registers the photo, so the next upload is recognised automatically
"""
from __future__ import annotations

import io
import json
import re
import time
from pathlib import Path

HASH_THRESHOLD = 10          # max Hamming distance (of 64 bits) to call two photos "the same picture"
_NAME_RE = re.compile(r"(?:^|[^a-z0-9])(?:m|machine|engine|unit|eng)[-_ ]?0*(\d{1,4})(?:[^0-9]|$)", re.I)


def dhash(data: bytes, size: int = 8) -> str:
    """64-bit difference hash: robust to resizing, re-compression and small brightness changes."""
    from PIL import Image, ImageOps
    im = Image.open(io.BytesIO(data))
    im = ImageOps.exif_transpose(im).convert("L").resize((size + 1, size), Image.LANCZOS)
    px = list(im.getdata())
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] > px[r * (size + 1) + c + 1] else 0)
    return f"{bits:016x}"


def hamming(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


def image_info(data: bytes) -> dict:
    from PIL import Image
    im = Image.open(io.BytesIO(data))
    return {"width": im.size[0], "height": im.size[1], "format": im.format or "?", "kb": round(len(data) / 1024, 1)}


def unit_from_filename(name: str):
    m = _NAME_RE.search(name or "")
    return int(m.group(1)) if m else None


class Registry:
    """artifacts/registry/registry.json : {"entries": [{ds, unit, file, hash, source}]}  (photos stored next to it)."""

    def __init__(self, root):
        self.dir = Path(root) / "artifacts" / "registry"
        self.file = self.dir / "registry.json"

    def entries(self):
        if self.file.exists():
            return json.loads(self.file.read_text()).get("entries", [])
        return []

    def _save(self, entries):
        self.dir.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps({"entries": entries}, indent=1))

    def match(self, h: str, ds=None):
        best = None
        for e in self.entries():
            if ds and e["ds"] != ds:
                continue
            d = hamming(h, e["hash"])
            if d <= HASH_THRESHOLD and (best is None or d < best[0]):
                best = (d, e)
        return best

    def add(self, ds: str, unit: int, data: bytes, source="user"):
        h = dhash(data)
        entries = [e for e in self.entries() if not (e["ds"] == ds and e["hash"] == h)]
        (self.dir / "photos").mkdir(parents=True, exist_ok=True)
        fname = f"{ds}_M{unit:03d}_{int(time.time() * 1000) % 10_000_000}.png" if source == "user" else f"{ds}_M{unit:03d}.png"
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert("RGB")
        im.thumbnail((900, 900))
        im.save(self.dir / "photos" / fname)
        entry = dict(ds=ds, unit=int(unit), file=fname, hash=h, source=source)
        entries.append(entry)
        self._save(entries)
        return entry
