"""
api_core.py - the whole backend as ONE framework-independent function:  handle(method, path, headers, body) -> (status, headers, bytes)

Two thin adapters call it: backend/main.py (FastAPI + uvicorn) and src/server_std.py (Python standard library, zero dependencies).
It serves the JSON API (/api/...) and the web app (web/).
"""
from __future__ import annotations

import json
import mimetypes
import re
import threading
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import numpy as np
import pandas as pd

from src.rul_core import (ACTIONS, SENSOR_COLS, SENSOR_GROUPS, SENSOR_INFO, SETTING_COLS, Preprocessor, health_percent, load_json,
                          status_from_rul, trend_arrow)
from src import imageid

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
ZOO_ROOT = ROOT / "artifacts" / "zoo"
MAX_BODY = 20 * 1024 * 1024
_lock = threading.RLock()
_bundles: dict = {}
_predictors: dict = {}


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


# ------------------------------------------------------------------------------------------------ data access
def available():
    return sorted(d.name for d in ZOO_ROOT.glob("FD*") if (d / "index.json").exists()) if ZOO_ROOT.exists() else []


def bundle(ds):
    with _lock:
        if ds in _bundles:
            return _bundles[ds]
        if ds not in available():
            raise ApiError(404, f"No model zoo for '{ds}'. Run notebook 03 (or tools/build_zoo.py) first.")
        z, f = ZOO_ROOT / ds, ROOT / "artifacts" / "final" / ds
        index = load_json(z / "index.json")
        tl = pd.read_csv(z / "timelines.csv.gz")
        imp = pd.read_csv(z / "importance.csv.gz")
        feat = pd.read_csv(f / "engine_importance.csv")[["unit_id", "feature", "label", "z_last", "trend"]]
        sens = pd.read_csv(f / "test_sensors.csv.gz")
        b = dict(index=index, tl=tl, imp=imp, feat=feat, sens=sens, prep=Preprocessor.from_dict(load_json(f / "prep.json")),
                 fleet0=pd.read_csv(f / "fleet_summary.csv").set_index("unit_id"),
                 ready={m["id"]: m for m in index["models"] if m["status"] == "ready"})
        _bundles[ds] = b
        return b


def pick_model(b, model_id):
    mid = model_id or b["index"]["recommended"]
    if mid not in b["ready"]:
        raise ApiError(400, f"Model '{mid}' is not available. Choose one of: {', '.join(b['ready'])}")
    return mid


def clean(o):
    """numpy / NaN safe for JSON."""
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return clean(o.tolist())
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (float, np.floating)):
        return None if not np.isfinite(o) else float(o)
    return o


def _unit(b, q):
    try:
        u = int(q.get("unit", [""])[0])
    except ValueError:
        raise ApiError(400, "parameter 'unit' must be an integer")
    if u not in set(b["fleet0"].index):
        raise ApiError(404, f"machine {u} not found in this dataset")
    return u


# ------------------------------------------------------------------------------------------------ endpoints
def r_health(q, body, headers):
    from src import zoo
    return dict(status="ok", datasets=available(), tensorflow=zoo.has_tensorflow())


def r_datasets(q, body, headers):
    out = []
    for ds in available():
        i = bundle(ds)["index"]
        out.append(dict(id=ds, window=i["window"], n_engines=i["n_test_engines"], recommended=i["recommended"], deep_available=i["deep_available"],
                        n_models=len(bundle(ds)["ready"])))
    return out


def r_models(q, body, headers):
    b = bundle(q.get("ds", [available()[0] if available() else ""])[0])
    i = b["index"]
    keep = ("id", "name", "family", "desc", "status", "metrics", "size_kb", "latency_ms", "params", "n_members", "recommended")
    return dict(dataset=i["dataset"], recommended=i["recommended"], deep_available=i["deep_available"], tensorflow=i["tensorflow"],
                models=[{k: m.get(k) for k in keep} for m in i["models"]])


def _fleet_frame(b, mid):
    last = b["tl"].sort_values("cycle").groupby("unit_id").tail(1).set_index("unit_id")
    df = pd.DataFrame({"unit": last.index, "cycles": last.cycle.to_numpy(), "rul_pred": last[mid].to_numpy(),
                       "rul_true": b["fleet0"].loc[last.index, "rul_true"].to_numpy(), "rul_true_capped": last.rul_true_capped.to_numpy(),
                       "anomaly": last.anomaly_score.to_numpy()})
    df["abs_error"] = (df.rul_pred - df.rul_true_capped).abs()
    df["health_pct"] = np.clip(df.rul_pred / b["index"]["cap"], 0, 1) * 100
    df["status"] = df.rul_pred.map(status_from_rul)
    return df


def r_fleet(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    mid = pick_model(b, q.get("model", [None])[0])
    df = _fleet_frame(b, mid)
    counts = df.status.value_counts().to_dict()
    return dict(dataset=ds, model=mid, model_name=b["ready"][mid]["name"], counts=counts, mae=float(df.abs_error.mean()),
                machines=df.sort_values("rul_pred").to_dict(orient="records"))


def r_lab(q, body, headers):
    """Everything the Model Lab needs: metrics + every model's prediction for every test engine (identical engines for all models)."""
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    last = b["tl"].sort_values("cycle").groupby("unit_id").tail(1).set_index("unit_id")
    ids = list(b["ready"])
    imp = b["imp"].assign(a=lambda d: d.contribution.abs()).groupby(["model", "feature"]).a.mean().reset_index()
    return dict(dataset=ds, cap=b["index"]["cap"], recommended=b["index"]["recommended"], deep_available=b["index"]["deep_available"],
                tensorflow=b["index"]["tensorflow"],
                models=[{k: m.get(k) for k in ("id", "name", "family", "desc", "status", "metrics", "size_kb", "latency_ms", "params", "n_members", "recommended")}
                        for m in b["index"]["models"]],
                units=last.index.tolist(), true_capped=last.rul_true_capped.tolist(), true_raw=b["fleet0"].loc[last.index, "rul_true"].tolist(),
                preds={m: last[m].round(2).tolist() for m in ids},
                importance={m: dict(zip(g.feature, g.a.round(3))) for m, g in imp.groupby("model")})


def r_engine(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    mid = pick_model(b, q.get("model", [None])[0])
    u = _unit(b, q)
    tl = b["tl"][b["tl"].unit_id == u].sort_values("cycle").reset_index(drop=True)
    last = int(tl.cycle.max())
    try:
        cutoff = int(q.get("cutoff", [last])[0])
    except ValueError:
        raise ApiError(400, "parameter 'cutoff' must be an integer")
    cutoff = min(max(cutoff, int(tl.cycle.min())), last)
    i = int((tl.cycle <= cutoff).sum()) - 1
    rul, anom, true_c = float(tl.loc[i, mid]), float(tl.loc[i, "anomaly_score"]), float(tl.loc[i, "rul_true_capped"])
    st = status_from_rul(rul)
    prep = b["prep"]
    sens = b["sens"][b["sens"].unit_id == u].sort_values("cycle")
    z = prep.transform_engine(sens)
    names = prep.features
    groups = {}
    for g, cols in SENSOR_GROUPS.items():
        idx = [prep.sensors.index(c) for c in cols if c in prep.sensors]
        if idx:
            s = z[: i + 1, idx].mean(1)
            groups[g] = dict(arrow=trend_arrow(s), value=float(s[-1]))
    feats = b["feat"][b["feat"].unit_id == u].set_index("feature")
    if cutoff == last:
        im = b["imp"][(b["imp"].model == mid) & (b["imp"].unit_id == u)].set_index("feature").contribution
        method = "Occlusion: cycles of life a sensor takes away"
        imp = [dict(feature=f, label=feats.loc[f, "label"], value=float(im[f]), trend=feats.loc[f, "trend"]) for f in names if f in im.index]
    else:
        rec = z[max(0, i - 4): i + 1].mean(0)
        method = "Deviation from normal behaviour (z-score)"
        imp = [dict(feature=f, label=SENSOR_INFO.get(f, ("cycles run",))[0], value=float(abs(v)), trend=trend_arrow(z[: i + 1, k]))
               for k, (f, v) in enumerate(zip(names, rec))]
    imp = sorted(imp, key=lambda d: -abs(d["value"]))[:10]
    top = [f for f in (d["feature"] for d in imp) if f in SENSOR_INFO][:6]
    series = {f"{SENSOR_INFO[f][0]}": dict(feature=f, desc=SENSOR_INFO[f][1], z=np.round(z[:, names.index(f)], 3).tolist()) for f in top}
    return dict(dataset=ds, model=mid, model_name=b["ready"][mid]["name"], unit=u, name=f"M-{u:03d}", last_cycle=last, cutoff=cutoff,
                cycles=tl.cycle.tolist(), rul_pred=tl[mid].round(2).tolist(), rul_true_capped=tl.rul_true_capped.tolist(),
                anomaly_series=tl.anomaly_score.round(3).tolist(), rul=rul, true_rul_capped=true_c, true_rul_raw=float(b["fleet0"].loc[u, "rul_true"]) if cutoff == last else None,
                health_pct=health_percent(rul, b["index"]["cap"]), anomaly=anom, anomaly_flag=anom > 0.5, status=st, action=ACTIONS[st],
                groups=groups, importance=imp, importance_method=method, sensors=series, cap=b["index"]["cap"])


def r_compare(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    u = _unit(b, q)
    tl = b["tl"][b["tl"].unit_id == u].sort_values("cycle")
    return dict(dataset=ds, unit=u, cycles=tl.cycle.tolist(), true_capped=tl.rul_true_capped.tolist(), cap=b["index"]["cap"],
                models=[dict(id=m, name=v["name"], family=v["family"], pred=tl[m].round(2).tolist(), final=float(tl[m].iloc[-1]),
                             error=float(abs(tl[m].iloc[-1] - tl.rul_true_capped.iloc[-1]))) for m, v in b["ready"].items()])


def r_sample_csv(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    u = _unit(b, q)
    s = b["sens"][b["sens"].unit_id == u].sort_values("cycle")
    return ("text/csv", s.to_csv(index=False).encode(), {"Content-Disposition": f'attachment; filename="machine_M-{u:03d}_{ds}.csv"'})


def r_predict(q, body, headers):
    """Live prediction from an uploaded sensor history, using the model the user selected."""
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    mid = pick_model(b, q.get("model", [None])[0])
    try:
        rows = json.loads(body or b"{}").get("rows")
    except json.JSONDecodeError:
        raise ApiError(400, "body must be JSON: {\"rows\": [ {cycle, sensor_1..sensor_21, setting_1..3}, ... ]}")
    if not rows:
        raise ApiError(400, "no rows received")
    df = pd.DataFrame(rows).apply(pd.to_numeric, errors="coerce")
    missing = [c for c in ["cycle"] + [s for s in b["prep"].sensors] if c not in df.columns]
    if missing:
        raise ApiError(422, f"missing columns: {', '.join(missing[:6])}{' ...' if len(missing) > 6 else ''}. Download the sample CSV to see the format.")
    if b["prep"].n_conditions > 1:
        miss = [c for c in SETTING_COLS if c not in df.columns]
        if miss:
            raise ApiError(422, f"{ds} has several operating conditions, so the columns {', '.join(SETTING_COLS)} are required.")
    for c in SETTING_COLS + SENSOR_COLS:
        if c not in df.columns:
            df[c] = 0.0
    if df[["cycle"] + b["prep"].sensors].isna().any().any():
        raise ApiError(422, "the file contains empty or non-numeric values in required columns")
    from src import zoo
    key = (ds, mid)
    with _lock:
        if key not in _predictors:
            try:
                _predictors[key] = zoo.ZooPredictor(ROOT, ds, mid)
            except Exception as exc:
                raise ApiError(503, f"could not prepare model: {exc}")
    zp = _predictors[key]
    try:
        tl, feat = zp.timeline(df)
        from src.rul_core import engine_windows
        W = engine_windows(feat, zp.window)
        occ = zp.occlusion(W[-1])
    except RuntimeError as exc:
        raise ApiError(503, str(exc))
    last = tl.iloc[-1]
    rul = float(last.rul_pred)
    st = status_from_rul(rul)
    names = zp.prep.features
    imp = sorted([dict(feature=f, label=SENSOR_INFO.get(f, ("cycles run",))[0], value=v, trend=trend_arrow(W[-1][:, k])) for k, (f, v) in enumerate(zip(names, occ))],
                 key=lambda d: -abs(d["value"]))[:10]
    return dict(model=mid, model_name=b["ready"][mid]["name"], cycles_received=int(len(df)), cycle=int(last.cycle), rul=rul,
                health_pct=health_percent(rul, zp.cap), anomaly=float(last.anomaly_score), anomaly_flag=bool(last.anomaly_score > 0.5), status=st, action=ACTIONS[st],
                cap=zp.cap, cycles=tl.cycle.tolist(), rul_pred=tl.rul_pred.round(2).tolist(), anomaly_series=tl.anomaly_score.round(3).tolist(), importance=imp)


# ---- photos ------------------------------------------------------------------------------------
def r_registry(q, body, headers):
    ds = q.get("ds", [None])[0]
    reg = imageid.Registry(ROOT)
    return [dict(e, url=f"/photos/{e['file']}", name=f"M-{e['unit']:03d}") for e in reg.entries() if not ds or e["ds"] == ds]


def r_image_identify(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    if not body:
        raise ApiError(400, "no image received")
    try:
        info, h = imageid.image_info(body), imageid.dhash(body)
    except Exception:
        raise ApiError(415, "this file is not a readable image (use JPG, PNG or WEBP)")
    fname = unquote(headers.get("x-filename", ""))
    units = set(b["fleet0"].index)
    reg = imageid.Registry(ROOT)
    res = dict(image=info, hash=h, filename=fname, dataset=ds, unit=None, method=None, confidence=None)
    u = imageid.unit_from_filename(fname)
    if u in units:
        res.update(unit=u, method="file name", confidence=1.0, note=f"The file name contains the machine ID M-{u:03d}.")
        return res
    m = reg.match(h, ds) or reg.match(h)
    if m:
        d, e = m
        res.update(unit=e["unit"], dataset=e["ds"], method="photo match", confidence=round(1 - d / 64, 3),
                   note=f"This photo matches the registered photo of M-{e['unit']:03d} (difference {d}/64 bits).")
        return res
    res["note"] = "This photo is not registered yet. Choose the machine it shows, then register it so it is recognised next time."
    return res


def r_image_register(q, body, headers):
    ds = q.get("ds", [""])[0]
    b = bundle(ds)
    u = _unit(b, q)
    try:
        e = imageid.Registry(ROOT).add(ds, u, body, source="user")
    except Exception:
        raise ApiError(415, "this file is not a readable image (use JPG, PNG or WEBP)")
    return dict(ok=True, entry=dict(e, url=f"/photos/{e['file']}", name=f"M-{u:03d}"))


ROUTES = {("GET", "/api/health"): r_health, ("GET", "/api/datasets"): r_datasets, ("GET", "/api/models"): r_models,
          ("GET", "/api/fleet"): r_fleet, ("GET", "/api/lab"): r_lab, ("GET", "/api/engine"): r_engine, ("GET", "/api/compare"): r_compare,
          ("GET", "/api/sample.csv"): r_sample_csv, ("POST", "/api/predict"): r_predict, ("GET", "/api/registry"): r_registry,
          ("POST", "/api/image/identify"): r_image_identify, ("POST", "/api/image/register"): r_image_register}


# ------------------------------------------------------------------------------------------------ dispatcher
def _json(status, obj):
    return status, {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"}, json.dumps(clean(obj), separators=(",", ":")).encode()


def _static(path):
    if path.startswith("/photos/"):
        base, rel = ROOT / "artifacts" / "registry" / "photos", path[len("/photos/"):]
    else:
        base, rel = WEB, "index.html" if path in ("/", "") else path.lstrip("/")
    f = (base / unquote(rel)).resolve()
    if base.resolve() not in f.parents and f != base.resolve():
        return 403, {"Content-Type": "text/plain"}, b"forbidden"
    if not f.is_file():
        if path.startswith("/api") or "." in Path(rel).name:
            return _json(404, {"error": f"not found: {path}"})
        f = WEB / "index.html"                                   # single-page app: unknown route -> app shell
    ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
    if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
        ctype += "; charset=utf-8" if "charset" not in ctype else ""
    return 200, {"Content-Type": ctype, "Cache-Control": "no-cache"}, f.read_bytes()


def handle(method, raw_path, headers=None, body=b""):
    headers = {k.lower(): v for k, v in (headers or {}).items()}
    method = method.upper()
    u = urlparse(raw_path)
    path, q = u.path.rstrip("/") or "/", parse_qs(u.query)
    try:
        if path == "/api":
            return _json(200, dict(name="Predictive Maintenance & RUL API", routes=[f"{m} {p}" for m, p in ROUTES]))
        fn = ROUTES.get(("GET" if method == "HEAD" else method, path))
        if fn is None:
            if path.startswith("/api/"):
                return _json(404 if not any(p == path for _, p in ROUTES) else 405, {"error": f"no such endpoint: {method} {path}"})
            if method not in ("GET", "HEAD"):
                return _json(405, {"error": "method not allowed"})
            st, h, b = _static(path)
            return st, h, (b"" if method == "HEAD" else b)
        if len(body or b"") > MAX_BODY:
            raise ApiError(413, "upload too large (max 20 MB)")
        out = fn(q, body, headers)
        if isinstance(out, tuple):                               # (content_type, bytes, extra_headers)
            ct, data, extra = out
            return 200, dict({"Content-Type": ct + "; charset=utf-8", "Cache-Control": "no-store"}, **extra), data
        return _json(200, out)
    except ApiError as e:
        return _json(e.status, {"error": e.message})
    except Exception as e:                                       # never leak a stack trace to the browser
        return _json(500, {"error": f"{type(e).__name__}: {e}"})
