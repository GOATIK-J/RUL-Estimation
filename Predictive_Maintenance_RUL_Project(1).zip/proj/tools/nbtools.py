"""Tiny helpers to write .ipynb files without nbformat, and to execute them headlessly for testing."""
import json
from pathlib import Path


def md(text):
    return {"cell_type": "markdown", "metadata": {}, "source": text.strip("\n").splitlines(True)}


def code(text):
    return {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": text.strip("\n").splitlines(True)}


def writefile_cell(path, root):
    body = (Path(root) / path).read_text().rstrip("\n")
    return code(f"%%writefile {path}\n{body}")


def save_notebook(cells, path):
    nb = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                                      "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}
    Path(path).write_text(json.dumps(nb, indent=1))


def run_notebook(path, workdir, patch=None, verbose=True):
    """Execute code cells in one namespace (handles %%writefile and strips other % / ! lines). For testing only."""
    import io, os, sys, traceback, contextlib
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.show = lambda *a, **k: plt.close("all")
    nb = json.loads(Path(path).read_text())
    os.chdir(workdir)
    sys.path.insert(0, str(workdir))
    ns = {"__name__": "__main__", "display": lambda *a: [print(x.to_string() if hasattr(x, "to_string") else x) for x in a]}
    if patch:
        patch()
    for i, c in enumerate(nb["cells"]):
        if c["cell_type"] != "code":
            continue
        src = "".join(c["source"])
        if src.startswith("%%writefile"):
            first, _, body = src.partition("\n")
            target = Path(workdir) / first.split(maxsplit=1)[1].strip()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(body + "\n")
            continue
        src = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith(("%", "!")))
        try:
            exec(compile(src, f"{Path(path).name}:cell{i}", "exec"), ns)
        except Exception:
            print(f"\n!!! ERROR in cell {i} of {Path(path).name}:\n{src[:600]}\n")
            traceback.print_exc()
            raise
    return ns
