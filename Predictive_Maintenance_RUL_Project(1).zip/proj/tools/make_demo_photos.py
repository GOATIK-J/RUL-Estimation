"""Creates illustrated sample 'machine photos' and registers them (so the Photo page can be demonstrated without real photos).
Usage:  python tools/make_demo_photos.py"""
import io
import math
import random
import sys
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import imageid  # noqa: E402


def font(size):
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def draw_engine(unit, ds, seed):
    rnd = random.Random(seed * 7919 + unit)
    W, H = 960, 640
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    tint = rnd.choice([(0, 6, 12), (4, 8, 8), (10, 4, 0), (0, 0, 0), (6, 6, 12)])      # muted hangar tints
    g1, g2 = rnd.randint(170, 220), rnd.randint(50, 105)
    top = tuple(min(255, g1 + t) for t in tint); bot = tuple(min(255, g2 + t) for t in tint)
    vertical = rnd.random() < 0.6
    for i in range(H if vertical else W):                                  # hangar gradient (direction varies)
        t = i / ((H if vertical else W) - 1)
        c = tuple(int(top[k] * (1 - t) + bot[k] * t) for k in range(3))
        d.line([(0, i), (W, i)] if vertical else [(i, 0), (i, H)], fill=c)
    for _ in range(rnd.randint(3, 7)):                                     # hangar structure
        x = rnd.randint(0, W); d.rectangle([x, 0, x + rnd.randint(8, 40), rnd.randint(120, 330)], fill=tuple(max(0, v - 35) for v in top))
    d.rectangle([0, int(H * 0.78), W, H], fill=(52, 58, 64))
    s = rnd.uniform(0.8, 1.15); cx, cy = int(W * rnd.uniform(0.4, 0.6)), int(H * rnd.uniform(0.42, 0.52)); L, R = 330 * s, 130 * s
    gb = rnd.randint(165, 205); body = (gb, gb + 4, gb + 8)
    d.polygon([(cx - L, cy - R), (cx + L * 0.65, cy - R * 0.82), (cx + L * 0.95, cy - R * 0.45), (cx + L * 0.95, cy + R * 0.45), (cx + L * 0.65, cy + R * 0.82), (cx - L, cy + R)], fill=body, outline=(30, 36, 42))
    d.rectangle([cx - L * 0.1, cy - R - 70 * s, cx + L * 0.35, cy - R + 6], fill=tuple(v - 25 for v in body), outline=(30, 36, 42))   # pylon
    d.ellipse([cx - L - 38 * s, cy - R, cx - L + 38 * s, cy + R], fill=(24, 30, 36), outline=(210, 218, 224), width=6)               # intake
    n = rnd.choice([10, 12, 14, 18])
    for k in range(n):
        a = 2 * math.pi * k / n + rnd.random() * 0.1
        d.line([(cx - L, cy), (cx - L + 30 * s * math.cos(a), cy + (R - 6) * math.sin(a))], fill=(120, 132, 142), width=5)
    d.ellipse([cx - L - 8, cy - 12, cx - L + 8, cy + 12], fill=(200, 208, 214))
    d.polygon([(cx + L * 0.95, cy - R * 0.4), (cx + L * 1.28, cy), (cx + L * 0.95, cy + R * 0.4)], fill=(88, 96, 104), outline=(30, 36, 42))   # exhaust cone
    for _ in range(rnd.randint(2, 5)):                                    # panel lines
        x = rnd.randint(int(cx - L * 0.6), int(cx + L * 0.8)); d.line([(x, cy - R * 0.7), (x, cy + R * 0.7)], fill=tuple(v - 40 for v in body), width=2)
    px, py = rnd.choice([(0.08, 0.08), (0.62, 0.08), (0.08, 0.84), (0.62, 0.84)])
    x0, y0 = int(W * px), int(H * py)
    d.rectangle([x0, y0, x0 + 300, y0 + 78], fill=(245, 214, 70), outline=(20, 20, 20), width=4)
    d.text((x0 + 16, y0 + 8), f"M-{unit:03d}", fill=(15, 15, 15), font=font(40))
    d.text((x0 + 16, y0 + 54), f"Turbofan · {ds}", fill=(40, 40, 40), font=font(16))
    return im


def main():
    reg = imageid.Registry(ROOT)
    reg.dir.mkdir(parents=True, exist_ok=True)
    for e in [e for e in reg.entries() if e["source"] == "demo"]:
        (reg.dir / "photos" / e["file"]).unlink(missing_ok=True)
    kept = [e for e in reg.entries() if e["source"] != "demo"]
    reg._save(kept)
    hashes = []
    for ds in sorted(p.name for p in (ROOT / "artifacts" / "final").glob("FD*")):
        fl = pd.read_csv(ROOT / "artifacts" / "final" / ds / "fleet_summary.csv").sort_values("rul_pred")
        picks = list(fl[fl.status == "CRITICAL"].unit_id[:2]) + list(fl[fl.status == "WARNING"].unit_id[::max(1, (fl.status == "WARNING").sum() // 2)][:2]) + list(fl[fl.status == "HEALTHY"].unit_id[-2:])
        for u in picks:
            for seed in range(50):                                         # make sure no two sample photos look alike to the matcher
                im = draw_engine(int(u), ds, seed)
                buf = io.BytesIO(); im.save(buf, "PNG"); h = imageid.dhash(buf.getvalue())
                if all(imageid.hamming(h, x) > 2 * imageid.HASH_THRESHOLD for x in hashes):
                    break
            hashes.append(h)
            reg.add(ds, int(u), buf.getvalue(), source="demo")
            print("sample photo", ds, f"M-{int(u):03d}")


if __name__ == "__main__":
    main()
