from nbtools import md, code, writefile_cell


def cells(root):
    C = []
    C.append(md("""
# Phase 1 — Data Audit & Exploratory Data Analysis
### Deep Learning-Based Predictive Maintenance and Remaining Useful Life (RUL) Estimation  ·  TensorFlow / Keras

**Goal of this phase:** understand the data *before* modelling. We (1) obtain the NASA C-MAPSS turbofan dataset, (2) audit its quality,
(3) explore how sensors behave as an engine degrades, and (4) turn what we see into **concrete preprocessing decisions** for Phase 2.

**Run order:** Phase 1 → Phase 2 → Phase 3. This notebook is *self-contained*: it writes the small helper library `src/rul_core.py` itself.

| Term | Meaning |
|---|---|
| Engine / unit | one machine followed from new until failure (training) or until a random cut-off (test) |
| Cycle | one flight = one row of 21 sensor readings + 3 operating settings |
| RUL | Remaining Useful Life = cycles left before failure |
| FD001…FD004 | four sub-datasets (1 or 6 operating conditions, 1 or 2 fault modes) |
"""))
    C.append(md("## 0. Shared helper library\nThis cell writes `src/rul_core.py` (data loading, preprocessing, windowing, metrics). It is plain NumPy / pandas / scikit-learn — no deep-learning framework is needed in Phase 1 or 2."))
    C.append(writefile_cell("src/rul_core.py", root))
    C.append(writefile_cell("src/viz.py", root))
    C.append(code("""
import sys, os, json, warnings, random
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
DATA_DIR = ROOT / "data" / "raw"
OUT = ROOT / "artifacts" / "phase1"; FIG = OUT / "figures"
for d in (DATA_DIR, FIG): d.mkdir(parents=True, exist_ok=True)
try: display
except NameError: display = print

from src.rul_core import *
from src import viz
np.random.seed(SEED); random.seed(SEED)
ALL_SETS = ["FD001", "FD002", "FD003", "FD004"]
print("Project root:", ROOT)
"""))
    C.append(md("## 1. Get the dataset\nThe cell reuses the files if they are already in `data/raw/`; otherwise it tries to download them from NASA. If your network blocks the download, simply drop `CMAPSSData.zip` into `data/raw/` (Colab: Files panel → drag & drop) and run the cell again."))
    C.append(code("""
files = ensure_dataset(DATA_DIR, ALL_SETS)
raw = {c: dict(zip(("train", "test", "rul"), load_subset(files, c))) for c in ALL_SETS}
for c in ALL_SETS:
    print(c, "train", raw[c]["train"].shape, "| test", raw[c]["test"].shape, "| test RUL labels", len(raw[c]["rul"]))
display(raw["FD001"]["train"].head())
"""))
    C.append(md("""
## 2. What does each column mean? (data dictionary)
Every row = one engine at one cycle. Besides `unit_id` and `cycle` there are **3 operating settings** and **21 sensors**.
There is **no vibration sensor** in C-MAPSS; fan speed `Nf` and core speed `Nc` are the closest rotating-machinery analogue.
"""))
    C.append(code("""
catalogue = pd.DataFrame([(k, v[0], v[1]) for k, v in SENSOR_INFO.items()], columns=["column", "symbol", "meaning"])
display(catalogue)
catalogue.to_csv(OUT / "sensor_catalogue.csv", index=False)
"""))
    C.append(md("## 3. The four sub-datasets at a glance"))
    C.append(code("""
rows = []
for c, d in raw.items():
    life = d["train"].groupby("unit_id")["cycle"].max()
    rows.append(dict(dataset=c, description=DATASET_CFG[c]["description"], train_engines=d["train"].unit_id.nunique(),
                     test_engines=d["test"].unit_id.nunique(), train_rows=len(d["train"]), test_rows=len(d["test"]),
                     life_min=life.min(), life_median=life.median(), life_max=life.max(),
                     shortest_test_history=d["test"].groupby("unit_id").size().min()))
overview = pd.DataFrame(rows); display(overview); overview.to_csv(OUT / "dataset_overview.csv", index=False)
"""))
    C.append(md("""
## 4. Data-quality audit
We never trust data blindly. Checks: missing values, non-finite values, duplicate (engine, cycle) rows, cycle ordering, constant columns,
and whether the number of official test-RUL labels equals the number of test engines.
"""))
    C.append(code("""
audit = []
for c, d in raw.items():
    for split in ("train", "test"):
        f = d[split]; num = f.select_dtypes("number").to_numpy(float)
        const = [col for col in SETTING_COLS + SENSOR_COLS if f[col].nunique() <= 1]
        ordered = all(g["cycle"].is_monotonic_increasing and g["cycle"].iloc[0] == 1 for _, g in f.groupby("unit_id"))
        audit.append(dict(dataset=c, split=split, rows=len(f), engines=f.unit_id.nunique(), missing=int(f.isna().sum().sum()),
                          non_finite=int((~np.isfinite(num)).sum()), duplicate_rows=int(f.duplicated(["unit_id", "cycle"]).sum()),
                          cycles_ordered_from_1=ordered, constant_columns=len(const)))
audit_df = pd.DataFrame(audit); display(audit_df); audit_df.to_csv(OUT / "audit_table.csv", index=False)
labels_ok = {c: len(d["rul"]) == d["test"].unit_id.nunique() for c, d in raw.items()}
print("Test RUL label count matches number of test engines:", labels_ok)
assert audit_df[["missing", "non_finite", "duplicate_rows"]].sum().sum() == 0 and all(labels_ok.values()) and audit_df.cycles_ordered_from_1.all()
print("AUDIT PASSED: no missing / non-finite / duplicate values; cycles ordered; labels consistent.")
"""))
    C.append(code("""
const_by_set = {c: [col for col in SETTING_COLS + SENSOR_COLS if raw[c]["train"][col].nunique() <= 1] for c in ALL_SETS}
for c, cols in const_by_set.items(): print(f"{c}: constant columns = {cols}")
print("\\nObservation: in the single-condition sets (FD001/FD003) several sensors never change -> they carry no information and will be dropped.")
print("In the 6-condition sets (FD002/FD004) nothing is constant *raw*, but most sensors only change because the operating condition changes.")
"""))
    C.append(md("## 5. EDA ① — How long do engines live?\nEngines fail after very different numbers of cycles, so we cannot predict RUL from the cycle count alone."))
    C.append(code("""
fig, axs = plt.subplots(1, 4, figsize=(15, 3.2), sharey=True)
for ax, c in zip(axs, ALL_SETS):
    life = raw[c]["train"].groupby("unit_id")["cycle"].max()
    ax.hist(life, bins=18, color=viz.BLUE); ax.axvline(life.median(), color=viz.WARN, ls="--"); ax.set_title(f"{c}  (median {life.median():.0f})"); ax.set_xlabel("cycles until failure")
axs[0].set_ylabel("engines"); fig.suptitle("Engine lifetime in the training sets", y=1.04, fontweight="bold")
fig.savefig(FIG / "01_lifetimes.png", bbox_inches="tight"); plt.show()
"""))
    C.append(md("## 6. EDA ② — Which sensors reveal degradation?\nWe align engines by *time to failure* (x = 0 is failure). A useful sensor shows a consistent drift as failure approaches."))
    C.append(code("""
tr1 = add_rul(raw["FD001"]["train"])
informative = [s for s in SENSOR_COLS if tr1[s].nunique() > 1]
rho = tr1[informative + ["RUL_raw"]].corr(method="spearman")["RUL_raw"].drop("RUL_raw").sort_values()
top = rho.abs().sort_values(ascending=False).head(4).index.tolist()
fig, axs = plt.subplots(1, 4, figsize=(15, 3.3))
for ax, s in zip(axs, top):
    for u in tr1.unit_id.unique()[:10]:
        g = tr1[tr1.unit_id == u]; ax.plot(-g["RUL_raw"], g[s], lw=1, alpha=0.8)
    ax.set_title(f"{s} ({SENSOR_INFO[s][0]})  ρ={rho[s]:+.2f}", fontsize=10); ax.set_xlabel("cycles before failure")
fig.suptitle("FD001: the four most RUL-correlated sensors (10 engines)", y=1.04, fontweight="bold")
fig.savefig(FIG / "02_sensor_degradation.png", bbox_inches="tight"); plt.show()
print("Sensors with strongest monotonic relation to RUL:", ", ".join(f"{s} ({rho[s]:+.2f})" for s in top))
"""))
    C.append(code("""
fig, ax = plt.subplots(figsize=(9, 4.2))
colors = [viz.CRIT if abs(v) > 0.5 else viz.BLUE for v in rho.values]
ax.barh(rho.index, rho.values, color=colors); ax.axvline(0, color=viz.MUTED)
ax.set_xlabel("Spearman correlation with RUL (FD001 training data)"); ax.set_title("Sensor relevance (red = |ρ| > 0.5)")
fig.savefig(FIG / "03_sensor_correlation.png", bbox_inches="tight"); plt.show()
print("Sensors that are almost uncorrelated with RUL add noise; the deep model will learn to ignore them, but constant ones are removed outright.")
"""))
    C.append(md("""
## 7. EDA ③ — Why FD004 is hard: six operating conditions
In FD002/FD004 the engine is flown at 6 different *operating conditions* (altitude, Mach number, throttle). A sensor then jumps up and down with the
condition — much more than it changes with wear. **If we scale all rows together, the model sees condition noise instead of degradation.**
The fix is to normalise each sensor **within its operating condition**.
"""))
    C.append(code("""
tr4 = add_rul(raw["FD004"]["train"])
p4 = Preprocessor(n_conditions=6, smooth_span=1, use_cycle=False).fit(tr4)
u = tr4.unit_id.iloc[0]; g = tr4[tr4.unit_id == u].sort_values("cycle")
z = p4.transform_engine(g); j = p4.sensors.index("sensor_11")
cond = p4._cond(g)
fig, axs = plt.subplots(1, 3, figsize=(15, 3.6))
sc = axs[0].scatter(tr4["setting_1"], tr4["setting_2"], c=p4._cond(tr4), cmap="tab10", s=2); axs[0].set_xlabel("setting_1 (altitude)"); axs[0].set_ylabel("setting_2 (Mach)"); axs[0].set_title("6 operating conditions found by k-means")
axs[1].plot(g["cycle"], g["sensor_11"], color=viz.WARN, lw=0.9); axs[1].set_title("RAW sensor_11 of one FD004 engine\\n(dominated by condition jumps)"); axs[1].set_xlabel("cycle")
axs[2].plot(g["cycle"], z[:, j], color=viz.OK, lw=0.9); axs[2].set_title("Per-condition NORMALISED sensor_11\\n(degradation trend is visible)"); axs[2].set_xlabel("cycle")
fig.savefig(FIG / "04_operating_conditions.png", bbox_inches="tight"); plt.show()
print("Decision: normalise every sensor per operating condition (Phase 2).")
"""))
    C.append(md("## 8. EDA ④ — The RUL target: why we cap it at 125\nAn engine that is brand new does not 'look' 300 cycles from failure and 250 cycles from failure differently: degradation only becomes visible late in life. A *piece-wise linear* target (flat at 125, then linearly down to 0) is the standard, physically sensible choice."))
    C.append(code("""
g = tr1[tr1.unit_id == 1]
fig, ax = plt.subplots(figsize=(8, 3.4))
ax.plot(g["cycle"], g["RUL_raw"], color=viz.MUTED, ls="--", label="raw RUL (linear)"); ax.plot(g["cycle"], g["RUL"], color=viz.BLUE, lw=2.5, label=f"capped RUL (cap={RUL_CAP})")
ax.set_xlabel("cycle"); ax.set_ylabel("RUL"); ax.set_title("Piece-wise linear RUL target (engine 1, FD001)"); ax.legend()
fig.savefig(FIG / "05_rul_cap.png", bbox_inches="tight"); plt.show()
"""))
    C.append(md("## 9. What did we learn? → decisions for Phase 2"))
    C.append(code("""
decisions = {
 "constant_columns_FD001": const_by_set["FD001"],
 "top_sensors_FD001": top,
 "operating_conditions": {c: DATASET_CFG[c]["n_conditions"] for c in ALL_SETS},
 "rul_cap": RUL_CAP,
 "decisions": [
   "Split train/validation BY ENGINE (rows of one engine are highly correlated -> row-wise split would leak).",
   "Fit all scalers on training engines only.",
   "Normalise sensors per operating condition (needed for FD002/FD004).",
   "Drop constant sensors; keep the rest (the network decides which matter).",
   "Smooth sensors causally (exponential moving average) to suppress noise without using future data.",
   "Use a piece-wise linear RUL target (cap 125) and evaluate on the official test protocol: LAST window of each test engine."],
}
(OUT / "phase1_findings.json").write_text(json.dumps(decisions, indent=2))
for d in decisions["decisions"]: print("•", d)
print("\\nPHASE 1 COMPLETE ✔  — figures in", FIG)
"""))
    return C
