from nbtools import md, code, writefile_cell


def cells(root):
    C = []
    C.append(md("""
# Phase 2 — Preprocessing, RUL Labels & Time-Series Windowing
### Deep Learning-Based Predictive Maintenance and RUL Estimation  ·  TensorFlow / Keras

**Goal:** convert raw sensor tables into clean, leak-free tensors `X (samples, time-steps, features)` and targets `y (RUL)` that a neural network can learn from.

Pipeline for every dataset (FD001 = easy benchmark, FD004 = hardest, 6 operating conditions):

`raw rows → RUL labels → engine-level train/validation split → fit preprocessing on TRAIN engines only → per-condition scaling → drop constant sensors → causal smoothing → sliding windows → save`

> **Anti-leakage rules used here:** (1) split by *engine*, never by row; (2) every statistic (means, std, clusters, healthy baseline) is learnt from training engines only; (3) smoothing is causal (uses only the past).
"""))
    C.append(writefile_cell("src/rul_core.py", root))
    C.append(writefile_cell("src/viz.py", root))
    C.append(code("""
import sys, os, json, warnings, random
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")

ROOT = Path.cwd(); sys.path.insert(0, str(ROOT))
DATA_DIR = ROOT / "data" / "raw"; PROC = ROOT / "data" / "processed"
OUT = ROOT / "artifacts" / "phase2"; FIG = OUT / "figures"
for d in (DATA_DIR, PROC, FIG): d.mkdir(parents=True, exist_ok=True)
try: display
except NameError: display = print
from src.rul_core import *
from src import viz
np.random.seed(SEED); random.seed(SEED)

# ---------------- configuration (change here) ----------------
DATASETS = ["FD001", "FD004"]   # FD001 = main benchmark, FD004 = hardest (6 conditions). Add "FD002"/"FD003" if you wish.
VAL_FRACTION = 0.20             # fraction of training ENGINES held out for validation / early stopping
SMOOTH_SPAN = 20                # exponential smoothing span (cycles); 1 = off. Chosen by 5-fold cross-validation over TRAIN engines (span 5: RMSE 12.5, 20: 10.6 on FD001)
USE_CYCLE = True                # add 'operating cycles so far' as an input feature
print("Configuration:", dict(DATASETS=DATASETS, RUL_CAP=RUL_CAP, VAL_FRACTION=VAL_FRACTION, SMOOTH_SPAN=SMOOTH_SPAN, USE_CYCLE=USE_CYCLE))
"""))
    C.append(md("## 1. Load data"))
    C.append(code("""
files = ensure_dataset(DATA_DIR, DATASETS)
S = {}
for c in DATASETS:
    train, test, rul = load_subset(files, c)
    S[c] = dict(train=add_rul(train), test=test, rul=rul, cfg=DATASET_CFG[c])
    print(c, "| train", S[c]["train"].shape, "| test", test.shape, "| window =", S[c]["cfg"]["window"], "| conditions =", S[c]["cfg"]["n_conditions"])
"""))
    C.append(md("""
## 2. Target: Remaining Useful Life
For a training engine that ran for 192 cycles, cycle 150 has RUL = 192 − 150 = 42. We then **cap at 125**
(`RUL = min(RUL, 125)`) — a healthy engine is simply "healthy", the exact number of cycles before the fault starts is unknowable from sensors.
"""))
    C.append(code("""
d = S["FD001"]["train"]
display(d[["unit_id", "cycle", "RUL_raw", "RUL"]].iloc[[0, 1, 70, 71, 100, 190, 191]])
"""))
    C.append(md("""
## 3. Train / validation split **by engine**
Rows of the same engine are almost copies of each other. If neighbouring rows of one engine landed in both train and validation, the model could
memorise the engine and the validation score would be fake. We therefore hold out **whole engines**.
"""))
    C.append(code("""
for c in DATASETS:
    tr_ids, va_ids = split_engines(S[c]["train"]["unit_id"].unique(), VAL_FRACTION)
    assert not set(tr_ids) & set(va_ids), "leakage!"
    S[c].update(tr_ids=tr_ids, va_ids=va_ids,
                tr_df=S[c]["train"][S[c]["train"].unit_id.isin(tr_ids)], va_df=S[c]["train"][S[c]["train"].unit_id.isin(va_ids)])
    print(f"{c}: {len(tr_ids)} training engines | {len(va_ids)} validation engines | {S[c]['test'].unit_id.nunique()} official test engines   (no overlap ✔)")
pd.DataFrame([dict(dataset=c, unit_id=int(u), split=s) for c in DATASETS for s, ids in (("train", S[c]["tr_ids"]), ("validation", S[c]["va_ids"])) for u in ids]).to_csv(OUT / "engine_splits.csv", index=False)
"""))
    C.append(md("""
## 4. Fit the preprocessor on training engines
`Preprocessor.fit` learns, **from training engines only**: the operating-condition clusters (k-means, FD002/FD004), the per-condition mean/std of every sensor, and which sensors are constant.
`transform_engine` then: z-scores per condition → drops constant sensors → smooths causally → appends the cycle feature.
"""))
    C.append(code("""
for c in DATASETS:
    cfg = S[c]["cfg"]
    prep = Preprocessor(cfg["n_conditions"], SMOOTH_SPAN, USE_CYCLE, RUL_CAP, cfg["window"]).fit(S[c]["tr_df"])
    S[c]["prep"] = prep
    dropped = [s for s in SENSOR_COLS if s not in prep.sensors]
    print(f"{c}: keeps {len(prep.sensors)} sensors, drops constant {dropped}; model input features = {prep.n_features}")
"""))
    C.append(md("### What preprocessing does to the signal (one FD004 engine)"))
    C.append(code("""
c = "FD004" if "FD004" in S else DATASETS[-1]
g = S[c]["tr_df"][S[c]["tr_df"].unit_id == S[c]["tr_ids"][0]].sort_values("cycle")
p0 = Preprocessor(S[c]["cfg"]["n_conditions"], 1, False, RUL_CAP, S[c]["cfg"]["window"]).fit(S[c]["tr_df"])   # no smoothing, for comparison
j = p0.sensors.index("sensor_11"); jj = S[c]["prep"].sensors.index("sensor_11")
fig, axs = plt.subplots(1, 3, figsize=(15, 3.4))
axs[0].plot(g["cycle"], g["sensor_11"], color=viz.WARN, lw=0.9); axs[0].set_title("① raw sensor_11")
axs[1].plot(g["cycle"], p0.transform_engine(g)[:, j], color=viz.BLUE, lw=0.9); axs[1].set_title("② per-condition z-score")
axs[2].plot(g["cycle"], S[c]["prep"].transform_engine(g)[:, jj], color=viz.OK, lw=1.6); axs[2].set_title("③ + causal smoothing")
for a in axs: a.set_xlabel("cycle")
fig.suptitle(f"{c}: raw → normalised → smoothed", y=1.04, fontweight="bold"); fig.savefig(FIG / "preprocessing_effect.png", bbox_inches="tight"); plt.show()
"""))
    C.append(md("""
## 5. Sliding windows
The network does not look at one row; it looks at the **last `window` cycles** (30 for single-condition sets, 40 for 6-condition sets) so it can see *trends*.
Window `i` ends at cycle `i` and is paired with the RUL at that cycle. For the first cycles, the first row is repeated to fill the window (so even a short test history works).
Training windows of FD004 use stride 2 (neighbouring windows are nearly identical).
**Test protocol (official):** one window per test engine = its **last** observed cycles, compared with the official RUL file.
"""))
    C.append(code("""
for c in DATASETS:
    cfg, prep = S[c]["cfg"], S[c]["prep"]; w = cfg["window"]
    Xtr, ytr, ytr_raw, utr, ctr = build_windows(prep, S[c]["tr_df"], w, cfg["train_stride"])
    Xva, yva, yva_raw, uva, cva = build_windows(prep, S[c]["va_df"], w, 1)
    Xte, yte_raw, ute, last = build_test_windows(prep, S[c]["test"], S[c]["rul"], w)
    S[c].update(Xtr=Xtr, ytr=ytr, Xva=Xva, yva=yva, yva_raw=yva_raw, Xte=Xte, yte_raw=yte_raw, ute=ute)
    print(f"{c}: X_train {Xtr.shape} | X_val {Xva.shape} | X_test {Xte.shape}   (samples, time-steps, features)")
    assert np.isfinite(Xtr).all() and np.isfinite(Xva).all() and np.isfinite(Xte).all()
    assert not set(utr) & set(uva)
"""))
    C.append(code("""
c = DATASETS[0]; X = S[c]["Xte"][0]; names = S[c]["prep"].features
fig, ax = plt.subplots(figsize=(11, 4.2))
im = ax.imshow(X.T, aspect="auto", cmap="coolwarm", vmin=-3, vmax=3); ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=8); ax.grid(False)
ax.set_xlabel("time step inside the window (oldest → newest)"); ax.set_title(f"{c}: ONE model input = {X.shape[0]} time-steps × {X.shape[1]} features"); plt.colorbar(im, label="z-score")
fig.savefig(FIG / "example_window.png", bbox_inches="tight"); plt.show()
"""))
    C.append(code("""
fig, axs = plt.subplots(1, len(DATASETS), figsize=(6 * len(DATASETS), 3.2), squeeze=False)
for ax, c in zip(axs[0], DATASETS):
    ax.hist(S[c]["ytr"], bins=40, color=viz.BLUE, alpha=0.9, label="train windows"); ax.hist(np.minimum(S[c]["yte_raw"], RUL_CAP), bins=20, color=viz.WARN, alpha=0.9, label="test engines (capped)")
    ax.set_title(f"{c}: RUL target distribution"); ax.set_xlabel("RUL (cycles)"); ax.legend()
fig.savefig(FIG / "target_distribution.png", bbox_inches="tight"); plt.show()
print("The big bar at 125 is the 'healthy plateau' created by the cap.")
"""))
    C.append(md("""
## 6. Healthy-behaviour baseline for anomaly detection
Anomaly detection needs a notion of *normal*. We learn it, unsupervised, from the **first 25 % of life of the training engines**
(Mahalanobis distance from the healthy sensor distribution). No RUL labels are used for the model itself.
Only the **alarm threshold** is then tuned (maximum F1) on the **validation engines**, where "degraded" means true RUL ≤ 50 cycles. The test engines are never used for this.
"""))
    C.append(code("""
for c in DATASETS:
    det = AnomalyDetector().fit(healthy_rows_from_train(S[c]["prep"], S[c]["tr_df"], 0.25))
    ns = len(S[c]["prep"].sensors); thr0 = det.thr
    f1, thr = det.calibrate(S[c]["Xva"][:, -1, :ns], S[c]["yva_raw"] <= 50)
    S[c]["det"] = det
    print(f"{c}: healthy 99.5th-percentile distance = {thr0:.2f} -> calibrated alarm threshold = {thr:.2f} (validation F1 = {f1:.2f})")
c = DATASETS[0]; g = S[c]["va_df"][S[c]["va_df"].unit_id == S[c]["va_ids"][0]].sort_values("cycle")
sc = S[c]["det"].score(S[c]["prep"].sensor_part(S[c]["prep"].transform_engine(g)))
fig, ax = plt.subplots(figsize=(8, 3)); ax.plot(g["cycle"], sc, color=viz.VIOLET, lw=2); ax.axhline(0.5, color=viz.CRIT, ls="--"); ax.set_title(f"Anomaly score of a validation engine ({c}) - rises as it degrades"); ax.set_xlabel("cycle")
fig.savefig(FIG / "anomaly_example.png", bbox_inches="tight"); plt.show()
"""))
    C.append(md("## 7. Save everything Phase 3 needs"))
    C.append(code("""
manifest = {"rul_cap": RUL_CAP, "val_fraction": VAL_FRACTION, "smooth_span": SMOOTH_SPAN, "use_cycle": USE_CYCLE, "seed": SEED, "datasets": {}}
for c in DATASETS:
    out = PROC / c; out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "arrays.npz", X_train=S[c]["Xtr"], y_train=S[c]["ytr"], X_val=S[c]["Xva"], y_val=S[c]["yva"], y_val_raw=S[c]["yva_raw"],
                        X_test=S[c]["Xte"], y_test_raw=S[c]["yte_raw"], y_test=np.minimum(S[c]["yte_raw"], RUL_CAP), test_units=S[c]["ute"])
    save_json(S[c]["prep"].to_dict(), out / "prep.json"); save_json(S[c]["det"].to_dict(), out / "anomaly.json")
    manifest["datasets"][c] = dict(window=S[c]["cfg"]["window"], n_features=S[c]["prep"].n_features, features=S[c]["prep"].features,
                                   train=list(S[c]["Xtr"].shape), val=list(S[c]["Xva"].shape), test=list(S[c]["Xte"].shape))
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2))
# reload check
for c in DATASETS:
    z = np.load(PROC / c / "arrays.npz"); assert z["X_train"].shape[1:] == z["X_test"].shape[1:] == z["X_val"].shape[1:]
    p = Preprocessor.from_dict(load_json(PROC / c / "prep.json")); g = S[c]["va_df"][S[c]["va_df"].unit_id == S[c]["va_ids"][0]].sort_values("cycle")
    assert np.allclose(p.transform_engine(g), S[c]["prep"].transform_engine(g), atol=1e-5), "saved preprocessor differs!"
    print(f"{c}: saved + reloaded OK  (preprocessor reproduces identical features)")
print("\\nPHASE 2 COMPLETE ✔  — next: Phase 3 (models, evaluation, explainability, compression, export)")
"""))
    return C
