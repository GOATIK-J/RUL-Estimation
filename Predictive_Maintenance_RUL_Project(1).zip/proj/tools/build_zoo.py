"""Rebuild artifacts/zoo from the models already on disk (no training):  python tools/build_zoo.py [FD001 FD004]"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import zoo  # noqa: E402

for ds in (sys.argv[1:] or sorted(p.name for p in (ROOT / "data" / "processed").glob("FD*"))):
    zoo.build_zoo(ROOT, ds)
