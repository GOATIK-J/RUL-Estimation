"""Builds the three phase notebooks from the sources in src/. Usage: python tools/build_all.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from nbtools import save_notebook
import nb_phase1, nb_phase2, nb_phase3

ROOT = Path(__file__).resolve().parent.parent
names = {"01_Phase1_Data_Audit_and_EDA.ipynb": nb_phase1, "02_Phase2_Preprocessing_and_Windowing.ipynb": nb_phase2,
         "03_Phase3_Models_Evaluation_XAI_Deployment.ipynb": nb_phase3}
for fname, mod in names.items():
    save_notebook(mod.cells(ROOT), ROOT / fname)
    print("built", fname)
