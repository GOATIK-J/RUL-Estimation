"""Headless runner used for testing:  python tools/run_nb.py <notebook.ipynb> [--fake-keras]"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from nbtools import run_notebook
nb = Path(sys.argv[1]).resolve()
patch = None
if "--fake-keras" in sys.argv:
    def patch():
        sys.path.insert(0, str(nb.parent / "tests"))
        import fake_keras
        fake_keras.install()
run_notebook(nb, nb.parent, patch=patch)
