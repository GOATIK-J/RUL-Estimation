"""
Train the six TensorFlow/Keras models and rebuild the model zoo shown in the web app.

    pip install tensorflow
    python tools/train_deep_models.py                   # all datasets, 6 architectures x 3 seeds (about 20-40 min on a laptop CPU)
    python tools/train_deep_models.py --quick           # 1 seed, 8 epochs: a few minutes, good for a first test
    python tools/train_deep_models.py --datasets FD001 --archs lstm gru

Needs the Phase-2 outputs (data/processed) and the Phase-3 exports (artifacts/final).  Afterwards run:  python run.py
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import zoo  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=None)
    ap.add_argument("--archs", nargs="+", default=None, choices=zoo.DEEP_ARCHS)
    ap.add_argument("--seeds", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--force", action="store_true", help="retrain even if weights already exist")
    ap.add_argument("--no-train", action="store_true", help="only rebuild the zoo from existing weights")
    a = ap.parse_args()
    datasets = a.datasets or sorted(p.name for p in (ROOT / "data" / "processed").glob("FD*") if (p / "arrays.npz").exists())
    if not datasets:
        sys.exit("No Phase-2 data in data/processed. Run notebook 02 first.")
    if not a.no_train and not zoo.has_tensorflow():
        sys.exit("TensorFlow is not installed.  Run:  pip install tensorflow   (or use --no-train to rebuild the zoo only)")
    for ds in datasets:
        if not a.no_train:
            zoo.train_deep_suite(ROOT, ds, archs=a.archs, seeds=a.seeds or (1 if a.quick else 3), epochs=a.epochs or (8 if a.quick else 60),
                                 patience=3 if a.quick else 10, force=a.force)
        zoo.build_zoo(ROOT, ds)
    print("\nDone. Start the web app with:  python run.py")


if __name__ == "__main__":
    main()
