from nbtools import md, code, writefile_cell


def cells(root):
    C = []
    C.append(md("""
# Phase 3 — Models, Evaluation, Explainability, Compression & Deployment Export
### Deep Learning-Based Predictive Maintenance and RUL Estimation  ·  **TensorFlow / Keras only**

**What this notebook does**
1. Trains **classical baselines** (Ridge, RandomForest, ExtraTrees, Gradient Boosting) on hand-crafted window statistics.
2. Trains **6 Keras architectures** (MLP, LSTM, GRU, BiLSTM, CNN-LSTM, **CNN-BiLSTM-Attention**) with several random seeds each.
3. Chooses the final model **on the validation engines only** (the official test set is never used for choosing).
4. Reports honest **test metrics** (MAE, RMSE, R², NASA score, anomaly precision/recall/F1) and an **over-fitting check**.
5. Explains predictions (**Integrated Gradients** + model-agnostic occlusion), and compresses the model (**distillation + quantisation**).
6. Exports everything the **FastAPI backend and Streamlit dashboard** need.

**How over-fitting is controlled:** held-out validation *engines*, early stopping with best-weight restore, dropout, L2 weight decay,
input-noise augmentation, learning-rate decay, seed ensembles, and a train-vs-validation-vs-test gap check at the end.

**Run order:** Phase 1 → Phase 2 → Phase 3. Needs `pip install tensorflow scikit-learn joblib matplotlib pandas`.
"""))
    for f in ("src/rul_core.py", "src/rul_models.py", "src/inference.py", "src/viz.py", "src/zoo.py"):
        C.append(writefile_cell(f, root))
    C.append(code("""
import sys, os, json, time, shutil, warnings, random
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import joblib
warnings.filterwarnings("ignore")

ROOT = Path.cwd(); sys.path.insert(0, str(ROOT))
DATA_DIR = ROOT / "data" / "raw"; PROC = ROOT / "data" / "processed"
MODELS = ROOT / "artifacts" / "models"; FINAL = ROOT / "artifacts" / "final"; OUT = ROOT / "artifacts" / "phase3"
for d in (MODELS, FINAL, OUT): d.mkdir(parents=True, exist_ok=True)
try: display
except NameError: display = print

from src.rul_core import *
from src import rul_models as RM
from src.inference import Predictor, export_dashboard_data
from src import viz

# ======================= CONFIGURATION =======================
DATASETS = ["FD001", "FD004"]     # must have been prepared in Phase 2
QUICK_RUN = False                 # True = 5-minute smoke test (1 seed, few epochs). False = full experiment.
ARCHS = ["mlp", "lstm", "gru", "bilstm", "cnn_lstm", "cnn_lstm_attention"]
N_SEEDS = 1 if QUICK_RUN else 3   # seeds per architecture (ensemble members)
EPOCHS = 6 if QUICK_RUN else 60   # upper limit; early stopping normally stops much earlier
PATIENCE = 3 if QUICK_RUN else 10
BATCH = 128
MODEL_KW = dict(units=64, filters=64, dropout=0.2, l2=1e-5, noise=0.03, lr=1e-3)
TARGET_R2 = 0.75
# =============================================================
np.random.seed(SEED); random.seed(SEED)
print("TensorFlow:", RM.TF_VERSION, "| GPUs:", (RM.tf.config.list_physical_devices("GPU") if RM.HAS_TF else "n/a"))
if not RM.HAS_TF:
    print("\\n*** TensorFlow is NOT installed: deep models will be skipped and the best classical model is exported. Run `pip install tensorflow` and re-run for the full deep-learning results. ***")
"""))
    C.append(md("## 1. Load the Phase-2 tensors"))
    C.append(code("""
R = {}
for c in DATASETS:
    z = np.load(PROC / c / "arrays.npz")
    R[c] = dict(z={k: z[k] for k in z.files}, prep=Preprocessor.from_dict(load_json(PROC / c / "prep.json")),
                det=AnomalyDetector.from_dict(load_json(PROC / c / "anomaly.json")), members={}, hist={})
    R[c]["w"], R[c]["F"] = R[c]["z"]["X_train"].shape[1], R[c]["z"]["X_train"].shape[2]
    print(f"{c}: train {R[c]['z']['X_train'].shape} | val {R[c]['z']['X_val'].shape} | test {R[c]['z']['X_test'].shape} | features: {R[c]['prep'].features}")
"""))
    C.append(md("""
## 2. Evaluation metrics — what they mean
| Metric | Meaning | Better |
|---|---|---|
| **MAE** | average absolute error in cycles | lower |
| **RMSE** | like MAE but punishes large errors | lower |
| **R²** | share of RUL variance explained (1 = perfect, 0 = predicting the mean) | higher |
| **NASA score** | asymmetric: *late* predictions (dangerous) cost more than early ones | lower |
| **Within ±10** | % of engines predicted within 10 cycles | higher |

*Validation* = all windows of 20 % held-out training engines (RUL capped at 125, the same target the model learns).
*Test* = the **official** protocol: the last window of every test engine vs NASA's RUL file. We report test R² against the **capped** RUL
(like training) and, to be fully transparent, also against the **raw uncapped** RUL file.
"""))
    C.append(code("""
def metric_row(name, kind, c, pv, pt):
    z = R[c]["z"]; v = regression_metrics(z["y_val"], pv); t = regression_metrics(z["y_test"], pt); r = regression_metrics(z["y_test_raw"], pt)
    return {"Model": name, "Type": kind, "Val_RMSE": v["RMSE"], "Val_MAE": v["MAE"], "Val_R2": v["R2"],
            "Test_RMSE": t["RMSE"], "Test_MAE": t["MAE"], "Test_R2": t["R2"], "Test_R2_rawRUL": r["R2"], "Test_RMSE_rawRUL": r["RMSE"],
            "Test_MAE_rawRUL": r["MAE"], "NASA_score": r["NASA_score"], "Within_10_%": r["Within_10_cycles_%"]}

def member_predict(m, X, cap=RUL_CAP):
    return np.clip(m["model"].predict(flat_features(X)), 0, cap) if m["kind"] == "sklearn" else RM.predict_rul(m["model"], X, cap)
"""))
    C.append(md("## 3. Classical (non-deep) baselines\nInput = 7 statistics per sensor over the window (last value, mean, std, min, max, slope, mean of last 5). These show how far *classical ML* gets, so the deep models have to earn their place."))
    C.append(code("""
for c in DATASETS:
    r, z = R[c], R[c]["z"]
    Ftr, Fva, Fte = (flat_features(z[k]) for k in ("X_train", "X_val", "X_test"))
    t0 = time.time(); models = RM.fit_classical(Ftr, z["y_train"], seed=0, fast=QUICK_RUN)
    for name, m in models.items():
        r["members"][f"sk:{name}"] = dict(kind="sklearn", name=name, model=m, val=np.clip(m.predict(Fva), 0, RUL_CAP), test=np.clip(m.predict(Fte), 0, RUL_CAP))
    print(f"{c}: classical models trained in {time.time() - t0:.0f}s")
    display(pd.DataFrame([metric_row(m["name"], "classical", c, m["val"], m["test"]) for m in r["members"].values()]).round(3).iloc[:, :8])
"""))
    C.append(md("""
## 4. Deep models (Keras)
Input window `(time-steps × features)` → network → one number = RUL/125. Loss = Huber (robust to outliers). Adam optimiser, gradient clipping.

* **MLP** – no memory of time order (control experiment).
* **LSTM / GRU / BiLSTM** – recurrent layers read the window step by step.
* **CNN-LSTM** – 1D convolutions extract local sensor patterns, the LSTM models how they evolve.
* **CNN-BiLSTM-Attention** – adds *temporal attention*: the model learns **which time steps matter** for the current RUL.

Each architecture is trained with several seeds; their average (an *ensemble*) is more accurate and more stable than any single run.
"""))
    C.append(code("""
DEEP_OK = {c: False for c in DATASETS}
if RM.HAS_TF:
    for c in DATASETS:
        r, z = R[c], R[c]["z"]
        for arch in ARCHS:
            t0 = time.time()
            try:
                for s in range(N_SEEDS):
                    RM.set_seed(1000 * (ARCHS.index(arch) + 1) + s)
                    model = RM.build_model(arch, r["w"], r["F"], **MODEL_KW)
                    h = RM.train_model(model, z["X_train"], z["y_train"], z["X_val"], z["y_val"], RUL_CAP, EPOCHS, BATCH, PATIENCE, verbose=0)
                    wpath = RM.save_weights(model, MODELS / c / f"{arch}_s{s}")
                    r["members"][f"keras:{arch}:s{s}"] = dict(kind="keras", name=arch, arch=arch, seed=s, model=model, file=wpath,
                                                              val=RM.predict_rul(model, z["X_val"]), test=RM.predict_rul(model, z["X_test"]))
                    if s == 0: r["hist"][arch] = {k: [float(v) for v in vals] for k, vals in h.history.items()}
                DEEP_OK[c] = True
                v = np.mean([r["members"][f"keras:{arch}:s{s}"]["val"] for s in range(N_SEEDS)], axis=0)
                print(f"{c} | {arch:20s} params={model.count_params():>7,} epochs={len(h.history['loss']):>3} | ensemble val RMSE={regression_metrics(z['y_val'], v)['RMSE']:.2f} | {time.time() - t0:.0f}s")
            except Exception as exc:                      # one failing model must never stop the whole experiment
                print(f"{c} | {arch}: FAILED ({type(exc).__name__}: {str(exc)[:150]}) - skipped")
else:
    print("TensorFlow not available -> skipping deep models.")
"""))
    C.append(code("""
hist_c = DATASETS[0]
if R[hist_c]["hist"]:
    fig = viz.fig_training_curves(R[hist_c]["hist"], FINAL / hist_c / "figures" / "learning_curves.png"); plt.show()
    gaps = {a: h["val_loss"][-1] / max(h["loss"][-1], 1e-9) for a, h in R[hist_c]["hist"].items()}
    print("final val_loss / train_loss ratio per model (≈1-3 = healthy; >>5 would signal over-fitting):", {k: round(v, 2) for k, v in gaps.items()})
"""))
    C.append(md("""
## 5. Model selection — on VALIDATION only
Candidates: every single classical model, every deep architecture (seed-ensemble), a **Deep Top-3 ensemble**, a **Classical ensemble** and a **Hybrid** (deep + classical).
We pick the lowest *validation* RMSE. The test set is not touched for this decision, so the test score is an unbiased estimate.
"""))
    C.append(code("""
def blend(c, weights):
    tot = sum(weights.values()); m = R[c]["members"]
    return (sum(w * m[k]["val"] for k, w in weights.items()) / tot, sum(w * m[k]["test"] for k, w in weights.items()) / tot)

CAND = {}
for c in DATASETS:
    m = R[c]["members"]; cand = {}
    for k, v in m.items():
        if v["kind"] == "sklearn": cand[v["name"]] = ("classical", {k: 1.0})
    for arch in ARCHS:
        ks = [k for k, v in m.items() if v["kind"] == "keras" and v["arch"] == arch]
        if ks: cand[f"{arch} (x{len(ks)} seeds)"] = ("deep", {k: 1.0 for k in ks})
    cls = {k: 1.0 for k in ("sk:ExtraTrees", "sk:HistGradientBoosting")}
    cand["Classical ensemble (ExtraTrees+GBM)"] = ("ensemble", cls)
    deep_rank = sorted([(regression_metrics(R[c]["z"]["y_val"], blend(c, w)[0])["RMSE"], n) for n, (t, w) in cand.items() if t == "deep"])
    if len(deep_rank) >= 2:
        top = [n for _, n in deep_rank[:3]]
        wdeep = {k: 1.0 / len(cand[n][1]) / len(top) for n in top for k in cand[n][1]}
        cand["Deep Top-3 ensemble"] = ("ensemble", wdeep)
        wh = {k: 0.5 * w for k, w in wdeep.items()}; wh.update({k: 0.25 for k in cls})
        cand["Hybrid: Deep Top-3 + Classical"] = ("ensemble", wh)
    CAND[c] = cand

TABLE, CHOSEN = {}, {}
for c in DATASETS:
    rows = [metric_row(n, t, c, *blend(c, w)) for n, (t, w) in CAND[c].items()]
    TABLE[c] = pd.DataFrame(rows).sort_values("Val_RMSE").reset_index(drop=True)
    CHOSEN[c] = TABLE[c].iloc[0]["Model"]
    print(f"\\n===== {c}: candidates ranked by VALIDATION RMSE =====")
    display(TABLE[c].round(3))
    print(f"-> selected on validation: {CHOSEN[c]}")
"""))
    C.append(md("## 6. Official test results"))
    C.append(code("""
for c in DATASETS:
    t = TABLE[c]; ch = t[t.Model == CHOSEN[c]].iloc[0]
    print(f"{c}  SELECTED MODEL: {CHOSEN[c]}")
    print(f"   validation : R² = {ch.Val_R2:.3f}  RMSE = {ch.Val_RMSE:.2f}  MAE = {ch.Val_MAE:.2f}")
    print(f"   TEST       : R² = {ch.Test_R2:.3f}  RMSE = {ch.Test_RMSE:.2f}  MAE = {ch.Test_MAE:.2f}      (target: capped RUL, same as training)")
    print(f"   TEST (raw) : R² = {ch.Test_R2_rawRUL:.3f}  RMSE = {ch.Test_RMSE_rawRUL:.2f}  MAE = {ch.Test_MAE_rawRUL:.2f}   NASA score = {ch.NASA_score:.0f}   within ±10 cycles = {ch['Within_10_%']:.0f}%")
    (FINAL / c / "figures").mkdir(parents=True, exist_ok=True)
    viz.fig_model_comparison(t, "Test_R2", f"{c}: official test R² (higher is better)", False, CHOSEN[c], FINAL / c / "figures" / "model_comparison_r2.png"); plt.show()
    viz.fig_model_comparison(t, "Test_RMSE", f"{c}: official test RMSE in cycles (lower is better)", True, CHOSEN[c], FINAL / c / "figures" / "model_comparison_rmse.png"); plt.show()
    w = CAND[c][CHOSEN[c]][1]; pt = blend(c, w)[1]
    viz.fig_pred_vs_true(R[c]["z"]["y_test"], pt, f"{c}: predicted vs actual RUL - {CHOSEN[c]}", FINAL / c / "figures" / "pred_vs_true.png"); plt.show()
"""))
    C.append(md("""
## 7. Over-fitting check
If a model memorised the training engines, its error on training data would be far smaller than on unseen data.
We compare RMSE on (a) a sample of training windows, (b) the held-out validation engines, (c) the official test engines.
"""))
    C.append(code("""
OVERFIT = {}
for c in DATASETS:
    z, w = R[c]["z"], CAND[c][CHOSEN[c]][1]; rng = np.random.RandomState(0)
    idx = rng.choice(len(z["X_train"]), min(6000, len(z["X_train"])), replace=False)
    tot = sum(w.values()); ptr = sum(wt * member_predict(R[c]["members"][k], z["X_train"][idx]) for k, wt in w.items()) / tot
    pv, pt = blend(c, w)
    OVERFIT[c] = dict(train_RMSE=regression_metrics(z["y_train"][idx], ptr)["RMSE"], val_RMSE=regression_metrics(z["y_val"], pv)["RMSE"], test_RMSE=regression_metrics(z["y_test"], pt)["RMSE"],
                      train_R2=regression_metrics(z["y_train"][idx], ptr)["R2"], val_R2=regression_metrics(z["y_val"], pv)["R2"], test_R2=regression_metrics(z["y_test"], pt)["R2"])
    o = OVERFIT[c]; print(f"{c}: RMSE train {o['train_RMSE']:.1f} | val {o['val_RMSE']:.1f} | test {o['test_RMSE']:.1f}      R² train {o['train_R2']:.3f} | val {o['val_R2']:.3f} | test {o['test_R2']:.3f}")
    gap = o["val_R2"] - o["test_R2"]
    print(f"   held-out validation vs held-out test: ΔR² = {gap:+.3f}  ->",
          "CONSISTENT on unseen engines: no harmful over-fitting to the validation set or the training engines" if abs(gap) < 0.08 and o["val_R2"] >= TARGET_R2
          else "WARNING: validation and test disagree - use more seeds / stronger regularisation")
    print("   (training-set R² is always optimistic - especially for tree ensembles; the honest evidence is the UNSEEN-engine scores above.)")
"""))
    C.append(md("""
## 8. Anomaly detection (unsupervised) — precision / recall / F1
The Mahalanobis detector from Phase 2 was fitted on **healthy early-life data only**. To score it we define *"degraded" = true RUL ≤ 50 cycles* and ask:
does the anomaly alarm (score > 0.5) fire on exactly those engines?
"""))
    C.append(code("""
ANOM = {}
for c in DATASETS:
    r, z = R[c], R[c]["z"]; ns = len(r["prep"].sensors); out = {}
    for split, X, y in (("validation", z["X_val"], z["y_val_raw"]), ("test", z["X_test"], z["y_test_raw"])):
        s = r["det"].score(X[:, -1, :ns]); lab = (y <= 50).astype(int)
        out[split] = classification_metrics(lab, (s > 0.5).astype(int), s)
    ANOM[c] = out; print(c, {k: {m: round(v, 3) for m, v in d.items()} for k, d in out.items()})
"""))
    C.append(md("## 9. Export the final model + dashboard data\nSaves the chosen ensemble (weights), preprocessing, anomaly detector and per-engine timelines, so the **backend and dashboard need no retraining**."))
    C.append(code("""
INFO = {}
for c in DATASETS:
    r, out = R[c], FINAL / c
    (out / "members").mkdir(parents=True, exist_ok=True); (out / "figures").mkdir(exist_ok=True)
    members = []; w = CAND[c][CHOSEN[c]][1]; tot = sum(w.values())
    for k, wt in w.items():
        m = r["members"][k]
        if m["kind"] == "sklearn":
            fname = f"members/{m['name']}.joblib"; joblib.dump(m["model"], out / fname, compress=3); members.append(dict(kind="sklearn", file=fname, weight=wt / tot))
        else:
            fname = f"members/{m['arch']}_s{m['seed']}.weights.h5"; shutil.copy(m["file"], out / fname); members.append(dict(kind="keras", arch=m["arch"], file=fname, kw=MODEL_KW, weight=wt / tot))
    ch = TABLE[c][TABLE[c].Model == CHOSEN[c]].iloc[0].to_dict()
    meta = dict(dataset=c, window=r["w"], cap=RUL_CAP, features=r["prep"].features, description=DATASET_CFG[c]["description"],
                final_model=dict(name=CHOSEN[c], members=members), has_tensorflow=RM.HAS_TF, tf_version=RM.TF_VERSION, quick_run=QUICK_RUN)
    save_json(meta, out / "meta.json"); save_json(r["prep"].to_dict(), out / "prep.json"); save_json(r["det"].to_dict(), out / "anomaly.json")
    pred = Predictor(out)
    chk = pred.predict_windows(r["z"]["X_test"]); ref = blend(c, w)[1]
    assert np.allclose(chk, ref, atol=0.5), f"reloaded model differs from in-memory model (max diff {np.abs(chk - ref).max():.3f})"
    print(f"{c}: exported '{CHOSEN[c]}' ({len(members)} members); reload check OK (max diff {np.abs(chk - ref).max():.4f} cycles)")
    test_df = load_subset(find_cmapss_files(DATA_DIR), c)[1]
    D = export_dashboard_data(pred, test_df, load_subset(find_cmapss_files(DATA_DIR), c)[2], out)
    INFO[c] = dict(pred=pred, D=D, meta=meta, chosen=ch)
    print(f"   dashboard data: {len(D['fleet'])} engines, {len(D['timelines']):,} timeline rows")
"""))
    C.append(md("""
## 9b. Model zoo for the web app
Every trained model (Keras networks, their ensembles and the classical models) is scored on the **same** engines and exported, so the web app can compare them side by side.
"""))
    C.append(code("""
from src import zoo
for c in DATASETS:
    zoo.build_zoo(ROOT, c, log=print)
"""))
    C.append(md("""
## 10. Explainable AI — *why* does the model predict a short RUL?
Two complementary methods:
* **Occlusion** (model-agnostic): reset one sensor to its healthy value and see how many cycles the predicted RUL *rises*. Large rise ⇒ that sensor is pushing the RUL down.
* **Integrated Gradients** (Keras, gradient-based): attributes the prediction to every (time-step, sensor) input value.
"""))
    C.append(code("""
XAI = {}
for c in DATASETS:
    pred, r = INFO[c]["pred"], R[c]; z = r["z"]; names = r["prep"].features
    occ = pred.occlusion_importance(z["X_test"])
    fi_occ = pd.Series(np.abs(occ).mean(0), index=names).sort_values(ascending=False)
    XAI[c] = dict(occlusion=fi_occ.to_dict())
    deep = [k for k, v in r["members"].items() if v["kind"] == "keras"]
    if deep:
        best = min(deep, key=lambda k: regression_metrics(z["y_val"], r["members"][k]["val"])["RMSE"])
        ig = RM.integrated_gradients(r["members"][best]["model"], z["X_test"], steps=24)
        fi_ig = pd.Series(np.abs(ig).sum(1).mean(0), index=names).sort_values(ascending=False)
        XAI[c]["integrated_gradients"] = fi_ig.to_dict()
        fig, axs = plt.subplots(1, 3, figsize=(16, 4.2), gridspec_kw={"width_ratios": [1.2, 1, 1]})
        im = axs[0].imshow(np.abs(ig).mean(0).T, aspect="auto", cmap="magma"); axs[0].set_yticks(range(len(names))); axs[0].set_yticklabels(names, fontsize=7); axs[0].grid(False)
        axs[0].set_xlabel("time step in window (right = most recent)"); axs[0].set_title("Integrated Gradients: where does the model look?"); plt.colorbar(im, ax=axs[0], fraction=0.04)
        top = fi_ig.head(8)[::-1]; axs[1].barh(top.index, top.values, color=viz.VIOLET); axs[1].set_title("Top sensors - Integrated Gradients")
        top = fi_occ.head(8)[::-1]; axs[2].barh(top.index, top.values, color=viz.BLUE); axs[2].set_title("Top sensors - occlusion (cycles)")
        fig.tight_layout(); fig.savefig(FINAL / c / "figures" / "explainability.png", bbox_inches="tight"); plt.show()
        from scipy.stats import spearmanr
        print(f"{c}: rank agreement between the two explanation methods (Spearman) = {spearmanr(fi_ig[names].values, fi_occ[names].values)[0]:.2f}")
    else:
        top = fi_occ.head(8)[::-1]; fig, ax = plt.subplots(figsize=(6, 3.6)); ax.barh(top.index, top.values, color=viz.BLUE); ax.set_title(f"{c}: top sensors (occlusion)")
        fig.savefig(FINAL / c / "figures" / "explainability.png", bbox_inches="tight"); plt.show()
    print(f"{c}: most influential inputs:", list(fi_occ.head(5).index))
"""))
    C.append(code("""
c = DATASETS[0]; D = INFO[c]["D"]; fleet = D["fleet"]
u = int(fleet.sort_values("rul_pred").iloc[len(fleet) // 4]["unit_id"])           # an engine in the 'warning' zone
tl = D["timelines"][D["timelines"].unit_id == u]; imp = D["importance"][D["importance"].unit_id == u]
viz.fig_rul_timeline(tl.cycle, tl.rul_pred, tl.rul_true_capped, RUL_CAP, title=f"{c} - test engine {u}: predicted vs true RUL over its life"); plt.show()
viz.fig_anomaly_timeline(tl.cycle, tl.anomaly_score, title=f"{c} - engine {u}: anomaly score"); plt.show()
viz.fig_importance(imp.label + " " + imp.trend, imp.contribution, title=f"Engine {u}: why is the RUL low?"); plt.show()
"""))
    C.append(md("""
## 11. Model compression for edge / IoT deployment
* **Knowledge distillation:** a tiny GRU student (16 units) learns from the big model's predictions (70 %) + ground truth (30 %).
* **Quantisation:** float16 weights (always possible) and TensorFlow-Lite dynamic-range int8 (when the converter supports the LSTM ops on your machine).

We report size, per-window latency and accuracy, and only claim a benefit if the error stays acceptable.
"""))
    C.append(code("""
COMP = {}
if RM.HAS_TF:
    for c in DATASETS:
        r, z = R[c], R[c]["z"]; deep = [k for k, v in r["members"].items() if v["kind"] == "keras"]
        if not deep: continue
        try:
            best = min(deep, key=lambda k: regression_metrics(z["y_val"], r["members"][k]["val"])["RMSE"]); teacher = r["members"][best]["model"]; arch = r["members"][best]["arch"]
            soft = teacher.predict(z["X_train"], batch_size=1024, verbose=0).ravel()
            student = RM.distill_student(soft, z["X_train"], z["y_train"], z["X_val"], z["y_val"], RUL_CAP, epochs=10 if QUICK_RUN else 40)
            f16, f16_bytes = RM.float16_quantize(teacher, arch, r["w"], r["F"], **MODEL_KW)
            rows = []
            def add(name, model, size, lat_fn=None, preds=None):
                p = preds if preds is not None else RM.predict_rul(model, z["X_test"]); lat = RM.latency_ms(lat_fn or (lambda x: model(x, training=False).numpy()), z["X_test"])
                rows.append(dict(Model=name, Size_KB=size / 1024, Latency_ms=lat, Test_RMSE=regression_metrics(z["y_test"], p)["RMSE"], Test_R2=regression_metrics(z["y_test"], p)["R2"]))
            add(f"Teacher ({arch}, float32)", teacher, teacher.count_params() * 4)
            add("Teacher float16 weights", f16, f16_bytes)
            add("Distilled student (tiny GRU)", student, student.count_params() * 4)
            size, info = RM.tflite_dynamic_quantize(teacher, MODELS / c / "teacher_dynamic_int8.tflite")
            if size:
                try:
                    p = RM.tflite_predict(info, z["X_test"]); add("Teacher TFLite int8 (dynamic)", None, size, lat_fn=lambda x: RM.tflite_predict(info, x), preds=p)
                except Exception as exc: print("TFLite model created but could not be executed here:", str(exc)[:100]); rows.append(dict(Model="Teacher TFLite int8 (size only)", Size_KB=size / 1024, Latency_ms=np.nan, Test_RMSE=np.nan, Test_R2=np.nan))
            else: print(f"{c}: TFLite conversion not available here ({info}); float16 quantisation is reported instead.")
            COMP[c] = pd.DataFrame(rows); display(COMP[c].round(3))
            fig, axs = plt.subplots(1, 3, figsize=(13, 3.2))
            for ax, col in zip(axs, ["Size_KB", "Latency_ms", "Test_RMSE"]): ax.barh(COMP[c]["Model"], COMP[c][col], color=viz.BLUE); ax.set_title(col)
            axs[1].set_yticklabels([]); axs[2].set_yticklabels([]); fig.tight_layout(); fig.savefig(FINAL / c / "figures" / "compression.png", bbox_inches="tight"); plt.show()
        except Exception as exc:
            print(f"{c}: compression step skipped ({type(exc).__name__}: {str(exc)[:150]})")
else:
    print("TensorFlow not available: compression needs the Keras models. Skipped.")
"""))
    C.append(md("## 12. Save results & final summary"))
    C.append(code("""
viz.fig_pipeline(FINAL / "pipeline.png"); plt.show()
index = {"datasets": [], "default": DATASETS[0]}
for c in DATASETS:
    t = TABLE[c]; ch = INFO[c]["chosen"]
    res = dict(dataset=c, description=DATASET_CFG[c]["description"], selected_model=CHOSEN[c], has_tensorflow=RM.HAS_TF, tf_version=RM.TF_VERSION, quick_run=QUICK_RUN,
               rul_cap=RUL_CAP, window=R[c]["w"], n_features=R[c]["F"], headline={k: float(v) for k, v in ch.items() if k not in ("Model", "Type")},
               table=t.round(4).to_dict("records"), overfit_check=OVERFIT[c], anomaly=ANOM[c], explainability=XAI[c],
               compression=(COMP[c].round(4).to_dict("records") if c in COMP else []),
               target_r2=TARGET_R2, target_met=bool(ch["Test_R2"] >= TARGET_R2 and ch["Val_R2"] >= TARGET_R2))
    save_json(res, FINAL / c / "results.json"); index["datasets"].append(c)
save_json(index, FINAL / "index.json")

print("=" * 78); print("FINAL SUMMARY"); print("=" * 78)
for c in DATASETS:
    ch = INFO[c]["chosen"]
    print(f"\\n{c} ({DATASET_CFG[c]['description']})  ->  {CHOSEN[c]}")
    print(f"   Validation R²={ch['Val_R2']:.3f} | Test R² (capped RUL)={ch['Test_R2']:.3f} | Test R² (raw RUL)={ch['Test_R2_rawRUL']:.3f}")
    print(f"   Test MAE={ch['Test_MAE']:.2f} cycles | RMSE={ch['Test_RMSE']:.2f} cycles | NASA score={ch['NASA_score']:.0f} | within ±10 cycles: {ch['Within_10_%']:.0f}%")
    print(f"   Anomaly detection (test): precision={ANOM[c]['test']['Precision']:.2f} recall={ANOM[c]['test']['Recall']:.2f} F1={ANOM[c]['test']['F1']:.2f}")
    print(f"   Target R² >= {TARGET_R2}: {'PASS ✔' if ch['Test_R2'] >= TARGET_R2 and ch['Val_R2'] >= TARGET_R2 else 'NOT MET ✘ (see tips in README)'}")
print("\\nPHASE 3 COMPLETE ✔  — launch the web app:   python run.py")
"""))
    return C
