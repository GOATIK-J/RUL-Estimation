"""
TEST HELPER ONLY (never used in real runs): a stand-in for src/rul_models' Keras part so that the Phase-3 notebook
*control flow* (training loops, selection, export, reload, XAI, compression) can be exercised on a machine
without TensorFlow. Models are scikit-learn regressors wrapped in a Keras-like interface.
"""
import importlib.util
import sys
import types
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

ROOT = Path(__file__).resolve().parent.parent
_STATE = {"seed": 0}


class _Out:
    def __init__(self, a): self.a = a
    def numpy(self): return self.a


class FakeModel:
    def __init__(self, arch, window, F, **kw):
        self.arch, self.window, self.F = arch, window, F
        self.reg = HistGradientBoostingRegressor(max_iter=40 + 10 * len(arch) % 60, learning_rate=0.1, random_state=_STATE["seed"])
    def count_params(self): return 1000 + 37 * len(self.arch)
    def _flat(self, X):
        from src.rul_core import flat_features
        return flat_features(np.asarray(X))
    def predict(self, X, batch_size=None, verbose=0): return self.reg.predict(self._flat(X)).reshape(-1, 1)
    def __call__(self, x, training=False): return _Out(self.predict(np.asarray(x)))
    def get_weights(self): return [np.zeros(3)]
    def set_weights(self, w): pass


def install():
    spec = importlib.util.spec_from_file_location("src._real_rul_models", ROOT / "src" / "rul_models.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    mod.HAS_TF, mod.TF_VERSION = True, "FAKE (flow test only)"
    mod.tf = types.SimpleNamespace(config=types.SimpleNamespace(list_physical_devices=lambda *_: []))
    mod.set_seed = lambda s: _STATE.update(seed=int(s))
    mod.build_model = lambda arch, window, F, **kw: FakeModel(arch, window, F, **kw)

    def train_model(model, Xtr, ytr, Xva, yva, cap=125.0, epochs=1, batch_size=1, patience=1, verbose=0):
        model.reg.fit(model._flat(Xtr), ytr / cap)
        l = float(np.mean((model.reg.predict(model._flat(Xtr)) - ytr / cap) ** 2)); lv = float(np.mean((model.reg.predict(model._flat(Xva)) - yva / cap) ** 2))
        return types.SimpleNamespace(history={"loss": [l * 2, l], "val_loss": [lv * 2, lv]})
    mod.train_model = train_model
    mod.predict_rul = lambda model, X, cap=125.0: np.clip(model.predict(X).ravel() * cap, 0, cap)

    def save_weights(model, path):
        path = str(path); path = path if path.endswith(".weights.h5") else path + ".weights.h5"
        Path(path).parent.mkdir(parents=True, exist_ok=True); joblib.dump(model.reg, path); return path
    mod.save_weights = save_weights

    def load_model(arch, window, F, path, **kw):
        m = FakeModel(arch, window, F); m.reg = joblib.load(path); return m
    mod.load_model = load_model
    mod.integrated_gradients = lambda model, X, steps=24, batch_size=64, baseline=None: np.asarray(X) * 0.05
    def distill(soft, Xtr, ytr, Xva, yva, cap=125.0, alpha=0.7, epochs=1, seed=0, verbose=0):
        m = FakeModel("student_gru", Xtr.shape[1], Xtr.shape[2]); m.reg.fit(m._flat(Xtr), alpha * soft + (1 - alpha) * ytr / cap); return m
    mod.distill_student = distill
    mod.float16_quantize = lambda model, arch, w, F, **kw: (model, model.count_params() * 2)
    mod.tflite_dynamic_quantize = lambda model, path: (None, "fake backend")
    sys.modules["src.rul_models"] = mod
    import src
    src.rul_models = mod
