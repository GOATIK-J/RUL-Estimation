"""
Run from the project root:   python -m pytest -q      (or:  python tests/test_pipeline.py)
Needs the C-MAPSS files in data/raw (Phase 1 downloads them). Artifact tests run only after Phase 3.
"""
import sys
from pathlib import Path

import numpy as np

try:
    import pytest
except ImportError:                                   # tiny stand-in so the tests also run without pytest installed
    import types

    class _Skip(Exception):
        pass

    def _skipif(cond, reason=""):
        def deco(fn):
            fn._skip = reason if cond else None
            return fn
        return deco

    def _skip(reason=""):
        raise _Skip(reason)

    pytest = types.SimpleNamespace(mark=types.SimpleNamespace(skipif=_skipif), skip=_skip, main=None, _Skip=_Skip)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import rul_core as rc  # noqa: E402

FILES = rc.find_cmapss_files(ROOT / "data" / "raw")
HAVE_DATA = all(f"{p}_FD001.txt" in FILES for p in ("train", "test", "RUL"))
needs_data = pytest.mark.skipif(not HAVE_DATA, reason="C-MAPSS data not downloaded yet")


def test_metrics_perfect_and_known_values():
    y = np.array([10.0, 20.0, 30.0])
    m = rc.regression_metrics(y, y)
    assert m["R2"] == 1.0 and m["RMSE"] == 0.0 and m["MAE"] == 0.0
    m = rc.regression_metrics(y, y + 5)
    assert abs(m["MAE"] - 5) < 1e-9 and abs(m["RMSE"] - 5) < 1e-9
    assert rc.nasa_score(y, y + 10) > rc.nasa_score(y, y - 10)          # late predictions are punished more


def test_window_shapes_and_padding():
    feat = np.arange(20, dtype=np.float32).reshape(10, 2)
    W = rc.engine_windows(feat, 4)
    assert W.shape == (10, 4, 2)
    assert np.allclose(W[-1], feat[-4:]) and np.allclose(W[0][-1], feat[0])      # last window ends at last cycle; first is padded


def test_anomaly_detector_calibration_and_scores_in_range():
    rng = np.random.RandomState(0)
    healthy = rng.randn(500, 5)
    det = rc.AnomalyDetector().fit(healthy)
    rows = np.vstack([rng.randn(200, 5), rng.randn(200, 5) + 3.0])
    labels = np.r_[np.zeros(200), np.ones(200)]
    f1, thr = det.calibrate(rows, labels)
    s = det.score(rows)
    assert f1 > 0.9 and ((s >= 0) & (s < 1)).all() and s[200:].mean() > s[:200].mean()


def test_viz_functions_render():
    import matplotlib
    matplotlib.use("Agg")
    from src import viz
    c = np.arange(1, 101)
    for fig in (viz.fig_gauge(70, "Health"), viz.fig_status_donut({"HEALTHY": 5, "WARNING": 3, "CRITICAL": 2}),
                viz.fig_rul_timeline(c, np.linspace(125, 0, 100), np.linspace(125, 0, 100), 125, cutoff=50),
                viz.fig_anomaly_timeline(c, np.linspace(0, 1, 100)), viz.fig_importance(["a", "b", "c"], [3, -1, 2]),
                viz.fig_pred_vs_true(c, c + np.random.randn(100)), viz.fig_generalization(0.99, 0.93, 0.91), viz.fig_pipeline()):
        assert fig is not None


def test_app_and_backend_compile():
    import py_compile
    for f in (ROOT / "run.py", ROOT / "backend" / "main.py", ROOT / "src" / "rul_models.py", ROOT / "src" / "inference.py", ROOT / "src" / "zoo.py", ROOT / "src" / "api_core.py", ROOT / "src" / "imageid.py", ROOT / "src" / "server_std.py"):
        py_compile.compile(str(f), doraise=True)


def test_split_engines_disjoint():
    tr, va = rc.split_engines(range(1, 101), 0.2)
    assert len(va) == 20 and not set(tr) & set(va)


@needs_data
def test_preprocessing_causal_and_no_leak():
    tr, te, rul = rc.load_subset(FILES, "FD001")
    tr = rc.add_rul(tr)
    assert tr.RUL.max() == rc.RUL_CAP and (tr.RUL_raw >= 0).all()
    ids_tr, ids_va = rc.split_engines(tr.unit_id.unique())
    fit = tr[tr.unit_id.isin(ids_tr)]
    p = rc.Preprocessor(1, 5, False, rc.RUL_CAP, 30).fit(fit)
    g = tr[tr.unit_id == ids_va[0]].sort_values("cycle")
    full = p.transform_engine(g)
    part = p.transform_engine(g.head(60))
    assert np.allclose(full[:60], part, atol=1e-5), "features must not depend on future cycles (causal)"
    p2 = rc.Preprocessor.from_dict(p.to_dict())
    assert np.allclose(p2.transform_engine(g), full), "JSON round-trip must be exact"
    Xte, y, units, last = rc.build_test_windows(p, te, rul, 30)
    assert Xte.shape == (100, 30, p.n_features) and np.isfinite(Xte).all()


@needs_data
def test_fd004_condition_normalisation_centres_sensors():
    tr, _, _ = rc.load_subset(FILES, "FD004") if "train_FD004.txt" in FILES else (None, None, None)
    if tr is None:
        pytest.skip("FD004 not available")
    p = rc.Preprocessor(6, 1, False, 125, 40).fit(tr)
    z = np.vstack([p.transform_engine(g) for _, g in list(tr.groupby("unit_id"))[:20]])
    assert np.abs(z.mean(0)).max() < 0.5 and z.std(0).max() < 2.0


@needs_data
def test_baseline_reaches_target_on_fd001():
    """End-to-end sanity: gradient boosting on window statistics must clear R2 >= 0.75 on the official FD001 test set."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    tr, te, rul = rc.load_subset(FILES, "FD001"); tr = rc.add_rul(tr)
    ids_tr, _ = rc.split_engines(tr.unit_id.unique())
    fit = tr[tr.unit_id.isin(ids_tr)]
    p = rc.Preprocessor(1, 5, False, rc.RUL_CAP, 30).fit(fit)
    X, y, *_ = rc.build_windows(p, fit, 30)
    Xte, yte, *_ = rc.build_test_windows(p, te, rul, 30)
    m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=60,
                                      l2_regularization=5.0, random_state=0).fit(rc.flat_features(X), y)
    assert rc.regression_metrics(yte, np.clip(m.predict(rc.flat_features(Xte)), 0, 125))["R2"] >= 0.75


def test_project_is_tensorflow_only():
    banned = ("import torch", "from torch", "torch.nn", "pytorch_lightning")
    for f in list((ROOT / "src").glob("*.py")) + [ROOT / "backend" / "main.py", ROOT / "run.py"]:
        txt = f.read_text().lower()
        assert not any(b in txt for b in banned), f"{f.name} must not use PyTorch"
    assert "import tensorflow" in (ROOT / "src" / "rul_models.py").read_text()


@pytest.mark.skipif(not (ROOT / "artifacts" / "final" / "FD001" / "meta.json").exists(), reason="Phase 3 not run yet")
def test_exported_artifacts_reproduce_predictions():
    import pandas as pd
    from src.inference import Predictor
    d = ROOT / "artifacts" / "final" / "FD001"
    fleet = pd.read_csv(d / "fleet_summary.csv")
    sens = pd.read_csv(d / "test_sensors.csv.gz")
    pred = Predictor(d)
    u = int(fleet.unit_id.iloc[0])
    res = pred.assess(sens[sens.unit_id == u].drop(columns=["unit_id"]))
    assert abs(res["rul"] - fleet.set_index("unit_id").loc[u, "rul_pred"]) < 0.5
    assert 0 <= res["anomaly_score"] <= 1 and res["status"] in ("HEALTHY", "WARNING", "CRITICAL")


# ---------------------------------------------------------------- web app / API / image identification
def test_imageid_filename_and_hash():
    from PIL import Image
    from src import imageid
    assert imageid.unit_from_filename("M-023.jpg") == 23
    assert imageid.unit_from_filename("engine_7_front.png") == 7
    assert imageid.unit_from_filename("holiday.png") is None
    import io
    def png(img):
        buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()
    a = png(Image.effect_noise((64, 64), 60).convert("RGB"))
    b = png(Image.effect_noise((64, 64), 60).convert("RGB"))
    assert imageid.hamming(imageid.dhash(a), imageid.dhash(a)) == 0
    assert imageid.hamming(imageid.dhash(a), imageid.dhash(b)) > 0


@pytest.mark.skipif(not (ROOT / "artifacts" / "zoo" / "FD001" / "index.json").exists(), reason="zoo not built")
def test_api_and_stdlib_server():
    import json, threading, urllib.request
    from src import api_core
    st, _, body = api_core.handle("GET", "/api/health", {}, b"")[:3]
    assert st == 200
    st, _, body = api_core.handle("GET", "/api/models?ds=FD001", {}, b"")[:3]
    models = json.loads(body)["models"]
    assert any(m["status"] == "ready" for m in models)
    st = api_core.handle("GET", "/api/nope", {}, b"")[0]
    assert st == 404
    from src.server_std import make_server
    srv = make_server("127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    for path in ("/api/health", "/api/fleet?ds=FD001", "/api/compare?ds=FD001&unit=1", "/"):
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}") as r:
            assert r.status == 200
    srv.shutdown()


if __name__ == "__main__":
    if pytest.main is not None:
        sys.exit(pytest.main([__file__, "-q"]))
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            if getattr(fn, "_skip", None):
                print(f"SKIP  {name}: {fn._skip}"); continue
            try:
                fn(); print(f"PASS  {name}")
            except pytest._Skip as e:
                print(f"SKIP  {name}: {e}")
            except Exception as e:
                failed += 1; print(f"FAIL  {name}: {type(e).__name__}: {e}")
    sys.exit(1 if failed else 0)

